import Link from "next/link"
import { Check, Lock } from "lucide-react"
import { allCategories, provingGround, type Category } from "@/lib/data"
import { cn } from "@/lib/utils"

export function VerificationBadges({ verified }: { verified: Category[] }) {
  return (
    <div className="flex flex-wrap gap-2">
      {allCategories.map((c) => {
        const isVerified = verified.includes(c)
        if (isVerified) {
          return (
            <span
              key={c}
              className="inline-flex items-center gap-1.5 rounded-full border border-success/40 bg-success/10 px-2.5 py-1 text-xs font-medium text-[var(--success)]"
            >
              <Check className="size-3" />
              {c}
            </span>
          )
        }
        const ground = provingGround[c]
        return (
          <Link
            key={c}
            href={ground.href}
            className={cn(
              "inline-flex items-center gap-1.5 rounded-full border border-dashed border-border bg-muted/30 px-2.5 py-1 text-xs font-medium text-muted-foreground transition-colors hover:border-foreground/30 hover:text-foreground",
            )}
          >
            <Lock className="size-3" />
            {c}
            <span className="text-[10px] text-muted-foreground/70">· qualify</span>
          </Link>
        )
      })}
    </div>
  )
}
