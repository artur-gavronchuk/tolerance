"use client"

import { useMemo, useState } from "react"
import Link from "next/link"
import { Award, CheckCircle2, Send, XCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import { agentSlug } from "@/lib/data"
import type { Bid } from "@/lib/marketplace"

export function BidList({
  bids,
  initialWinnerIds,
  canBid,
  ownAgentHasBid,
}: {
  bids: Bid[]
  initialWinnerIds?: string[]
  /** Whether "you" (Atlas) are verified for this job's category and can submit a bid. */
  canBid: boolean
  ownAgentHasBid: boolean
}) {
  const [winnerIds, setWinnerIds] = useState<string[] | null>(initialWinnerIds ?? null)
  const [selected, setSelected] = useState<string[]>([])
  const [showBidForm, setShowBidForm] = useState(false)
  const [ownBid, setOwnBid] = useState<Bid | null>(null)

  const allBids = ownBid ? [ownBid, ...bids] : bids
  const hired = winnerIds !== null

  const total = useMemo(
    () => allBids.filter((b) => selected.includes(b.id)).reduce((sum, b) => sum + b.price, 0),
    [allBids, selected],
  )

  function toggle(id: string) {
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  function confirmHires() {
    if (selected.length === 0) return
    setWinnerIds(selected)
  }

  return (
    <div className={cn("space-y-3", !hired && selected.length > 0 && "pb-20")}>
      {!hired && canBid && !ownAgentHasBid && !ownBid && (
        <div className="rounded-xl border border-dashed border-brand/40 bg-brand-muted/20 p-4">
          {!showBidForm ? (
            <button
              onClick={() => setShowBidForm(true)}
              className="inline-flex items-center gap-1.5 text-sm font-medium text-brand hover:underline"
            >
              <Send className="size-4" />
              Submit a bid as Atlas
            </button>
          ) : (
            <BidForm
              onSubmit={(bid) => {
                setOwnBid(bid)
                setShowBidForm(false)
              }}
              onCancel={() => setShowBidForm(false)}
            />
          )}
        </div>
      )}

      {allBids.map((b) => {
        const isWinner = winnerIds?.includes(b.id) ?? false
        const isChecked = selected.includes(b.id)
        const isOwn = ownBid?.id === b.id
        return (
          <div
            key={b.id}
            className={cn(
              "rounded-xl border p-4 transition-colors",
              isWinner ? "border-success/50 bg-success/5" : "border-border bg-card",
              hired && !isWinner && "opacity-60",
            )}
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                {!hired && (
                  <button
                    onClick={() => toggle(b.id)}
                    aria-pressed={isChecked}
                    aria-label={isChecked ? `Deselect ${b.agent}` : `Select ${b.agent} to hire`}
                    className={cn(
                      "flex size-5 shrink-0 items-center justify-center rounded-md border transition-colors",
                      isChecked ? "border-foreground bg-foreground text-background" : "border-border",
                    )}
                  >
                    {isChecked && <CheckCircle2 className="size-3.5" />}
                  </button>
                )}
                <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-foreground text-sm font-semibold text-background">
                  {b.agent[0]}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <Link href={`/agents/${agentSlug(b.agent)}`} className="text-sm font-semibold tracking-tight hover:underline">
                      {b.agent}
                    </Link>
                    <span className="text-xs text-muted-foreground">by {b.author}</span>
                    {isOwn && (
                      <span className="rounded bg-brand-muted px-1.5 py-0.5 text-[10px] font-semibold text-brand">
                        YOUR AGENT
                      </span>
                    )}
                    {isWinner && (
                      <span className="flex items-center gap-1 rounded bg-success/15 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-[var(--success)]">
                        <Award className="size-3" />
                        hired
                      </span>
                    )}
                    {hired && !isWinner && (
                      <span className="flex items-center gap-1 rounded bg-muted px-1.5 py-0.5 text-[10px] font-semibold uppercase text-muted-foreground">
                        <XCircle className="size-3" />
                        not selected
                      </span>
                    )}
                  </div>
                  <p className="mt-0.5 text-xs text-muted-foreground">{b.rating} elo · {b.etaHours}h ETA</p>
                </div>
              </div>
              <span className="text-base font-semibold tabular-nums">${b.price.toLocaleString()}</span>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{b.pitch}</p>
          </div>
        )
      })}

      {!hired && selected.length > 0 && (
        <div className="fixed inset-x-0 bottom-4 z-50 mx-auto flex w-[calc(100%-2.5rem)] max-w-lg items-center justify-between gap-3 rounded-xl border border-foreground bg-foreground px-4 py-3 text-background shadow-lg">
          <p className="text-sm font-medium">
            Hiring {selected.length} agent{selected.length > 1 ? "s" : ""} · ${total.toLocaleString()} total
          </p>
          <button
            onClick={confirmHires}
            className="shrink-0 rounded-lg bg-background px-3 py-1.5 text-xs font-semibold text-foreground transition-opacity hover:opacity-90"
          >
            Confirm hires
          </button>
        </div>
      )}
    </div>
  )
}

function BidForm({ onSubmit, onCancel }: { onSubmit: (bid: Bid) => void; onCancel: () => void }) {
  const [price, setPrice] = useState("")
  const [eta, setEta] = useState("")
  const [pitch, setPitch] = useState("")

  const canSubmit = Number(price) > 0 && Number(eta) > 0 && pitch.trim().length > 0

  return (
    <div className="space-y-2.5">
      <div className="grid grid-cols-2 gap-2.5">
        <input
          value={price}
          onChange={(e) => setPrice(e.target.value)}
          type="number"
          min={1}
          placeholder="Price ($)"
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-foreground/40"
        />
        <input
          value={eta}
          onChange={(e) => setEta(e.target.value)}
          type="number"
          min={1}
          placeholder="ETA (hours)"
          className="rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-foreground/40"
        />
      </div>
      <textarea
        value={pitch}
        onChange={(e) => setPitch(e.target.value)}
        placeholder="Your pitch — how will Atlas approach this?"
        rows={3}
        className="w-full resize-none rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-foreground/40"
      />
      <div className="flex items-center gap-2">
        <button
          disabled={!canSubmit}
          onClick={() =>
            onSubmit({
              id: `own-${Date.now()}`,
              jobId: "",
              agent: "Atlas",
              author: "you",
              price: Number(price),
              etaHours: Number(eta),
              pitch,
              rating: 1720,
              submittedAt: new Date().toISOString(),
            })
          }
          className="rounded-lg bg-foreground px-3 py-1.5 text-xs font-semibold text-background transition-opacity hover:opacity-90 disabled:opacity-40"
        >
          Submit bid
        </button>
        <button
          onClick={onCancel}
          className="rounded-lg border border-border px-3 py-1.5 text-xs font-medium transition-colors hover:bg-muted"
        >
          Cancel
        </button>
      </div>
    </div>
  )
}
