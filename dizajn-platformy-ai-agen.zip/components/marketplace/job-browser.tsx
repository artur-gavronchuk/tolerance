"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowRight, Lock } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Category } from "@/lib/data"
import type { Job, JobStatus } from "@/lib/marketplace"
import { jobStatusLabels, getBidsForJob, isVerifiedForJob } from "@/lib/marketplace"

const statusFilters: (JobStatus | "all")[] = ["all", "open", "in_review", "completed"]
const statusLabelsShort: Record<JobStatus | "all", string> = {
  all: "All",
  open: "Open",
  in_review: "In review",
  completed: "Completed",
}

const statusTone: Record<JobStatus, string> = {
  open: "text-success",
  in_review: "text-amber-600",
  completed: "text-muted-foreground",
}

export function JobBrowser({ jobs, verifiedCategories }: { jobs: Job[]; verifiedCategories: Category[] }) {
  const [status, setStatus] = useState<JobStatus | "all">("all")

  const filtered = jobs.filter((j) => status === "all" || j.status === status)

  return (
    <section>
      <div className="flex flex-wrap items-center gap-1.5">
        {statusFilters.map((s) => (
          <button
            key={s}
            onClick={() => setStatus(s)}
            className={cn(
              "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
              status === s
                ? "border-foreground bg-foreground text-background"
                : "border-border text-muted-foreground hover:border-foreground/30 hover:text-foreground",
            )}
          >
            {statusLabelsShort[s]}
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-3">
        {filtered.map((j) => {
          const bidCount = getBidsForJob(j.id).length
          const verified = isVerifiedForJob(verifiedCategories, j)
          return (
            <Link
              key={j.id}
              href={`/marketplace/${j.id}`}
              className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-foreground/30 sm:flex-row sm:items-center"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className={cn("text-xs font-medium", statusTone[j.status])}>{jobStatusLabels[j.status]}</span>
                  <span className="text-xs text-muted-foreground">· {bidCount} bids</span>
                  <span className="text-xs text-muted-foreground">· {j.category}</span>
                  {!verified && (
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Lock className="size-3" />
                      not verified
                    </span>
                  )}
                </div>
                <h3 className="mt-1 truncate text-sm font-semibold tracking-tight">{j.title}</h3>
                <p className="mt-1 line-clamp-1 text-sm text-muted-foreground">{j.brief}</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {j.skills.slice(0, 3).map((s) => (
                    <span key={s} className="rounded-md bg-muted px-1.5 py-0.5 text-[11px] text-muted-foreground">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-4 sm:flex-col sm:items-end sm:gap-1">
                <span className="text-base font-semibold tabular-nums">${j.budget.toLocaleString()}</span>
                <span className="flex items-center gap-1 text-xs text-muted-foreground">
                  Due {new Date(j.deadline).toLocaleDateString(undefined, { month: "short", day: "numeric" })}
                  <ArrowRight className="size-3.5" />
                </span>
              </div>
            </Link>
          )
        })}
      </div>
    </section>
  )
}
