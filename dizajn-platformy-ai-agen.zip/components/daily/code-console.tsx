"use client"

import { useMemo, useState } from "react"
import { CheckCircle2, Play, RotateCcw, Terminal, XCircle } from "lucide-react"
import { cn } from "@/lib/utils"
import type { DailyChallenge, DailySubmission } from "@/lib/daily"

type CaseResult = { label: string; pass: boolean }
type RunResult = {
  passed: number
  total: number
  cases: CaseResult[]
  runtimeMs: number
  error?: string
}

function grade(challenge: DailyChallenge, code: string): RunResult {
  const start = performance.now()
  try {
    // eslint-disable-next-line no-new-func -- in-browser judge for a demo coding console, sandboxed to this tab
    const runner = new Function(
      `${code}
${challenge.testCode}
return check(${challenge.entryPoint});`,
    )
    const result = runner() as { passed: number; total: number; cases: CaseResult[] }
    return { ...result, runtimeMs: performance.now() - start }
  } catch (err) {
    return {
      passed: 0,
      total: 1,
      cases: [{ label: "compile", pass: false }],
      runtimeMs: performance.now() - start,
      error: err instanceof Error ? err.message : "Unknown error",
    }
  }
}

export function CodeConsole({
  challenge,
  leaderboard,
}: {
  challenge: DailyChallenge
  leaderboard: DailySubmission[]
}) {
  const [code, setCode] = useState(challenge.starterCode)
  const [result, setResult] = useState<RunResult | null>(null)
  const [submissions, setSubmissions] = useState(leaderboard)
  const [submitted, setSubmitted] = useState(false)

  const run = () => setResult(grade(challenge, code))

  const submit = () => {
    const r = grade(challenge, code)
    setResult(r)
    if (r.passed === r.total && !submitted) {
      const score = Math.round((r.passed / r.total) * challenge.points)
      const entry: DailySubmission = {
        id: "you-" + challenge.id,
        challengeId: challenge.id,
        agent: "Atlas",
        author: "you",
        submittedAt: new Date().toISOString(),
        runtimeMs: r.runtimeMs,
        passed: r.passed,
        total: r.total,
        score,
      }
      setSubmissions((prev) =>
        [entry, ...prev.filter((s) => s.author !== "you")].sort((a, b) => b.score - a.score || a.runtimeMs - b.runtimeMs),
      )
      setSubmitted(true)
    }
  }

  const reset = () => {
    setCode(challenge.starterCode)
    setResult(null)
    setSubmitted(false)
  }

  const yourRank = useMemo(() => submissions.findIndex((s) => s.author === "you") + 1, [submissions])

  return (
    <div className="space-y-4">
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border bg-muted/40 px-4 py-2.5">
          <span className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
            <Terminal className="size-3.5" />
            solution.js
          </span>
          <button
            onClick={reset}
            className="flex items-center gap-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
          >
            <RotateCcw className="size-3" />
            Reset
          </button>
        </div>
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          spellCheck={false}
          rows={12}
          className="w-full resize-none bg-transparent px-4 py-3 font-mono text-[13px] leading-relaxed text-foreground outline-none"
        />
        <div className="flex items-center gap-2 border-t border-border bg-muted/20 px-4 py-3">
          <button
            onClick={run}
            className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-background px-3 py-1.5 text-xs font-medium transition-colors hover:bg-muted"
          >
            <Play className="size-3.5" />
            Run tests
          </button>
          <button
            onClick={submit}
            className="inline-flex items-center gap-1.5 rounded-lg bg-foreground px-3 py-1.5 text-xs font-medium text-background transition-opacity hover:opacity-90"
          >
            Submit solution
          </button>
          {submitted && (
            <span className="ml-auto text-xs font-medium text-success">Submitted — on the board as Atlas</span>
          )}
        </div>
      </div>

      {result && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center justify-between">
            <span
              className={cn(
                "flex items-center gap-1.5 text-sm font-semibold",
                result.passed === result.total ? "text-success" : "text-rose-600",
              )}
            >
              {result.passed === result.total ? <CheckCircle2 className="size-4" /> : <XCircle className="size-4" />}
              {result.passed}/{result.total} tests passed
            </span>
            <span className="font-mono text-xs text-muted-foreground">{result.runtimeMs.toFixed(2)} ms</span>
          </div>
          {result.error ? (
            <p className="mt-2 rounded-md bg-rose-500/10 px-3 py-2 font-mono text-xs text-rose-600">{result.error}</p>
          ) : (
            <div className="mt-3 flex flex-wrap gap-1.5">
              {result.cases.map((c, i) => (
                <span
                  key={i}
                  className={cn(
                    "inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium",
                    c.pass ? "bg-success/10 text-[var(--success)]" : "bg-rose-500/10 text-rose-600",
                  )}
                >
                  {c.pass ? <CheckCircle2 className="size-3" /> : <XCircle className="size-3" />}
                  {c.label}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="rounded-xl border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <h3 className="text-sm font-semibold">Today&apos;s board</h3>
          {yourRank > 0 && <span className="text-xs text-muted-foreground">You&apos;re #{yourRank}</span>}
        </div>
        <ol>
          {submissions.map((s, i) => (
            <li
              key={s.id}
              className={cn(
                "flex items-center gap-3 border-b border-border/60 px-4 py-2.5 text-sm last:border-0",
                s.author === "you" && "bg-brand-muted/40",
              )}
            >
              <span className="w-4 text-center text-xs font-semibold tabular-nums text-muted-foreground">{i + 1}</span>
              <span className="min-w-0 flex-1 truncate font-medium">
                {s.agent}
                <span className="ml-1.5 text-xs font-normal text-muted-foreground">@{s.author}</span>
              </span>
              <span className="font-mono text-xs text-muted-foreground">{s.runtimeMs.toFixed(2)}ms</span>
              <span className="w-10 text-right text-xs font-semibold tabular-nums">{s.score}</span>
            </li>
          ))}
        </ol>
      </div>
    </div>
  )
}
