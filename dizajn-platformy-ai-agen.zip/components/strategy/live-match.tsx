"use client"

import { useEffect, useRef, useState } from "react"
import { AlertTriangle, Pause, Play, RotateCcw, Terminal } from "lucide-react"
import { cn } from "@/lib/utils"
import type { StrategyMatch } from "@/lib/strategy"
import { starterStrategy } from "@/lib/strategy"

const WIDTH = 800
const HEIGHT = 450
const UNIT_R = 14
const PUCK_R = 8
const MATCH_SECONDS = 90
const SPEED = 150
const DECISION_MS = 150

type Vec = { x: number; y: number }
type Unit = { id: number; x: number; y: number; vx: number; vy: number; hp: number; respawnAt: number }
type Puck = { x: number; y: number; vx: number; vy: number }

type Move = { dx: number; dy: number }

function makeUnits(team: "A" | "B"): Unit[] {
  const x = team === "A" ? 90 : WIDTH - 90
  return [0, 1, 2].map((i) => ({
    id: i,
    x,
    y: HEIGHT / 2 + (i - 1) * 110,
    vx: 0,
    vy: 0,
    hp: 100,
    respawnAt: 0,
  }))
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v))
}

function normalize(dx: number, dy: number): Vec {
  const len = Math.hypot(dx, dy)
  if (len < 0.001) return { x: 0, y: 0 }
  return { x: dx / len, y: dy / len }
}

function defaultBot(self: Unit[], opponents: Unit[], target: Vec | null, homeX: number): Move[] {
  const t = target ?? opponents[0]
  if (!t) return self.map(() => ({ dx: 0, dy: 0 }))
  const side = homeX < t.x ? 1 : -1
  return self.map((u, i) => {
    if (i === 0) return { dx: t.x - u.x, dy: t.y - u.y }
    // Supporting units hold a flanking formation instead of stacking on the same point.
    const spread = i === 1 ? -95 : 95
    const targetX = t.x + side * -70
    return { dx: targetX - u.x, dy: t.y + spread - u.y }
  })
}

function buildState(self: Unit[], opponents: Unit[], target: Vec | null) {
  return {
    self: self.map((u) => ({ id: u.id, x: u.x, y: u.y })),
    opponents: opponents.map((u) => ({ id: u.id, x: u.x, y: u.y })),
    target: target ? { x: target.x, y: target.y } : null,
    arena: { width: WIDTH, height: HEIGHT },
  }
}

export function LiveMatch({ match }: { match: StrategyMatch }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [code, setCode] = useState(starterStrategy)
  const [error, setError] = useState<string | null>(null)
  const [deployed, setDeployed] = useState(false)
  const [running, setRunning] = useState(true)
  const [scoreA, setScoreA] = useState(0)
  const [scoreB, setScoreB] = useState(0)
  const [clock, setClock] = useState(MATCH_SECONDS)
  const [log, setLog] = useState<string[]>([`Match started: ${match.teamA.agent} vs ${match.teamB.agent}`])
  const [resetKey, setResetKey] = useState(0)

  const strategyFnRef = useRef<((state: unknown) => Move[]) | null>(null)

  const deploy = () => {
    try {
      // eslint-disable-next-line no-new-func -- sandboxed strategy runner for a demo simulation, executes only in this tab
      const factory = new Function(`${code}\nreturn strategy;`)
      const fn = factory() as (state: unknown) => Move[]
      if (typeof fn !== "function") throw new Error("Expected a `strategy` function")
      strategyFnRef.current = fn
      setError(null)
      setDeployed(true)
      setLog((l) => [`Deployed strategy for ${match.teamA.agent}`, ...l].slice(0, 8))
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to compile")
    }
  }

  const reset = () => {
    strategyFnRef.current = null
    setDeployed(false)
    setError(null)
    setScoreA(0)
    setScoreB(0)
    setClock(MATCH_SECONDS)
    setRunning(true)
    setLog([`Match started: ${match.teamA.agent} vs ${match.teamB.agent}`])
    setResetKey((k) => k + 1)
  }

  useEffect(() => {
    const unitsA = makeUnits("A")
    const unitsB = makeUnits("B")
    const puck: Puck = { x: WIDTH / 2, y: HEIGHT / 2, vx: 0, vy: 0 }
    let clockLocal = MATCH_SECONDS
    let scoreALocal = 0
    let scoreBLocal = 0
    let decisionAcc = 0
    let last = performance.now()
    let raf = 0
    let stateSyncAcc = 0
    let isRunning = true
    let localError: string | null = null

    const canvas = canvasRef.current
    const ctx = canvas?.getContext("2d")

    function pushLog(text: string) {
      setLog((l) => [text, ...l].slice(0, 8))
    }

    function decide(units: Unit[], opponents: Unit[], target: Vec | null, useUser: boolean, homeX: number): Move[] {
      if (useUser && strategyFnRef.current) {
        try {
          const state = buildState(units, opponents, target)
          const moves = strategyFnRef.current(state)
          if (!Array.isArray(moves)) throw new Error("strategy() must return an array")
          return units.map((_, i) => moves[i] ?? { dx: 0, dy: 0 })
        } catch (err) {
          localError = err instanceof Error ? err.message : "Runtime error in strategy()"
          return defaultBot(units, opponents, target, homeX)
        }
      }
      return defaultBot(units, opponents, target, homeX)
    }

    function applyMoves(units: Unit[], moves: Move[]) {
      units.forEach((u, i) => {
        if (u.respawnAt > 0) return
        const m = moves[i] ?? { dx: 0, dy: 0 }
        const n = normalize(m.dx, m.dy)
        u.vx = n.x * SPEED
        u.vy = n.y * SPEED
      })
    }

    function applyDecisions() {
      if (match.sport === "hockey") {
        const targetForA: Vec = { x: puck.x, y: puck.y }
        const targetForB: Vec = { x: puck.x, y: puck.y }
        applyMoves(unitsA, decide(unitsA, unitsB, targetForA, true, 90))
        applyMoves(unitsB, decide(unitsB, unitsA, targetForB, false, WIDTH - 90))
      } else {
        const nearestForA = unitsB.filter((u) => u.respawnAt <= 0)[0] ?? unitsB[0]
        const nearestForB = unitsA.filter((u) => u.respawnAt <= 0)[0] ?? unitsA[0]
        applyMoves(
          unitsA,
          decide(unitsA, unitsB, nearestForA ? { x: nearestForA.x, y: nearestForA.y } : null, true, 90),
        )
        applyMoves(
          unitsB,
          decide(unitsB, unitsA, nearestForB ? { x: nearestForB.x, y: nearestForB.y } : null, false, WIDTH - 90),
        )
      }
    }

    function integrate(dt: number) {
      const now = performance.now()
      for (const u of [...unitsA, ...unitsB]) {
        if (u.respawnAt > 0) {
          if (now >= u.respawnAt) {
            u.respawnAt = 0
            u.hp = 100
          }
          continue
        }
        u.x = clamp(u.x + u.vx * dt, UNIT_R, WIDTH - UNIT_R)
        u.y = clamp(u.y + u.vy * dt, UNIT_R, HEIGHT - UNIT_R)
      }

      if (match.sport === "hockey") {
        for (const u of [...unitsA, ...unitsB]) {
          if (u.respawnAt > 0) continue
          const dx = puck.x - u.x
          const dy = puck.y - u.y
          const dist = Math.hypot(dx, dy)
          if (dist < UNIT_R + PUCK_R + 4) {
            const n = normalize(dx, dy)
            puck.vx += n.x * 260 * dt
            puck.vy += n.y * 260 * dt
            puck.vx += u.vx * 0.35 * dt
            puck.vy += u.vy * 0.35 * dt
          }
        }
        puck.x += puck.vx * dt
        puck.y += puck.vy * dt
        puck.vx *= 0.985
        puck.vy *= 0.985
        if (puck.y < PUCK_R) {
          puck.y = PUCK_R
          puck.vy *= -0.8
        }
        if (puck.y > HEIGHT - PUCK_R) {
          puck.y = HEIGHT - PUCK_R
          puck.vy *= -0.8
        }
        if (puck.x < PUCK_R + 4) {
          scoreBLocal++
          setScoreB(scoreBLocal)
          pushLog(`${match.teamB.agent} scores! ${scoreALocal}-${scoreBLocal}`)
          puck.x = WIDTH / 2
          puck.y = HEIGHT / 2
          puck.vx = 0
          puck.vy = 0
        } else if (puck.x > WIDTH - PUCK_R - 4) {
          scoreALocal++
          setScoreA(scoreALocal)
          pushLog(`${match.teamA.agent} scores! ${scoreALocal}-${scoreBLocal}`)
          puck.x = WIDTH / 2
          puck.y = HEIGHT / 2
          puck.vx = 0
          puck.vy = 0
        }
      } else {
        for (const a of unitsA) {
          if (a.respawnAt > 0) continue
          for (const b of unitsB) {
            if (b.respawnAt > 0) continue
            const dist = Math.hypot(a.x - b.x, a.y - b.y)
            if (dist < 70) {
              a.hp -= 40 * dt
              b.hp -= 40 * dt
            }
          }
        }
        for (const u of unitsA) {
          if (u.respawnAt <= 0 && u.hp <= 0) {
            scoreBLocal++
            setScoreB(scoreBLocal)
            pushLog(`${match.teamB.agent} destroys a unit! ${scoreALocal}-${scoreBLocal}`)
            u.respawnAt = performance.now() + 3000
            u.x = 90
            u.y = HEIGHT / 2
          }
        }
        for (const u of unitsB) {
          if (u.respawnAt <= 0 && u.hp <= 0) {
            scoreALocal++
            setScoreA(scoreALocal)
            pushLog(`${match.teamA.agent} destroys a unit! ${scoreALocal}-${scoreBLocal}`)
            u.respawnAt = performance.now() + 3000
            u.x = WIDTH - 90
            u.y = HEIGHT / 2
          }
        }
      }
    }

    function draw() {
      if (!ctx || !canvas) return
      ctx.clearRect(0, 0, WIDTH, HEIGHT)
      ctx.fillStyle = match.sport === "hockey" ? "#eef2f7" : "#f4f1ec"
      ctx.fillRect(0, 0, WIDTH, HEIGHT)

      if (match.sport === "hockey") {
        ctx.strokeStyle = "#c7ccd4"
        ctx.lineWidth = 2
        ctx.beginPath()
        ctx.moveTo(WIDTH / 2, 0)
        ctx.lineTo(WIDTH / 2, HEIGHT)
        ctx.stroke()
        ctx.beginPath()
        ctx.arc(WIDTH / 2, HEIGHT / 2, 55, 0, Math.PI * 2)
        ctx.stroke()
        ctx.fillStyle = "rgba(37,99,235,0.12)"
        ctx.fillRect(0, 0, 14, HEIGHT)
        ctx.fillStyle = "rgba(220,38,38,0.10)"
        ctx.fillRect(WIDTH - 14, 0, 14, HEIGHT)
      } else {
        ctx.strokeStyle = "#dcd5c8"
        ctx.lineWidth = 1
        for (let gx = 0; gx <= WIDTH; gx += 40) {
          ctx.beginPath()
          ctx.moveTo(gx, 0)
          ctx.lineTo(gx, HEIGHT)
          ctx.stroke()
        }
        for (let gy = 0; gy <= HEIGHT; gy += 40) {
          ctx.beginPath()
          ctx.moveTo(0, gy)
          ctx.lineTo(WIDTH, gy)
          ctx.stroke()
        }
      }

      function drawUnit(u: Unit, color: string) {
        if (u.respawnAt > 0) return
        ctx!.beginPath()
        ctx!.arc(u.x, u.y, UNIT_R, 0, Math.PI * 2)
        ctx!.fillStyle = color
        ctx!.fill()
        if (match.sport === "tanks") {
          const pct = clamp(u.hp, 0, 100) / 100
          ctx!.fillStyle = "rgba(0,0,0,0.15)"
          ctx!.fillRect(u.x - 16, u.y - UNIT_R - 10, 32, 4)
          ctx!.fillStyle = pct > 0.4 ? "#16a34a" : "#dc2626"
          ctx!.fillRect(u.x - 16, u.y - UNIT_R - 10, 32 * pct, 4)
        }
      }

      unitsA.forEach((u) => drawUnit(u, "#2563eb"))
      unitsB.forEach((u) => drawUnit(u, "#dc2626"))

      if (match.sport === "hockey") {
        ctx.beginPath()
        ctx.arc(puck.x, puck.y, PUCK_R, 0, Math.PI * 2)
        ctx.fillStyle = "#111318"
        ctx.fill()
      }
    }

    function frame(now: number) {
      const dt = Math.min(0.05, (now - last) / 1000)
      last = now

      if (isRunning && clockLocal > 0) {
        decisionAcc += dt * 1000
        if (decisionAcc >= DECISION_MS) {
          decisionAcc = 0
          applyDecisions()
        }
        integrate(dt)
        clockLocal = Math.max(0, clockLocal - dt)
        if (clockLocal <= 0) {
          isRunning = false
          pushLog(`Full time: ${scoreALocal}-${scoreBLocal}`)
        }
      }

      draw()

      stateSyncAcc += dt * 1000
      if (stateSyncAcc >= 180) {
        stateSyncAcc = 0
        setClock(Math.ceil(clockLocal))
        setRunning(isRunning)
        if (localError) {
          setError(localError)
          localError = null
        }
      }

      raf = requestAnimationFrame(frame)
    }

    raf = requestAnimationFrame(frame)
    return () => {
      isRunning = false
      cancelAnimationFrame(raf)
    }
    // resetKey intentionally restarts the whole simulation from scratch
  }, [resetKey, match])

  const togglePause = () => setRunning((r) => !r)

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="space-y-3">
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-4 py-3">
            <div className="flex items-center gap-3 text-sm font-semibold">
              <span className="text-brand">{match.teamA.agent}</span>
              <span className="font-mono text-lg tabular-nums">{scoreA}</span>
              <span className="text-muted-foreground">–</span>
              <span className="font-mono text-lg tabular-nums">{scoreB}</span>
              <span className="text-rose-600">{match.teamB.agent}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-sm tabular-nums text-muted-foreground">
                {String(Math.floor(clock / 60)).padStart(1, "0")}:{String(clock % 60).padStart(2, "0")}
              </span>
              <button
                onClick={togglePause}
                className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs font-medium transition-colors hover:bg-muted"
              >
                {running ? <Pause className="size-3" /> : <Play className="size-3" />}
                {running ? "Pause" : "Resume"}
              </button>
              <button
                onClick={reset}
                className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs font-medium transition-colors hover:bg-muted"
              >
                <RotateCcw className="size-3" />
                Reset
              </button>
            </div>
          </div>
          <canvas ref={canvasRef} width={WIDTH} height={HEIGHT} className="block w-full" />
        </div>

        <div className="rounded-xl border border-border bg-card p-3">
          <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Match feed</h3>
          <ul className="space-y-1 font-mono text-xs text-muted-foreground">
            {log.map((line, i) => (
              <li key={i} className="truncate">
                <span className="text-muted-foreground/50">›</span> {line}
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="space-y-3">
        <div className="rounded-xl border border-border bg-card p-4">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Rules</h3>
          <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{match.rules}</p>
        </div>

        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border bg-muted/40 px-4 py-2.5">
            <span className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <Terminal className="size-3.5" />
              {match.teamA.agent}&apos;s strategy.js
            </span>
            {deployed && <span className="text-xs font-medium text-success">live</span>}
          </div>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            spellCheck={false}
            rows={13}
            className="w-full resize-none bg-transparent px-4 py-3 font-mono text-[12.5px] leading-relaxed outline-none"
          />
          <div className="flex items-center gap-2 border-t border-border bg-muted/20 px-4 py-3">
            <button
              onClick={deploy}
              className="inline-flex items-center gap-1.5 rounded-lg bg-foreground px-3 py-1.5 text-xs font-medium text-background transition-opacity hover:opacity-90"
            >
              Deploy strategy
            </button>
            {deployed && !error && <span className="text-xs text-muted-foreground">Controlling {match.teamA.agent} now</span>}
          </div>
          {error && (
            <div className="flex items-start gap-2 border-t border-border bg-rose-500/10 px-4 py-2.5 text-xs text-rose-600">
              <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
              <span className="font-mono">{error}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
