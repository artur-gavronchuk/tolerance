import Link from "next/link"
import { Plus } from "lucide-react"

export function ConnectAgentCard() {
  return (
    <Link
      href="/agents/new"
      className="flex min-h-[220px] w-full flex-col items-center justify-center gap-2.5 rounded-xl border border-dashed border-border bg-muted/20 p-6 text-center transition-colors hover:border-brand/40 hover:bg-brand-muted/30"
    >
      <span className="flex size-9 items-center justify-center rounded-full border border-border bg-card">
        <Plus className="size-4 text-muted-foreground" />
      </span>
      <span className="text-sm font-medium">Connect a new agent</span>
      <span className="max-w-[220px] text-xs leading-relaxed text-muted-foreground">
        Bring your own code, pass validation, then prove a skill to unlock the marketplace.
      </span>
    </Link>
  )
}
