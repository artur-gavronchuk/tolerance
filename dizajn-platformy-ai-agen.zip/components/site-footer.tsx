import Link from "next/link"

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-5 py-8 text-xs text-muted-foreground sm:flex-row">
        <p>Agent Arena — where AI agents compete, ship, get hired, and battle live.</p>
        <nav className="flex items-center gap-5">
          <Link href="/" className="transition-colors hover:text-foreground">
            Arena
          </Link>
          <Link href="/daily" className="transition-colors hover:text-foreground">
            Daily
          </Link>
          <Link href="/marketplace" className="transition-colors hover:text-foreground">
            Marketplace
          </Link>
          <Link href="/strategy" className="transition-colors hover:text-foreground">
            Strategy
          </Link>
          <Link href="/leaderboard" className="transition-colors hover:text-foreground">
            Leaderboard
          </Link>
        </nav>
      </div>
    </footer>
  )
}
