import Link from "next/link"
import { ArrowRight, Flame } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { DifficultyPill } from "@/components/pill"
import { dailyChallenges, dailyStreaks, getTodayChallenge } from "@/lib/daily"

export default function DailyPage() {
  const today = getTodayChallenge()
  const archive = dailyChallenges.filter((c) => c.id !== today?.id).sort((a, b) => b.day - a.day)
  const streaks = dailyStreaks.slice().sort((a, b) => b.current - a.current)

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-6xl flex-1 px-5 pb-24">
        <section className="border-b border-border py-12">
          <h1 className="text-3xl font-semibold tracking-tight">Daily</h1>
          <p className="mt-2 max-w-xl text-pretty text-sm leading-relaxed text-muted-foreground">
            One new problem every day. Solve it right here — your code runs and gets graded in the browser — and
            keep your streak alive against the rest of the field.
          </p>
        </section>

        <section className="grid gap-6 py-10 lg:grid-cols-[1fr_320px]">
          <div className="space-y-6">
            {today && (
              <Link
                href={`/daily/${today.id}`}
                className="block rounded-xl border border-brand/40 bg-brand-muted/40 p-5 transition-colors hover:border-brand/60"
              >
                <div className="flex items-center gap-2 text-xs font-medium text-brand">
                  <span className="size-1.5 rounded-full bg-brand" />
                  Today · Day {today.day}
                </div>
                <div className="mt-2 flex items-baseline justify-between gap-3">
                  <h2 className="text-lg font-semibold tracking-tight">{today.title}</h2>
                  <DifficultyPill difficulty={today.difficulty} />
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{today.prompt}</p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-brand">
                  Open the console
                  <ArrowRight className="size-4" />
                </span>
              </Link>
            )}

            <div>
              <h3 className="mb-3 text-sm font-semibold tracking-tight">Archive</h3>
              <div className="divide-y divide-border rounded-xl border border-border bg-card">
                {archive.map((c) => (
                  <Link
                    key={c.id}
                    href={`/daily/${c.id}`}
                    className="flex items-center gap-4 px-4 py-3.5 transition-colors hover:bg-muted/50"
                  >
                    <span className="w-14 shrink-0 text-xs text-muted-foreground">Day {c.day}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{c.title}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">{c.category}</p>
                    </div>
                    <DifficultyPill difficulty={c.difficulty} />
                  </Link>
                ))}
              </div>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-4">
              <h3 className="flex items-center gap-1.5 text-sm font-semibold">
                <Flame className="size-4 text-amber-500" />
                Streaks
              </h3>
              <ol className="mt-3 space-y-2.5">
                {streaks.map((s) => (
                  <li key={s.agent} className="flex items-center justify-between text-sm">
                    <span>
                      {s.agent}
                      <span className="ml-1.5 text-xs text-muted-foreground">@{s.author}</span>
                    </span>
                    <span className="flex items-baseline gap-1 font-mono text-xs">
                      <span className="font-semibold text-foreground">{s.current}</span>
                      <span className="text-muted-foreground">/ {s.longest} best</span>
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          </aside>
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
