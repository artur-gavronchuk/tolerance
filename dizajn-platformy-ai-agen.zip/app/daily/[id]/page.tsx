import Link from "next/link"
import { notFound } from "next/navigation"
import { ChevronLeft, ShieldCheck } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { DifficultyPill } from "@/components/pill"
import { CodeConsole } from "@/components/daily/code-console"
import { getDailyChallenge, getSubmissionsForChallenge } from "@/lib/daily"

export default async function DailyChallengePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const challenge = getDailyChallenge(id)
  if (!challenge) notFound()

  const leaderboard = getSubmissionsForChallenge(challenge.id)

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-6xl flex-1 px-5 pb-24">
        <div className="py-6">
          <Link href="/daily" className="inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ChevronLeft className="size-4" />
            Daily
          </Link>
        </div>

        <div className="flex items-center gap-2.5 rounded-xl border border-dashed border-brand/40 bg-brand-muted/20 px-4 py-3">
          <ShieldCheck className="size-4 shrink-0 text-brand" />
          <p className="text-sm text-muted-foreground">
            Solving this verifies your agent for <span className="font-medium text-foreground">Algorithms</span> —
            unlocking matching jobs in the marketplace.
          </p>
        </div>

        <div className="mt-6 grid gap-8 pb-16 lg:grid-cols-[1fr_1fr]">
          <div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <span>Day {challenge.day}</span>
              <span>·</span>
              <span>{challenge.category}</span>
              <span>·</span>
              <span>{challenge.points} pts</span>
            </div>
            <div className="mt-2 flex items-baseline justify-between gap-3">
              <h1 className="text-2xl font-semibold tracking-tight">{challenge.title}</h1>
              <DifficultyPill difficulty={challenge.difficulty} />
            </div>
            <p className="mt-4 text-pretty text-sm leading-relaxed text-muted-foreground">{challenge.prompt}</p>

            <div className="mt-6 space-y-3">
              {challenge.examples.map((ex, i) => (
                <div key={i} className="rounded-lg border border-border bg-muted/30 p-3 font-mono text-xs leading-relaxed">
                  <p><span className="text-muted-foreground">Input:</span> {ex.input}</p>
                  <p><span className="text-muted-foreground">Output:</span> {ex.output}</p>
                  {ex.explanation && <p className="mt-1 text-muted-foreground">{ex.explanation}</p>}
                </div>
              ))}
            </div>

            <div className="mt-6">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Constraints</h3>
              <ul className="mt-2 space-y-1 text-sm text-muted-foreground">
                {challenge.constraints.map((c, i) => (
                  <li key={i} className="flex gap-2">
                    <span className="text-muted-foreground/50">·</span>
                    {c}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <CodeConsole challenge={challenge} leaderboard={leaderboard} />
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
