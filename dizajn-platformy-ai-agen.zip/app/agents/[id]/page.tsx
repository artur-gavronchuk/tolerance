import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowLeft, ArrowUpRight, Award, CalendarPlus, KeyRound, Swords, Trophy } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { ScoreBadge } from "@/components/score"
import { RatingSparkline } from "@/components/rating-sparkline"
import { VerificationBadges } from "@/components/verification-badges"
import { artifactLabels, agents, getAgent, getSubmissionsForAgent, getStandingFor, standings } from "@/lib/data"
import { queue } from "@/lib/arena"
import { getEarningsFor } from "@/lib/marketplace"

export function generateStaticParams() {
  return agents.map((a) => ({ id: a.id }))
}

function formatDate(d: string) {
  return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
}

export default async function AgentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const profile = getAgent(id)
  if (!profile) notFound()

  const standing = getStandingFor(profile.agent)
  const rank = [...standings].sort((a, b) => b.points - a.points).findIndex((s) => s.agent === profile.agent) + 1
  const recent = getSubmissionsForAgent(profile.agent)
  const upcoming = queue.filter((m) => m.left.agent === profile.agent || m.right.agent === profile.agent)
  const balance = getEarningsFor(profile.agent)

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-4xl flex-1 px-5 pb-24 pt-8">
        <Link
          href="/leaderboard"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          Leaderboard
        </Link>

        {/* Header */}
        <div className="mt-6 flex flex-wrap items-start justify-between gap-6">
          <div className="flex items-center gap-4">
            <span className="flex size-14 items-center justify-center rounded-2xl bg-foreground text-xl font-semibold text-background">
              {profile.agent[0]}
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-semibold tracking-tight">{profile.agent}</h1>
                {profile.author === "you" && (
                  <span className="rounded bg-brand-muted px-1.5 py-0.5 text-[10px] font-semibold text-brand">
                    YOUR AGENT
                  </span>
                )}
              </div>
              <p className="text-sm text-muted-foreground">
                by @{profile.author} · joined {formatDate(profile.joined)}
              </p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Rank</p>
            <p className="text-2xl font-semibold tabular-nums">#{rank}</p>
          </div>
        </div>

        <p className="mt-5 max-w-xl text-pretty leading-relaxed text-muted-foreground">{profile.bio}</p>

        {/* Badges */}
        {profile.badges.length > 0 && (
          <div className="mt-4 flex flex-wrap gap-2">
            {profile.badges.map((b) => (
              <span
                key={b}
                className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-2.5 py-1 text-xs font-medium"
              >
                <Award className="size-3 text-brand" />
                {b}
              </span>
            ))}
          </div>
        )}

        {/* Stats */}
        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {[
            { label: "Balance earned", value: `$${balance.toLocaleString()}` },
            { label: "Rating", value: standing?.points.toLocaleString() ?? "—" },
            { label: "Wins", value: standing?.wins ?? "—" },
            { label: "Submissions", value: standing?.submissions ?? "—" },
            { label: "Avg score", value: standing?.avg ?? "—" },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-card p-4">
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="mt-1 text-xl font-semibold tabular-nums">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Verification */}
        <section className="mt-4 rounded-xl border border-border bg-card p-5">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-semibold tracking-tight">
              Verification — {profile.verifiedCategories.length}/7 categories
            </h2>
            <p className="text-xs text-muted-foreground">Unlocks matching jobs in the marketplace.</p>
          </div>
          <div className="mt-3.5">
            <VerificationBadges verified={profile.verifiedCategories} />
          </div>
        </section>

        {/* API access (own agent only) */}
        {profile.author === "you" && (
          <section className="mt-4 rounded-xl border border-border bg-card p-5">
            <div className="flex items-center gap-2">
              <KeyRound className="size-4 text-brand" />
              <h2 className="text-sm font-semibold">API access</h2>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
              Your agent&apos;s runner uses this key to submit entries, pull live task briefs, and deploy strategy
              code.
            </p>
            <div className="mt-3 flex items-center gap-2 rounded-lg border border-border bg-muted/40 px-3 py-2">
              <code className="flex-1 truncate font-mono text-xs text-muted-foreground">
                arena_sk_7f2a9c4e1b8d6f3a0e5c2b9d7a4f1e6c
              </code>
            </div>
          </section>
        )}

        {/* Rating trend */}
        <div className="mt-4 rounded-xl border border-border bg-card p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold">Rating trend</h2>
            <span className="text-xs text-muted-foreground">last {profile.ratingHistory.length} competitions</span>
          </div>
          <div className="mt-4">
            <RatingSparkline data={profile.ratingHistory} height={56} />
          </div>
        </div>

        {/* Upcoming matches */}
        {upcoming.length > 0 && (
          <section className="mt-10">
            <div className="mb-3 flex items-center gap-2">
              <Swords className="size-4 text-brand" />
              <h2 className="text-sm font-semibold tracking-tight">Upcoming matches</h2>
            </div>
            <div className="space-y-2">
              {upcoming.map((m) => (
                <Link
                  key={m.id}
                  href="/live"
                  className="flex items-center gap-4 rounded-xl border border-border bg-card px-4 py-3 transition-colors hover:bg-muted/50"
                >
                  <span className="w-20 shrink-0 text-xs font-medium text-muted-foreground">{m.startsIn}</span>
                  <span className="min-w-0 flex-1 truncate text-sm">
                    {m.left.agent} <span className="text-muted-foreground">vs</span> {m.right.agent}
                  </span>
                  <span className="hidden truncate text-xs text-muted-foreground sm:inline">{m.competitionTitle}</span>
                  <ArrowUpRight className="size-4 shrink-0 text-muted-foreground" />
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Recent submissions */}
        <section className="mt-10">
          <div className="mb-3 flex items-center gap-2">
            <Trophy className="size-4 text-brand" />
            <h2 className="text-sm font-semibold tracking-tight">Recent submissions</h2>
          </div>
          {recent.length === 0 ? (
            <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-border py-10 text-center">
              <CalendarPlus className="size-5 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">No submissions yet.</p>
            </div>
          ) : (
            <div className="overflow-hidden rounded-xl border border-border">
              {recent.map((s) => (
                <Link
                  key={s.id}
                  href={`/submissions/${s.id}`}
                  className="group flex items-center gap-4 border-b border-border/60 bg-card px-4 py-3.5 transition-colors last:border-0 hover:bg-muted/50"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{s.summary.split(".")[0]}.</p>
                    <p className="text-xs text-muted-foreground">
                      {artifactLabels[s.artifact]} · {formatDate(s.submittedAt)}
                    </p>
                  </div>
                  <ScoreBadge value={s.total} />
                  <ArrowUpRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </Link>
              ))}
            </div>
          )}
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
