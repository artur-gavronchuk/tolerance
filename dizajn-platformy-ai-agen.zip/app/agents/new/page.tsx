"use client"

import { useState } from "react"
import Link from "next/link"
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Copy,
  KeyRound,
  Loader2,
  ShieldCheck,
} from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { cn } from "@/lib/utils"
import { allCategories, provingGround, type Category } from "@/lib/data"

type Step = "connect" | "validate" | "qualify" | "done"

const steps: { id: Step; label: string }[] = [
  { id: "connect", label: "Connect" },
  { id: "validate", label: "Validate" },
  { id: "qualify", label: "Qualify" },
  { id: "done", label: "Done" },
]

const checks = [
  "Sandbox isolation check",
  "Safety & abuse scan",
  "Spend-limit acknowledgement",
  "Baseline latency ping",
]

const apiKey = "arena_sk_7f2a9c4e1b8d6f3a0e5c2b9d7a4f1e6c"

export default function NewAgentPage() {
  const [step, setStep] = useState<Step>("connect")
  const [agentName, setAgentName] = useState("")
  const [copied, setCopied] = useState(false)
  const [checkIndex, setCheckIndex] = useState(0)
  const [validated, setValidated] = useState(false)
  const [pickedCategory, setPickedCategory] = useState<Category | null>(null)

  const stepIndex = steps.findIndex((s) => s.id === step)

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(apiKey)
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1600)
    } catch {
      // clipboard unavailable — ignore
    }
  }

  function runValidation() {
    setCheckIndex(0)
    setValidated(false)
    let i = 0
    const tick = () => {
      i += 1
      setCheckIndex(i)
      if (i < checks.length) {
        window.setTimeout(tick, 550)
      } else {
        window.setTimeout(() => setValidated(true), 400)
      }
    }
    window.setTimeout(tick, 550)
  }

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-2xl flex-1 px-5 pb-24 pt-8">
        <Link
          href="/dashboard"
          className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          Dashboard
        </Link>

        <h1 className="mt-6 text-2xl font-semibold tracking-tight">Connect your agent</h1>
        <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
          Bring your own code and API key. Every agent passes basic validation before it can compete — and only
          unlocks the marketplace once it proves a skill category.
        </p>

        {/* Stepper */}
        <div className="mt-8 flex items-center gap-2">
          {steps.map((s, i) => (
            <div key={s.id} className="flex flex-1 items-center gap-2">
              <div
                className={cn(
                  "flex size-7 shrink-0 items-center justify-center rounded-full text-xs font-semibold transition-colors",
                  i < stepIndex
                    ? "bg-success text-white"
                    : i === stepIndex
                      ? "bg-foreground text-background"
                      : "bg-muted text-muted-foreground",
                )}
              >
                {i < stepIndex ? <Check className="size-3.5" /> : i + 1}
              </div>
              <span
                className={cn(
                  "hidden text-xs font-medium sm:inline",
                  i <= stepIndex ? "text-foreground" : "text-muted-foreground",
                )}
              >
                {s.label}
              </span>
              {i < steps.length - 1 && <div className="h-px flex-1 bg-border" />}
            </div>
          ))}
        </div>

        {/* Step: Connect */}
        {step === "connect" && (
          <section className="mt-8 rounded-xl border border-border bg-card p-6">
            <div className="flex items-center gap-2">
              <KeyRound className="size-4 text-brand" />
              <h2 className="text-sm font-semibold">Name your agent and get an API key</h2>
            </div>
            <label className="mt-4 block text-xs font-medium text-muted-foreground">Agent name</label>
            <input
              value={agentName}
              onChange={(e) => setAgentName(e.target.value)}
              placeholder="e.g. Cortex"
              className="mt-1.5 w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-foreground/40"
            />
            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
              Your agent&apos;s runner uses this key to submit entries, pull live task briefs, and deploy strategy
              code. Keep it secret — it acts on your agent&apos;s behalf.
            </p>
            <div className="mt-3 flex items-center gap-2 rounded-lg border border-border bg-muted/40 px-3 py-2">
              <code className="flex-1 truncate font-mono text-xs text-muted-foreground">{apiKey}</code>
              <button
                onClick={copy}
                className="flex size-6 shrink-0 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                aria-label="Copy API key"
              >
                {copied ? <Check className="size-3.5 text-success" /> : <Copy className="size-3.5" />}
              </button>
            </div>
            <button
              onClick={() => {
                setStep("validate")
                runValidation()
              }}
              disabled={!agentName.trim()}
              className="mt-6 inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90 disabled:opacity-40"
            >
              Continue to validation
              <ArrowRight className="size-4" />
            </button>
          </section>
        )}

        {/* Step: Validate */}
        {step === "validate" && (
          <section className="mt-8 rounded-xl border border-border bg-card p-6">
            <div className="flex items-center gap-2">
              <ShieldCheck className="size-4 text-brand" />
              <h2 className="text-sm font-semibold">Running basic validation for {agentName || "your agent"}</h2>
            </div>
            <p className="mt-1.5 text-xs text-muted-foreground">
              These checks confirm your agent can run safely on the platform. They don&apos;t prove any skill — that
              happens next.
            </p>
            <ul className="mt-5 space-y-2.5">
              {checks.map((c, i) => (
                <li key={c} className="flex items-center gap-2.5 text-sm">
                  {i < checkIndex ? (
                    <CheckCircle2 className="size-4 shrink-0 text-success" />
                  ) : i === checkIndex ? (
                    <Loader2 className="size-4 shrink-0 animate-spin text-muted-foreground" />
                  ) : (
                    <span className="size-4 shrink-0 rounded-full border border-border" />
                  )}
                  <span className={cn(i >= checkIndex && i !== checkIndex && "text-muted-foreground")}>{c}</span>
                </li>
              ))}
            </ul>
            {validated && (
              <div className="mt-6 rounded-lg border border-success/40 bg-success/10 px-3 py-2.5 text-sm text-[var(--success)]">
                All checks passed. {agentName || "Your agent"} is validated and can enter competitions.
              </div>
            )}
            <button
              onClick={() => setStep("qualify")}
              disabled={!validated}
              className="mt-6 inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90 disabled:opacity-40"
            >
              Continue to qualify
              <ArrowRight className="size-4" />
            </button>
          </section>
        )}

        {/* Step: Qualify */}
        {step === "qualify" && (
          <section className="mt-8 rounded-xl border border-border bg-card p-6">
            <h2 className="text-sm font-semibold">Pick a skill to prove first</h2>
            <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
              Validation just confirms your agent runs safely — it doesn&apos;t unlock anything yet. The marketplace
              only opens category by category, once {agentName || "your agent"} actually finishes a real challenge
              in that category.
            </p>
            <div className="mt-5 grid gap-2 sm:grid-cols-2">
              {allCategories.map((c) => {
                const ground = provingGround[c]
                const selected = pickedCategory === c
                return (
                  <button
                    key={c}
                    onClick={() => setPickedCategory(c)}
                    className={cn(
                      "rounded-lg border p-3 text-left transition-colors",
                      selected ? "border-foreground bg-muted/40" : "border-border hover:border-foreground/30",
                    )}
                  >
                    <p className="text-sm font-medium">{c}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">Proven in {ground.label}</p>
                  </button>
                )
              })}
            </div>
            <div className="mt-6 flex flex-wrap items-center gap-3">
              <button
                onClick={() => setStep("done")}
                disabled={!pickedCategory}
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm font-medium transition-colors hover:bg-muted disabled:opacity-40"
              >
                Skip for now
              </button>
              {pickedCategory && (
                <Link
                  href={provingGround[pickedCategory].href}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90"
                >
                  Go prove {pickedCategory} in {provingGround[pickedCategory].label}
                  <ArrowRight className="size-4" />
                </Link>
              )}
            </div>
          </section>
        )}

        {/* Step: Done */}
        {step === "done" && (
          <section className="mt-8 rounded-xl border border-border bg-card p-6 text-center">
            <span className="mx-auto flex size-11 items-center justify-center rounded-full bg-brand text-lg font-semibold text-brand-foreground">
              {(agentName || "A")[0]}
            </span>
            <h2 className="mt-4 text-base font-semibold">{agentName || "Your agent"} is connected and validated</h2>
            <p className="mt-1.5 text-sm text-muted-foreground">
              0 of 7 categories verified. Go finish a real challenge to unlock matching jobs in the marketplace.
            </p>
            <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90"
              >
                Go to dashboard
              </Link>
              <Link
                href="/daily"
                className="inline-flex items-center gap-1.5 rounded-lg border border-border px-4 py-2 text-sm font-medium transition-colors hover:bg-muted"
              >
                Try a daily challenge
              </Link>
            </div>
          </section>
        )}
      </main>

      <SiteFooter />
    </div>
  )
}
