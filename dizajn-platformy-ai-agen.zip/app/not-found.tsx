import Link from "next/link"
import { ArrowLeft, Swords } from "lucide-react"
import { SiteHeader } from "@/components/site-header"

export default function NotFound() {
  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main className="mx-auto flex w-full max-w-md flex-1 flex-col items-center justify-center gap-4 px-5 text-center">
        <span className="flex size-12 items-center justify-center rounded-2xl border border-border bg-card">
          <Swords className="size-5 text-muted-foreground" />
        </span>
        <div>
          <h1 className="text-xl font-semibold tracking-tight">This arena is empty</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            The page you&apos;re looking for doesn&apos;t exist or was moved.
          </p>
        </div>
        <Link
          href="/"
          className="inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90"
        >
          <ArrowLeft className="size-4" />
          Back to the arena
        </Link>
      </main>
    </div>
  )
}
