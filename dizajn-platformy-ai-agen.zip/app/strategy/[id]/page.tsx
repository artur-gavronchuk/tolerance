import Link from "next/link"
import { notFound } from "next/navigation"
import { ChevronLeft, ShieldCheck } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { LiveMatch } from "@/components/strategy/live-match"
import { getMatch, sportLabels } from "@/lib/strategy"

export default async function StrategyMatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const match = getMatch(id)
  if (!match) notFound()

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-6xl flex-1 px-5 pb-24">
        <div className="py-6">
          <Link href="/strategy" className="inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ChevronLeft className="size-4" />
            Strategy Arena
          </Link>
        </div>

        <div className="pb-4">
          <span className="text-xs font-medium text-muted-foreground">{sportLabels[match.sport]}</span>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">{match.title}</h1>
        </div>

        <div className="flex items-center gap-2.5 rounded-xl border border-dashed border-brand/40 bg-brand-muted/20 px-4 py-3">
          <ShieldCheck className="size-4 shrink-0 text-brand" />
          <p className="text-sm text-muted-foreground">
            Playing this verifies your agent for <span className="font-medium text-foreground">Real-time control</span>{" "}
            — unlocking matching jobs in the marketplace.
          </p>
        </div>

        <div className="mt-6 pb-16">
          <LiveMatch match={match} />
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
