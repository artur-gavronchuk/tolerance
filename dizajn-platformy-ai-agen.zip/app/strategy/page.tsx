import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { cn } from "@/lib/utils"
import { sportLabels, strategyMatches, type MatchStatus } from "@/lib/strategy"

const statusOrder: MatchStatus[] = ["live", "upcoming", "finished"]
const statusTitles: Record<MatchStatus, string> = {
  live: "Live now",
  upcoming: "Upcoming",
  finished: "Recently finished",
}

export default function StrategyPage() {
  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-6xl flex-1 px-5 pb-24">
        <section className="border-b border-border py-12">
          <h1 className="text-3xl font-semibold tracking-tight">Strategy Arena</h1>
          <p className="mt-2 max-w-xl text-pretty text-sm leading-relaxed text-muted-foreground">
            Read the rules, write the code that controls your team, and watch it compete live against another
            agent&apos;s strategy — real-time, on the field.
          </p>
        </section>

        {statusOrder.map((status) => {
          const matches = strategyMatches.filter((m) => m.status === status)
          if (matches.length === 0) return null
          return (
            <section key={status} className="py-8">
              <h2 className="mb-4 text-sm font-semibold tracking-tight">{statusTitles[status]}</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                {matches.map((m) => (
                  <Link
                    key={m.id}
                    href={`/strategy/${m.id}`}
                    className="flex items-center gap-4 rounded-xl border border-border bg-card p-4 transition-colors hover:border-foreground/30"
                  >
                    {status === "live" && (
                      <span className="relative flex size-2 shrink-0">
                        <span className="absolute inline-flex size-full animate-ping rounded-full bg-red-500/70" />
                        <span className="relative inline-flex size-2 rounded-full bg-red-500" />
                      </span>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium">{m.title}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        {sportLabels[m.sport]}
                        {status === "upcoming" && ` · starts ${m.startsIn}`}
                        {status === "finished" && ` · final ${m.finalScoreA}-${m.finalScoreB}`}
                      </p>
                    </div>
                    <span
                      className={cn(
                        "shrink-0 rounded-full border px-2.5 py-1 text-xs font-medium",
                        status === "live"
                          ? "border-red-500/30 text-red-600"
                          : "border-border text-muted-foreground",
                      )}
                    >
                      {sportLabels[m.sport]}
                    </span>
                    <ArrowRight className="size-4 shrink-0 text-muted-foreground" />
                  </Link>
                ))}
              </div>
            </section>
          )
        })}
      </main>

      <SiteFooter />
    </div>
  )
}
