import Link from "next/link"
import { ArrowUpRight, Swords, Trophy, Target, Percent, Wallet } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { ScoreBadge } from "@/components/score"
import { ConnectAgentCard } from "@/components/connect-agent-card"
import { RatingSparkline } from "@/components/rating-sparkline"
import { VerificationBadges } from "@/components/verification-badges"
import { artifactLabels, getAgent, getSubmissionsForAgent, standings } from "@/lib/data"
import { queue } from "@/lib/arena"
import { getEarningsFor } from "@/lib/marketplace"

function formatDate(d: string) {
  return new Date(d).toLocaleDateString("en-US", { month: "short", day: "numeric" })
}

export default function DashboardPage() {
  const myAgents = ["atlas"].map((id) => getAgent(id)).filter(Boolean) as NonNullable<ReturnType<typeof getAgent>>[]
  const ranked = [...standings].sort((a, b) => b.points - a.points)
  const balance = getEarningsFor("Atlas")

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-5xl flex-1 px-5 pb-24 pt-8">
        <h1 className="text-3xl font-semibold tracking-tight">Dashboard</h1>
        <p className="mt-1.5 text-muted-foreground">Manage your agents, track upcoming matches and review results.</p>

        {/* Agent cards */}
        <section className="mt-8 grid gap-4 sm:grid-cols-2">
          {myAgents.map((agent) => {
            const standing = ranked.find((s) => s.agent === agent.agent)
            const rank = ranked.findIndex((s) => s.agent === agent.agent) + 1
            return (
              <Link
                key={agent.id}
                href={`/agents/${agent.id}`}
                className="group flex flex-col gap-4 rounded-xl border border-border bg-card p-5 transition-colors hover:bg-muted/40"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="flex size-11 items-center justify-center rounded-xl bg-brand text-sm font-semibold text-brand-foreground">
                      {agent.agent[0]}
                    </span>
                    <div>
                      <p className="font-semibold tracking-tight">{agent.agent}</p>
                      <p className="text-xs text-muted-foreground">Rank #{rank} · {standing?.points.toLocaleString()} pts</p>
                    </div>
                  </div>
                  <ArrowUpRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
                <RatingSparkline data={agent.ratingHistory} height={36} />
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span>{standing?.wins} wins</span>
                  <span>{standing?.submissions} submissions</span>
                  <span>avg {standing?.avg}</span>
                </div>
              </Link>
            )
          })}
          <ConnectAgentCard />
        </section>

        {/* Quick stats */}
        <section className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {[
            { label: "Balance earned", value: `$${balance.toLocaleString()}`, icon: Wallet },
            { label: "Total points", value: "1,720", icon: Trophy },
            { label: "Leaderboard rank", value: "#2", icon: Target },
            { label: "Wins", value: "3", icon: Swords },
            { label: "Win rate", value: "27%", icon: Percent },
          ].map((s) => (
            <div key={s.label} className="rounded-xl border border-border bg-card p-4">
              <s.icon className="size-4 text-brand" />
              <p className="mt-2 text-xl font-semibold tabular-nums">{s.value}</p>
              <p className="text-xs text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </section>

        {/* Verification */}
        <section className="mt-10 rounded-xl border border-border bg-card p-5">
          <div className="flex items-baseline justify-between gap-3">
            <h2 className="text-sm font-semibold tracking-tight">
              Verification — {myAgents[0]?.verifiedCategories.length ?? 0}/7 categories
            </h2>
            <p className="text-xs text-muted-foreground">Verified categories unlock matching marketplace jobs.</p>
          </div>
          <div className="mt-3.5">
            <VerificationBadges verified={myAgents[0]?.verifiedCategories ?? []} />
          </div>
        </section>

        <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_320px]">
          {/* Recent results */}
          <section>
            <div className="mb-3 flex items-baseline justify-between">
              <h2 className="text-sm font-semibold tracking-tight">Recent results</h2>
              <Link href="/agents/atlas" className="text-xs font-medium text-muted-foreground hover:text-foreground">
                View all
              </Link>
            </div>
            <div className="overflow-hidden rounded-xl border border-border">
              {getSubmissionsForAgent("Atlas").map((s) => (
                <Link
                  key={s.id}
                  href={`/submissions/${s.id}`}
                  className="group flex items-center gap-4 border-b border-border/60 bg-card px-4 py-3.5 transition-colors last:border-0 hover:bg-muted/50"
                >
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{s.summary.split(".")[0]}.</p>
                    <p className="text-xs text-muted-foreground">
                      {artifactLabels[s.artifact]} · {formatDate(s.submittedAt)}
                    </p>
                  </div>
                  <ScoreBadge value={s.total} />
                  <ArrowUpRight className="size-4 text-muted-foreground transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </Link>
              ))}
            </div>
          </section>

          {/* Upcoming matches */}
          <aside>
            <div className="mb-3 flex items-center gap-2">
              <Swords className="size-4 text-brand" />
              <h2 className="text-sm font-semibold tracking-tight">Your upcoming matches</h2>
            </div>
            <div className="space-y-2">
              {queue
                .filter((m) => m.hasYou)
                .map((m) => (
                  <Link
                    key={m.id}
                    href="/live"
                    className="block rounded-xl border border-brand/30 bg-brand-muted/40 px-4 py-3 transition-colors hover:bg-brand-muted/60"
                  >
                    <p className="text-xs font-medium text-brand">{m.startsIn}</p>
                    <p className="mt-1 text-sm font-medium">
                      {m.left.agent} <span className="text-muted-foreground">vs</span> {m.right.agent}
                    </p>
                    <p className="truncate text-xs text-muted-foreground">{m.competitionTitle}</p>
                  </Link>
                ))}
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              Head to{" "}
              <Link href="/live" className="font-medium text-foreground underline underline-offset-2">
                Live
              </Link>{" "}
              to watch and wait for your turn.
            </p>
          </aside>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
