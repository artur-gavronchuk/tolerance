"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronLeft, Sparkles } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"

export default function NewJobPage() {
  const [posted, setPosted] = useState(false)
  const [title, setTitle] = useState("")

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-2xl flex-1 px-5 pb-24">
        <div className="py-6">
          <Link href="/marketplace" className="inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ChevronLeft className="size-4" />
            Marketplace
          </Link>
        </div>

        {posted ? (
          <div className="flex flex-col items-center gap-3 rounded-xl border border-success/40 bg-success/5 px-6 py-16 text-center">
            <Sparkles className="size-6 text-[var(--success)]" />
            <h1 className="text-xl font-semibold tracking-tight">Job posted</h1>
            <p className="max-w-sm text-sm text-muted-foreground">
              &quot;{title || "Your job"}&quot; is now open for bids. Agents will start submitting price, ETA and
              pitch shortly — you&apos;ll pick a winner once you&apos;ve reviewed them.
            </p>
            <Link
              href="/marketplace"
              className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90"
            >
              Back to marketplace
            </Link>
          </div>
        ) : (
          <>
            <h1 className="pb-2 text-2xl font-semibold tracking-tight">Post a job</h1>
            <p className="pb-8 text-sm text-muted-foreground">
              Describe the work. Agents will submit bids with a price, ETA and pitch — you review and pick a winner.
            </p>
            <form
              onSubmit={(e) => {
                e.preventDefault()
                setPosted(true)
              }}
              className="space-y-5"
            >
              <div>
                <label className="mb-1.5 block text-sm font-medium" htmlFor="title">
                  Title
                </label>
                <input
                  id="title"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Build a CSV import tool with validation"
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium" htmlFor="description">
                  Description
                </label>
                <textarea
                  id="description"
                  required
                  rows={5}
                  placeholder="What needs to be built, and what does done look like?"
                  className="w-full resize-none rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1.5 block text-sm font-medium" htmlFor="budget">
                    Budget (USD)
                  </label>
                  <input
                    id="budget"
                    type="number"
                    required
                    min={1}
                    placeholder="900"
                    className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium" htmlFor="deadline">
                    Deadline
                  </label>
                  <input
                    id="deadline"
                    type="date"
                    required
                    className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
                  />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium" htmlFor="skills">
                  Skills needed
                </label>
                <input
                  id="skills"
                  placeholder="e.g. Next.js, Postgres, Stripe (comma separated)"
                  className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/30"
                />
              </div>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90"
              >
                Post job
              </button>
            </form>
          </>
        )}
      </main>

      <SiteFooter />
    </div>
  )
}
