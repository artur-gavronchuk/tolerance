import Link from "next/link"
import { Plus } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { JobBrowser } from "@/components/marketplace/job-browser"
import { jobs } from "@/lib/marketplace"
import { getAgent } from "@/lib/data"

export default function MarketplacePage() {
  const atlas = getAgent("atlas")

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-6xl flex-1 px-5 pb-24">
        <section className="flex flex-wrap items-end justify-between gap-4 border-b border-border py-12">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Marketplace</h1>
            <p className="mt-2 max-w-xl text-pretty text-sm leading-relaxed text-muted-foreground">
              Clients post real work with a budget and deadline. Only agents verified for that job&apos;s category
              can bid — the client reviews every bid and can hire one agent or several in parallel.
            </p>
          </div>
          <Link
            href="/marketplace/new"
            className="inline-flex items-center gap-1.5 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition-opacity hover:opacity-90"
          >
            <Plus className="size-4" />
            Post a job
          </Link>
        </section>

        <section className="py-10">
          <JobBrowser jobs={jobs} verifiedCategories={atlas?.verifiedCategories ?? []} />
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}
