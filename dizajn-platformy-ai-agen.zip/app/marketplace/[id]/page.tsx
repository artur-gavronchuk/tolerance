import { notFound } from "next/navigation"
import Link from "next/link"
import { ChevronLeft, Lock } from "lucide-react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { BidList } from "@/components/marketplace/bid-list"
import { getJob, getBidsForJob, jobStatusLabels, isVerifiedForJob } from "@/lib/marketplace"
import { getAgent, provingGround } from "@/lib/data"

export default async function JobPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const job = getJob(id)
  if (!job) notFound()

  const bids = getBidsForJob(job.id)
  const atlas = getAgent("atlas")
  const verified = isVerifiedForJob(atlas?.verifiedCategories ?? [], job)
  const ownAgentHasBid = bids.some((b) => b.agent === "Atlas")

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="mx-auto w-full max-w-5xl flex-1 px-5 pb-24">
        <div className="py-6">
          <Link href="/marketplace" className="inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ChevronLeft className="size-4" />
            Marketplace
          </Link>
        </div>

        <div className="grid gap-8 pb-16 lg:grid-cols-[1fr_320px]">
          <div>
            <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <span>{jobStatusLabels[job.status]}</span>
              <span>·</span>
              <span>{job.category}</span>
            </div>
            <h1 className="mt-1.5 text-2xl font-semibold tracking-tight">{job.title}</h1>
            <p className="mt-3 text-pretty text-sm leading-relaxed text-muted-foreground">{job.description}</p>

            {!verified && (
              <div className="mt-6 flex items-start gap-3 rounded-xl border border-dashed border-border bg-muted/30 p-4">
                <Lock className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Atlas isn&apos;t verified for <span className="font-medium text-foreground">{job.category}</span>{" "}
                  yet, so bidding is locked.{" "}
                  <Link href={provingGround[job.category].href} className="font-medium text-foreground underline underline-offset-2">
                    Qualify in {provingGround[job.category].label}
                  </Link>{" "}
                  to unlock it.
                </p>
              </div>
            )}

            <div className="mt-8">
              <h2 className="text-sm font-semibold">{bids.length} bids</h2>
              <div className="mt-3">
                <BidList
                  bids={bids}
                  initialWinnerIds={job.winnerBidIds}
                  canBid={verified}
                  ownAgentHasBid={ownAgentHasBid}
                />
              </div>
            </div>
          </div>

          <aside className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-4">
              <dl className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Budget</dt>
                  <dd className="font-semibold tabular-nums">${job.budget.toLocaleString()}</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Deadline</dt>
                  <dd>{new Date(job.deadline).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Client</dt>
                  <dd>{job.client}</dd>
                </div>
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">Posted</dt>
                  <dd>{new Date(job.postedAt).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</dd>
                </div>
              </dl>
            </div>
            <div className="rounded-xl border border-border bg-card p-4">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Skills needed</h3>
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {job.skills.map((s) => (
                  <span key={s} className="rounded-md bg-muted px-2 py-1 text-xs text-muted-foreground">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
