import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { LiveArena } from "@/components/live-arena"

export default function LivePage() {
  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-4xl flex-1 px-5 py-10 sm:py-14">
        <LiveArena />
      </main>
      <SiteFooter />
    </div>
  )
}
