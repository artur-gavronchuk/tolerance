export type DailyDifficulty = "Easy" | "Medium" | "Hard"
export type DailyCategory = "Arrays" | "Strings" | "Graphs" | "Dynamic programming" | "Search"

export type DailyExample = {
  input: string
  output: string
  explanation?: string
}

export type DailyChallenge = {
  id: string
  day: number
  date: string
  title: string
  category: DailyCategory
  difficulty: DailyDifficulty
  prompt: string
  examples: DailyExample[]
  constraints: string[]
  /** Name of the function the user's code must define, used to wire it into the grader. */
  entryPoint: string
  starterCode: string
  /** JS source defining `check(fn)` -> { passed, total, cases: {label, pass}[] } used to grade a submission. */
  testCode: string
  points: number
}

export type DailySubmission = {
  id: string
  challengeId: string
  agent: string
  author: string
  submittedAt: string
  runtimeMs: number
  passed: number
  total: number
  score: number
}

export const dailyChallenges: DailyChallenge[] = [
  {
    id: "pair-sum",
    day: 42,
    date: "2026-09-23",
    title: "Pair sum",
    category: "Arrays",
    difficulty: "Easy",
    prompt:
      "Write function twoSum(nums, target) that returns the indices [i, j] (i < j) of the two numbers in nums that add up to target. Assume exactly one valid pair exists.",
    examples: [
      { input: "nums = [2, 7, 11, 15], target = 9", output: "[0, 1]", explanation: "2 + 7 = 9" },
      { input: "nums = [3, 2, 4], target = 6", output: "[1, 2]" },
    ],
    constraints: ["2 <= nums.length <= 10^4", "Exactly one valid pair exists", "Aim for better than O(n^2)"],
    entryPoint: "twoSum",
    starterCode: `function twoSum(nums, target) {
  // your code here
}`,
    testCode: `function check(fn) {
  const cases = [
    { args: [[2,7,11,15], 9], expect: [0,1] },
    { args: [[3,2,4], 6], expect: [1,2] },
    { args: [[-1,-2,-3,-4,-5], -8], expect: [2,4] },
    { args: [[0,4,3,0], 0], expect: [0,3] },
    { args: [[5,75,25], 100], expect: [1,2] },
  ]
  let passed = 0
  const results = cases.map((c, i) => {
    let ok = false
    try {
      const out = fn(...c.args)
      ok = Array.isArray(out) && out.length === 2 && out.slice().sort().join(",") === c.expect.slice().sort().join(",")
    } catch (e) { ok = false }
    if (ok) passed++
    return { label: "case " + (i + 1), pass: ok }
  })
  return { passed, total: cases.length, cases: results }
}`,
    points: 100,
  },
  {
    id: "longest-substring",
    day: 41,
    date: "2026-09-22",
    title: "Longest substring without repeats",
    category: "Strings",
    difficulty: "Medium",
    prompt:
      "Write function longest(s) that returns the length of the longest substring of s without repeating characters.",
    examples: [
      { input: 's = "abcabcbb"', output: "3", explanation: '"abc" is the longest' },
      { input: 's = "bbbbb"', output: "1" },
    ],
    constraints: ["0 <= s.length <= 5 * 10^4", "s consists of printable ASCII"],
    entryPoint: "longest",
    starterCode: `function longest(s) {
  // your code here
}`,
    testCode: `function check(fn) {
  const cases = [
    { args: ["abcabcbb"], expect: 3 },
    { args: ["bbbbb"], expect: 1 },
    { args: ["pwwkew"], expect: 3 },
    { args: [""], expect: 0 },
    { args: ["abcdefg"], expect: 7 },
  ]
  let passed = 0
  const results = cases.map((c, i) => {
    let ok = false
    try { ok = fn(...c.args) === c.expect } catch (e) { ok = false }
    if (ok) passed++
    return { label: "case " + (i + 1), pass: ok }
  })
  return { passed, total: cases.length, cases: results }
}`,
    points: 150,
  },
  {
    id: "island-count",
    day: 40,
    date: "2026-09-21",
    title: "Count islands",
    category: "Graphs",
    difficulty: "Medium",
    prompt:
      "Write function islands(grid) where grid is a 2D array of 0/1. Return the number of connected groups of 1s (4-directionally connected).",
    examples: [
      {
        input: "[[1,1,0],[0,1,0],[0,0,1]]",
        output: "2",
      },
    ],
    constraints: ["1 <= rows, cols <= 300", "grid[i][j] is 0 or 1"],
    entryPoint: "islands",
    starterCode: `function islands(grid) {
  // your code here
}`,
    testCode: `function check(fn) {
  const cases = [
    { args: [[[1,1,0],[0,1,0],[0,0,1]]], expect: 2 },
    { args: [[[1,1,1],[1,1,1],[1,1,1]]], expect: 1 },
    { args: [[[0,0],[0,0]]], expect: 0 },
    { args: [[[1,0,1,0,1]]], expect: 3 },
  ]
  let passed = 0
  const results = cases.map((c, i) => {
    let ok = false
    try { ok = fn(JSON.parse(JSON.stringify(c.args[0]))) === c.expect } catch (e) { ok = false }
    if (ok) passed++
    return { label: "case " + (i + 1), pass: ok }
  })
  return { passed, total: cases.length, cases: results }
}`,
    points: 200,
  },
  {
    id: "coin-change",
    day: 39,
    date: "2026-09-20",
    title: "Minimum coins",
    category: "Dynamic programming",
    difficulty: "Hard",
    prompt:
      "Write function minCoins(coins, amount) that returns the fewest coins needed to make amount using the given coin denominations (unlimited supply of each). Return -1 if impossible.",
    examples: [{ input: "coins = [1,2,5], amount = 11", output: "3", explanation: "5 + 5 + 1" }],
    constraints: ["1 <= coins.length <= 12", "0 <= amount <= 10^4"],
    entryPoint: "minCoins",
    starterCode: `function minCoins(coins, amount) {
  // your code here
}`,
    testCode: `function check(fn) {
  const cases = [
    { args: [[1,2,5], 11], expect: 3 },
    { args: [[2], 3], expect: -1 },
    { args: [[1], 0], expect: 0 },
    { args: [[1,3,4], 6], expect: 2 },
  ]
  let passed = 0
  const results = cases.map((c, i) => {
    let ok = false
    try { ok = fn(...c.args) === c.expect } catch (e) { ok = false }
    if (ok) passed++
    return { label: "case " + (i + 1), pass: ok }
  })
  return { passed, total: cases.length, cases: results }
}`,
    points: 250,
  },
  {
    id: "binary-search-rotated",
    day: 38,
    date: "2026-09-19",
    title: "Search in rotated array",
    category: "Search",
    difficulty: "Medium",
    prompt:
      "Write function search(nums, target) on a rotated, ascending, distinct-valued array. Return the index of target or -1. Aim for O(log n).",
    examples: [{ input: "nums = [4,5,6,7,0,1,2], target = 0", output: "4" }],
    constraints: ["1 <= nums.length <= 5000", "All values distinct"],
    entryPoint: "search",
    starterCode: `function search(nums, target) {
  // your code here
}`,
    testCode: `function check(fn) {
  const cases = [
    { args: [[4,5,6,7,0,1,2], 0], expect: 4 },
    { args: [[4,5,6,7,0,1,2], 3], expect: -1 },
    { args: [[1], 0], expect: -1 },
    { args: [[5,1,3], 5], expect: 0 },
  ]
  let passed = 0
  const results = cases.map((c, i) => {
    let ok = false
    try { ok = fn(...c.args) === c.expect } catch (e) { ok = false }
    if (ok) passed++
    return { label: "case " + (i + 1), pass: ok }
  })
  return { passed, total: cases.length, cases: results }
}`,
    points: 150,
  },
]

export const dailySubmissions: DailySubmission[] = [
  { id: "ps-sable", challengeId: "pair-sum", agent: "Sable", author: "mira", submittedAt: "2026-09-23T08:12:00", runtimeMs: 0.8, passed: 5, total: 5, score: 100 },
  { id: "ps-atlas", challengeId: "pair-sum", agent: "Atlas", author: "you", submittedAt: "2026-09-23T09:40:00", runtimeMs: 1.1, passed: 5, total: 5, score: 100 },
  { id: "ps-nova", challengeId: "pair-sum", agent: "Nova", author: "kira", submittedAt: "2026-09-23T10:05:00", runtimeMs: 1.4, passed: 4, total: 5, score: 80 },
  { id: "ls-sable", challengeId: "longest-substring", agent: "Sable", author: "mira", submittedAt: "2026-09-22T07:55:00", runtimeMs: 1.9, passed: 5, total: 5, score: 150 },
  { id: "ls-orion", challengeId: "longest-substring", agent: "Orion", author: "dmitri", submittedAt: "2026-09-22T11:20:00", runtimeMs: 2.4, passed: 5, total: 5, score: 150 },
  { id: "ic-atlas", challengeId: "island-count", agent: "Atlas", author: "you", submittedAt: "2026-09-21T09:10:00", runtimeMs: 2.1, passed: 4, total: 4, score: 200 },
  { id: "cc-sable", challengeId: "coin-change", agent: "Sable", author: "mira", submittedAt: "2026-09-20T08:30:00", runtimeMs: 3.2, passed: 4, total: 4, score: 250 },
  { id: "bsr-nova", challengeId: "binary-search-rotated", agent: "Nova", author: "kira", submittedAt: "2026-09-19T09:00:00", runtimeMs: 0.6, passed: 4, total: 4, score: 150 },
]

export const dailyStreaks = [
  { agent: "Sable", author: "mira", current: 12, longest: 21 },
  { agent: "Atlas", author: "you", current: 6, longest: 14 },
  { agent: "Nova", author: "kira", current: 9, longest: 9 },
  { agent: "Orion", author: "dmitri", current: 2, longest: 8 },
]

export function getDailyChallenge(id: string) {
  return dailyChallenges.find((c) => c.id === id)
}

export function getTodayChallenge() {
  return dailyChallenges.slice().sort((a, b) => b.day - a.day)[0]
}

export function getDailyArchive() {
  return dailyChallenges.slice().sort((a, b) => b.day - a.day).slice(1)
}

export function getSubmissionsForChallenge(id: string) {
  return dailySubmissions
    .filter((s) => s.challengeId === id)
    .sort((a, b) => b.score - a.score || a.runtimeMs - b.runtimeMs)
}

export function getStreakFor(agent: string) {
  return dailyStreaks.find((s) => s.agent === agent)
}
