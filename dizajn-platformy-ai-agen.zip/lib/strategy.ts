export type SportType = "hockey" | "tanks"
export type MatchStatus = "live" | "upcoming" | "finished"

export type StrategyTeam = {
  agent: string
  author: string
  isYou?: boolean
}

export type StrategyMatch = {
  id: string
  sport: SportType
  title: string
  rules: string
  teamA: StrategyTeam
  teamB: StrategyTeam
  status: MatchStatus
  finalScoreA?: number
  finalScoreB?: number
  startsIn?: string
}

export const sportLabels: Record<SportType, string> = {
  hockey: "3v3 Hockey",
  tanks: "Tank Skirmish",
}

export const sportRules: Record<SportType, string> = {
  hockey:
    "Two teams of 3 units share a rink and one puck. Your code returns a movement vector for each of your units every tick. Push the puck into the opponent's goal (their end of the rink) to score. Most goals when the clock hits zero wins.",
  tanks:
    "Two teams of 3 units share an open arena. Your code returns a movement vector for each of your units every tick. Standing within range of an enemy unit deals steady damage to it — destroy enemy units to score a point. Destroyed units respawn after a short delay. Most destructions when the clock hits zero wins.",
}

export const strategyMatches: StrategyMatch[] = [
  {
    id: "atlas-vs-sable-hockey",
    sport: "hockey",
    title: "Atlas vs Sable — rink control",
    rules: sportRules.hockey,
    teamA: { agent: "Atlas", author: "you", isYou: true },
    teamB: { agent: "Sable", author: "mira" },
    status: "live",
  },
  {
    id: "nova-vs-orion-tanks",
    sport: "tanks",
    title: "Nova vs Orion — open arena",
    rules: sportRules.tanks,
    teamA: { agent: "Nova", author: "kira" },
    teamB: { agent: "Orion", author: "dmitri" },
    status: "live",
  },
  {
    id: "atlas-vs-vega-tanks",
    sport: "tanks",
    title: "Atlas vs Vega — open arena",
    rules: sportRules.tanks,
    teamA: { agent: "Atlas", author: "you", isYou: true },
    teamB: { agent: "Vega", author: "leo" },
    status: "upcoming",
    startsIn: "in 8 minutes",
  },
  {
    id: "sable-vs-nova-hockey",
    sport: "hockey",
    title: "Sable vs Nova — rink control",
    rules: sportRules.hockey,
    teamA: { agent: "Sable", author: "mira" },
    teamB: { agent: "Nova", author: "kira" },
    status: "upcoming",
    startsIn: "in 22 minutes",
  },
  {
    id: "orion-vs-juno-hockey",
    sport: "hockey",
    title: "Orion vs Juno — rink control",
    rules: sportRules.hockey,
    teamA: { agent: "Orion", author: "dmitri" },
    teamB: { agent: "Juno", author: "sana" },
    status: "finished",
    finalScoreA: 4,
    finalScoreB: 2,
  },
  {
    id: "atlas-vs-juno-tanks",
    sport: "tanks",
    title: "Atlas vs Juno — open arena",
    rules: sportRules.tanks,
    teamA: { agent: "Atlas", author: "you", isYou: true },
    teamB: { agent: "Juno", author: "sana" },
    status: "finished",
    finalScoreA: 6,
    finalScoreB: 3,
  },
]

export function getMatch(id: string) {
  return strategyMatches.find((m) => m.id === id)
}

export const starterStrategy = `function strategy(state) {
  // state.self: your units [{ id, x, y }]
  // state.opponents: enemy units [{ id, x, y }]
  // state.target: puck (hockey) or nearest enemy (tanks), or null
  // state.arena: { width, height }
  // Return one { dx, dy } per unit in state.self, values roughly -1..1
  return state.self.map((unit) => {
    const target = state.target ?? state.opponents[0]
    if (!target) return { dx: 0, dy: 0 }
    return { dx: target.x - unit.x, dy: target.y - unit.y }
  })
}`
