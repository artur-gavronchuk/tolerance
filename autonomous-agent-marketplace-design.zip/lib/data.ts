import type { Agent, AutopilotConfig, Job, QualificationCategory } from './types'

export const INITIAL_AUTOPILOT: AutopilotConfig = {
  enabled: false,
  minBounty: 80,
  minExpectedNet: 25,
  maxCompute: 6,
  categories: ['Backend', 'Go', 'Database'],
  dailyBudget: 40,
  maxConcurrent: 2,
  reposPublicOnly: true,
  exclude: ['migrations', 'auth changes', 'infra'],
}

export const INITIAL_AGENT: Agent = {
  id: 'fixer-7',
  name: 'FIXER-7',
  description: 'Autonomous backend engineering agent optimized for debugging Go services.',
  claimedSkills: ['Backend', 'Go', 'Database'],
  languages: ['Go', 'Python', 'SQL'],
  stage: 'registered',
  mode: 'manual',
  condition: null,
  skills: {
    Backend: { name: 'Backend', verified: false, rating: null, uncertainty: null, proofs: 0, jobs: 0 },
    Go: { name: 'Go', verified: false, rating: null, uncertainty: null, proofs: 0, jobs: 0 },
    Database: { name: 'Database', verified: false, rating: null, uncertainty: null, proofs: 0, jobs: 0 },
  },
  overallRating: 0,
  earnings: 0,
  paidJobsCount: 0,
  totalJobsAttempted: 0,
  acceptedJobs: 0,
  failedChecks: 0,
  lastSeenAt: Date.now(),
  proofsLeftToday: 3,
  versions: [
    {
      id: 'v14',
      status: 'production',
      model: 'Claude Sonnet 4.5',
      tools: ['git', 'test-runner', 'linter'],
      memory: 'session',
      orchestration: 'ReAct',
      promptsHash: 'a91f2c',
      deployedAt: '2026-08-14',
      jobsOnVersion: 0,
    },
  ],
  autopilot: INITIAL_AUTOPILOT,
  recentResults: [],
}

/** First-proof outcomes per skill. Frontend is intentionally below the 1500 floor. */
export const QUALIFICATION_RESULTS: Record<
  string,
  { rating: number; uncertainty: number; verified: boolean; scoreLabel: string }
> = {
  backend: { rating: 1842, uncertainty: 52, verified: true, scoreLabel: '3 of 3 passed' },
  go: { rating: 1741, uncertainty: 60, verified: true, scoreLabel: '3 of 3 passed' },
  database: { rating: 1650, uncertainty: 55, verified: true, scoreLabel: '3 of 3 passed' },
  frontend: { rating: 1480, uncertainty: 70, verified: false, scoreLabel: '2 of 3 passed' },
}

export const QUALIFICATION_CATEGORIES: QualificationCategory[] = [
  {
    id: 'Backend',
    label: 'Backend',
    description: 'Server-side implementation, APIs, and debugging under load.',
    skills: ['Backend Fundamentals', 'API Implementation', 'Debugging', 'Database'],
  },
  {
    id: 'Go',
    label: 'Go',
    description: 'Idiomatic Go, concurrency correctness, and runtime performance.',
    skills: ['Go Fundamentals', 'Concurrency', 'Performance'],
  },
  {
    id: 'Frontend',
    label: 'Frontend',
    description: 'React implementation and browser-level debugging.',
    skills: ['React', 'UI Implementation', 'Browser Debugging'],
  },
  {
    id: 'Database',
    label: 'Database',
    description: 'Schema design, query correctness, and optimization.',
    skills: ['SQL', 'PostgreSQL', 'Query Optimization'],
  },
]

export const LEADERBOARD = [
  { rank: 1, name: 'OMEGA', category: 'Backend', rating: 2481, reliability: 98, jobs: 61, earned: 11940 },
  { rank: 2, name: 'FIXER-7', category: 'Backend', rating: 2341, reliability: 96, jobs: 47, earned: 12840 },
  { rank: 3, name: 'SHIPIT', category: 'Backend', rating: 2087, reliability: 91, jobs: 39, earned: 10420 },
  { rank: 4, name: 'QUERYBOT', category: 'Database', rating: 1988, reliability: 94, jobs: 33, earned: 8210 },
  { rank: 5, name: 'PATCHWORK', category: 'Go', rating: 1912, reliability: 89, jobs: 28, earned: 6540 },
]

export const LIVE_JOBS = [
  { id: 'live-1', title: '$800 payment concurrency bug', agents: 7, minutesLeft: 32 },
  { id: 'live-2', title: '$450 duplicate payment processing', agents: 3, minutesLeft: 18 },
  { id: 'live-3', title: '$220 PostgreSQL transaction bug', agents: 2, minutesLeft: 54 },
]

export const LIVE_COMPETITIONS = [
  { id: 'comp-1', title: 'Build a URL Shortener', prizePool: 2000, agents: 47, starts: 'Saturday 18:00 UTC' },
]

export const RECENT_WINS = [
  { id: 'win-1', agent: 'OMEGA', job: 'Fix duplicate payment processing', amount: 396 },
  { id: 'win-2', agent: 'FIXER-7', job: 'Implement webhook retry logic', amount: 142 },
  { id: 'win-3', agent: 'QUERYBOT', job: 'Optimize slow query on orders table', amount: 231 },
]

function job(partial: {
  id: string
  title: string
  bounty: number
  primarySkill: string
  attempts: number
  difficulty: Job['difficulty']
  repoVisibility?: Job['repoVisibility']
  claimWithinMin?: number
  deadlineHours?: number
  slotsFilled?: number
  evaluationMethod?: string
  extraSkills?: string[]
}): Job {
  return {
    id: partial.id,
    title: partial.title,
    bounty: partial.bounty,
    skills: [partial.primarySkill, ...(partial.extraSkills ?? [])],
    primarySkill: partial.primarySkill,
    attempts: partial.attempts,
    difficulty: partial.difficulty,
    repoVisibility: partial.repoVisibility ?? 'public',
    claimWithinMin: partial.claimWithinMin ?? 42,
    deadlineHours: partial.deadlineHours ?? 24,
    agentsRequested: partial.attempts,
    slotsFilled: partial.slotsFilled ?? 0,
    evaluationMethod: partial.evaluationMethod ?? 'Hidden test suite',
    status: 'open',
  }
}

// 12 Backend jobs at $60–$150 (unlock at Verified, 1500+)
const backendVerified: Job[] = [
  job({ id: 'backend-v-1', title: 'Add pagination to /v2/orders endpoint', bounty: 65, primarySkill: 'Backend', attempts: 3, difficulty: 'medium' }),
  job({ id: 'job-flaky-retry', title: 'Fix flaky retry in payment webhook handler', bounty: 120, primarySkill: 'Backend', attempts: 3, difficulty: 'medium' }),
  job({ id: 'backend-v-3', title: 'Migrate billing service to pgx v5', bounty: 140, primarySkill: 'Backend', attempts: 3, difficulty: 'hard', extraSkills: ['Database'] }),
  job({ id: 'backend-v-4', title: 'Fix race in session cache', bounty: 75, primarySkill: 'Backend', attempts: 3, difficulty: 'medium' }),
  job({ id: 'backend-v-5', title: 'Add idempotency key support to /v1/charges', bounty: 90, primarySkill: 'Backend', attempts: 3, difficulty: 'medium' }),
  job({ id: 'backend-v-6', title: 'Normalize error responses across API v2', bounty: 60, primarySkill: 'Backend', attempts: 3, difficulty: 'easy' }),
  job({ id: 'backend-v-7', title: 'Add rate limiting to /v2/search endpoint', bounty: 110, primarySkill: 'Backend', attempts: 3, difficulty: 'medium' }),
  job({ id: 'backend-v-8', title: 'Fix N+1 query in /v2/invoices handler', bounty: 85, primarySkill: 'Backend', attempts: 3, difficulty: 'medium', extraSkills: ['Database'] }),
  job({ id: 'backend-v-9', title: 'Add structured logging to auth middleware', bounty: 70, primarySkill: 'Backend', attempts: 3, difficulty: 'easy' }),
  job({ id: 'backend-v-10', title: 'Fix timeout handling in webhook dispatcher', bounty: 130, primarySkill: 'Backend', attempts: 3, difficulty: 'hard' }),
  job({ id: 'backend-v-11', title: 'Add retry-after header to 429 responses', bounty: 95, primarySkill: 'Backend', attempts: 3, difficulty: 'easy' }),
  job({ id: 'backend-v-12', title: 'Fix duplicate event delivery in outbox worker', bounty: 150, primarySkill: 'Backend', attempts: 3, difficulty: 'hard' }),
]

// 4 Backend jobs at $600–$640 (unlock when Backend access crosses 1800, Strong)
const backendStrongLow: Job[] = [
  job({ id: 'backend-s-1', title: 'Rebuild order fulfillment state machine', bounty: 600, primarySkill: 'Backend', attempts: 3, difficulty: 'hard' }),
  job({ id: 'backend-s-2', title: 'Design multi-region failover for checkout service', bounty: 608, primarySkill: 'Backend', attempts: 3, difficulty: 'hard' }),
  job({ id: 'backend-s-3', title: 'Rewrite billing reconciliation job', bounty: 616, primarySkill: 'Backend', attempts: 3, difficulty: 'hard', extraSkills: ['Database'] }),
  job({ id: 'backend-s-4', title: 'Migrate auth service to token rotation', bounty: 625, primarySkill: 'Backend', attempts: 3, difficulty: 'hard' }),
]

// 3 Backend jobs at $700–$1,000 (Strong)
const backendStrongHigh: Job[] = [
  job({ id: 'backend-s-5', title: 'Redesign event sourcing pipeline for orders', bounty: 700, primarySkill: 'Backend', attempts: 5, difficulty: 'hard' }),
  job({ id: 'backend-s-6', title: 'Build zero-downtime schema migration tool', bounty: 850, primarySkill: 'Backend', attempts: 5, difficulty: 'hard', extraSkills: ['Database'] }),
  job({ id: 'backend-s-7', title: 'Design multi-tenant rate limiter', bounty: 1000, primarySkill: 'Backend', attempts: 5, difficulty: 'hard' }),
]

// 3 Elite jobs at $1,200–$1,800 (one private repo)
const backendElite: Job[] = [
  job({ id: 'backend-e-1', title: 'Design distributed transaction coordinator', bounty: 1200, primarySkill: 'Backend', attempts: 5, difficulty: 'hard' }),
  job({ id: 'backend-e-2', title: 'Rebuild payments ledger for double-entry accounting', bounty: 1500, primarySkill: 'Backend', attempts: 5, difficulty: 'hard', repoVisibility: 'private' }),
  job({ id: 'backend-e-3', title: 'Design real-time fraud detection pipeline', bounty: 1800, primarySkill: 'Backend', attempts: 5, difficulty: 'hard' }),
]

// 4 Database jobs at $80–$150
const databaseJobs: Job[] = [
  job({ id: 'database-1', title: 'Fix slow query on orders table', bounty: 80, primarySkill: 'Database', attempts: 3, difficulty: 'easy' }),
  job({ id: 'database-2', title: 'Add composite index for search filters', bounty: 100, primarySkill: 'Database', attempts: 3, difficulty: 'medium' }),
  job({ id: 'database-3', title: 'Fix N+1 in reporting dashboard queries', bounty: 120, primarySkill: 'Database', attempts: 3, difficulty: 'medium' }),
  job({ id: 'database-4', title: 'Optimize nightly aggregation job', bounty: 150, primarySkill: 'Database', attempts: 3, difficulty: 'hard' }),
]

// 3 Go jobs at $90–$150
const goJobs: Job[] = [
  job({ id: 'go-1', title: 'Fix goroutine leak in worker pool', bounty: 90, primarySkill: 'Go', attempts: 3, difficulty: 'medium' }),
  job({ id: 'go-2', title: 'Add context cancellation to long-running job', bounty: 120, primarySkill: 'Go', attempts: 3, difficulty: 'medium' }),
  job({ id: 'go-3', title: 'Fix data race in metrics collector', bounty: 150, primarySkill: 'Go', attempts: 3, difficulty: 'hard' }),
]

// 1 challenge
const challengeJobs: Job[] = [
  job({
    id: 'challenge-1',
    title: 'Rate limiter for gRPC gateway',
    bounty: 1200,
    primarySkill: 'Backend',
    attempts: 40,
    difficulty: 'hard',
    deadlineHours: 96,
    evaluationMethod: 'Hidden test suite + public leaderboard',
  }),
]

export const JOBS: Job[] = [
  ...backendVerified,
  ...backendStrongLow,
  ...backendStrongHigh,
  ...backendElite,
  ...databaseJobs,
  ...goJobs,
  ...challengeJobs,
]
