'use client'

import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { eligibleJobs } from './access'
import { INITIAL_AGENT, INITIAL_AUTOPILOT, JOBS, QUALIFICATION_RESULTS } from './data'
import { computePayout, type PayoutBreakdown } from './money'
import type {
  ActivityEvent,
  Agent,
  AgentMode,
  AttemptResult,
  AutopilotConfig,
  Job,
  OvernightRunSummary,
  SkillNode,
} from './types'

const STORAGE_KEY = 'arena42-demo'

interface PersistedState {
  agent: Agent
  jobs: Job[]
  activity: ActivityEvent[]
}

interface AppState {
  agent: Agent
  jobs: Job[]
  activity: ActivityEvent[]
  hydrated: boolean
  lastOvernightRun: OvernightRunSummary | null
  createAgent: (input: { name: string; description: string; claimedSkills: string[]; languages: string[] }) => void
  connectRuntime: () => void
  markValidated: () => void
  runProof: (skillLabel: string) => void
  sendAgentToJob: (jobId: string) => void
  completeJob: (jobId: string, outcome: AttemptResult, payout: PayoutBreakdown) => void
  setAutopilot: (config: Partial<AutopilotConfig>) => void
  setMode: (mode: AgentMode) => void
  simulateOvernightRun: () => void
  logActivity: (event: Omit<ActivityEvent, 'id' | 'timestamp'>) => void
  applyDemoPreset: (preset: DemoPreset) => void
}

export type DemoPreset =
  | 'fresh'
  | 'operational'
  | 'qualified'
  | 'first-money'
  | 'proven'
  | 'trusted'
  | 'autopilot-overnight'
  | 'version-changed'
  | 'offline'

const AppContext = createContext<AppState | null>(null)

let idCounter = 0
function nextId() {
  idCounter += 1
  return `evt-${idCounter}`
}

function passRate(results: AttemptResult[]): number {
  const last10 = results.slice(0, 10)
  if (last10.length === 0) return 1
  const passed = last10.filter((r) => r !== 'failed').length
  return passed / last10.length
}

function accessOf(agent: Agent, skillName: string): number {
  const skill = agent.skills[skillName]
  if (!skill || !skill.verified || skill.rating == null) return 0
  return skill.rating - (skill.uncertainty ?? 0)
}

/** Recomputes stage from the underlying facts. Called after every state-changing action. */
function recomputeStage(agent: Agent): Agent['stage'] {
  let stage = agent.stage
  if (stage === 'registered' || stage === 'connected') return stage

  const anyVerifiedAt1500 = Object.keys(agent.skills).some((s) => accessOf(agent, s) >= 1500)
  if (stage === 'operational' && anyVerifiedAt1500) stage = 'qualified'

  if (stage === 'qualified' && agent.acceptedJobs >= 3) stage = 'proven'

  if (stage === 'proven' && agent.acceptedJobs >= 10 && passRate(agent.recentResults) >= 0.7) {
    stage = 'trusted'
  }

  if ((stage === 'trusted' || stage === 'proven') && agent.acceptedJobs >= 3 && passRate(agent.recentResults) < 0.7) {
    stage = 'proven'
  }

  return stage
}

function unlockSummary(before: Job[], after: Job[]) {
  const beforeIds = new Set(before.map((j) => j.id))
  const newlyUnlocked = after.filter((j) => !beforeIds.has(j.id))
  return {
    count: newlyUnlocked.length,
    totalValue: newlyUnlocked.reduce((sum, j) => sum + j.bounty, 0),
    maxBounty: newlyUnlocked.reduce((max, j) => Math.max(max, j.bounty), 0),
  }
}

function loadPersisted(): PersistedState | null {
  if (typeof window === 'undefined') return null
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return null
    const parsed = JSON.parse(raw) as PersistedState
    if (!parsed?.agent || !parsed?.jobs) return null
    return parsed
  } catch {
    return null
  }
}

function savePersisted(state: PersistedState) {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  } catch {
    // ignore write failures (quota, privacy mode, etc.)
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [agent, setAgent] = useState<Agent>(INITIAL_AGENT)
  const [jobs, setJobs] = useState<Job[]>(JOBS)
  const [activity, setActivity] = useState<ActivityEvent[]>([])
  const [lastOvernightRun, setLastOvernightRun] = useState<OvernightRunSummary | null>(null)
  const [hydrated, setHydrated] = useState(false)
  const skipNextPersist = useRef(true)

  useEffect(() => {
    const persisted = loadPersisted()
    if (persisted) {
      setAgent(persisted.agent)
      setJobs(persisted.jobs)
      setActivity(persisted.activity)
    }
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    if (skipNextPersist.current) {
      skipNextPersist.current = false
      return
    }
    savePersisted({ agent, jobs, activity })
  }, [agent, jobs, activity, hydrated])

  const logActivity = (event: Omit<ActivityEvent, 'id' | 'timestamp'>) => {
    setActivity((prev) => [{ ...event, id: nextId(), timestamp: Date.now() }, ...prev])
  }

  const createAgent = (input: { name: string; description: string; claimedSkills: string[]; languages: string[] }) => {
    const skills: Agent['skills'] = {}
    for (const s of input.claimedSkills) {
      skills[s] = { name: s, verified: false, rating: null, uncertainty: null, proofs: 0, jobs: 0 }
    }
    setAgent((prev) => ({
      ...prev,
      name: input.name || prev.name,
      description: input.description || prev.description,
      claimedSkills: input.claimedSkills,
      languages: input.languages,
      skills,
      stage: 'registered',
    }))
  }

  const connectRuntime = () => {
    setAgent((prev) => ({ ...prev, stage: 'connected' }))
  }

  const markValidated = () => {
    setAgent((prev) => ({ ...prev, stage: 'operational' }))
    logActivity({
      kind: 'validation',
      title: 'Agent validated',
      detail: `${agent.name} proved it can operate autonomously on the platform.`,
    })
  }

  const runProof = (skillLabel: string) => {
    const key = skillLabel.toLowerCase()
    const result = QUALIFICATION_RESULTS[key] ?? QUALIFICATION_RESULTS.backend
    const beforeEligible = eligibleJobs(agent, jobs)

    const prevSkill = agent.skills[skillLabel]
    const updatedSkill: SkillNode = {
      name: skillLabel,
      verified: result.verified,
      rating: result.rating,
      uncertainty: result.uncertainty,
      proofs: (prevSkill?.proofs ?? 0) + 1,
      jobs: prevSkill?.jobs ?? 0,
    }

    let nextAgent: Agent = {
      ...agent,
      proofsLeftToday: Math.max(0, agent.proofsLeftToday - 1),
      skills: { ...agent.skills, [skillLabel]: updatedSkill },
      overallRating: result.verified ? result.rating : agent.overallRating,
    }
    nextAgent = { ...nextAgent, stage: recomputeStage(nextAgent) }
    setAgent(nextAgent)

    const afterEligible = eligibleJobs(nextAgent, jobs)
    const summary = unlockSummary(beforeEligible, afterEligible)

    if (result.verified) {
      logActivity({
        kind: 'qualification',
        title: `${skillLabel} verified`,
        detail:
          summary.count > 0
            ? `${summary.count} paid jobs unlocked · $${summary.totalValue.toLocaleString()} total · jobs up to $${summary.maxBounty}`
            : `Verified at ${result.rating}. No jobs unlock yet at this access level.`,
      })
    } else {
      logActivity({
        kind: 'qualification',
        title: `${skillLabel} not verified yet`,
        detail: `${result.scoreLabel}. Access ${result.rating - result.uncertainty} (needs 1500).`,
      })
    }
  }

  const sendAgentToJob = (jobId: string) => {
    setJobs((prev) => prev.map((j) => (j.id === jobId ? { ...j, status: 'in_progress' } : j)))
    setAgent((prev) => ({ ...prev, totalJobsAttempted: prev.totalJobsAttempted + 1 }))
  }

  const completeJob = (jobId: string, outcome: AttemptResult, payout: PayoutBreakdown) => {
    const jobBefore = jobs.find((j) => j.id === jobId)
    if (!jobBefore) return

    const beforeEligible = eligibleJobs(agent, jobs)
    const nextJobs = jobs.map((j) => (j.id === jobId ? { ...j, status: 'completed' as const } : j))
    setJobs(nextJobs)

    const skillName = jobBefore.primarySkill
    const skill = agent.skills[skillName]

    let ratingDelta = 0
    let uncertaintyDelta = 0
    if (outcome === 'picked') {
      ratingDelta = 27
      uncertaintyDelta = -12
    } else if (outcome === 'passed') {
      ratingDelta = 8
      uncertaintyDelta = -10
    } else {
      ratingDelta = -15
      uncertaintyDelta = -8
    }

    const newRating = (skill?.rating ?? 0) + ratingDelta
    const newUncertainty = Math.max(25, (skill?.uncertainty ?? 0) + uncertaintyDelta)
    const updatedSkill: SkillNode | undefined = skill
      ? { ...skill, rating: newRating, uncertainty: newUncertainty, jobs: skill.jobs + 1 }
      : skill

    const recentResults: AttemptResult[] = [outcome, ...agent.recentResults].slice(0, 10)
    const acceptedJobs = agent.acceptedJobs + (outcome !== 'failed' ? 1 : 0)
    const failedChecks = outcome === 'failed' ? agent.failedChecks + 1 : 0

    let nextAgent: Agent = {
      ...agent,
      skills: updatedSkill ? { ...agent.skills, [skillName]: updatedSkill } : agent.skills,
      earnings: agent.earnings + payout.net,
      paidJobsCount: agent.paidJobsCount + (outcome !== 'failed' ? 1 : 0),
      acceptedJobs,
      failedChecks,
      recentResults,
      overallRating: updatedSkill ? newRating : agent.overallRating,
      lastSeenAt: Date.now(),
    }

    const consecutiveFailures = recentResults[0] === 'failed' && recentResults[1] === 'failed'
    if (consecutiveFailures) {
      nextAgent = { ...nextAgent, condition: 'restricted', mode: 'manual' }
    }

    nextAgent = { ...nextAgent, stage: recomputeStage(nextAgent) }
    setAgent(nextAgent)

    const afterEligible = eligibleJobs(nextAgent, nextJobs)
    const summary = unlockSummary(beforeEligible, afterEligible)

    logActivity({
      kind: 'payment',
      title: outcome === 'failed' ? 'Job failed checks' : 'Job completed',
      detail:
        outcome === 'failed'
          ? `Customer's checks failed the submitted solution.`
          : outcome === 'picked'
            ? `Customer accepted the submitted solution.${payout.othersPassedCount > 0 ? ` ${payout.othersPassedCount} other attempt${payout.othersPassedCount === 1 ? '' : 's'} passed · $${payout.baseShare.toFixed(2)} each.` : ''}`
            : `Passed checks but wasn't the picked attempt.`,
      amount: outcome === 'failed' ? undefined : payout.net,
    })

    if (summary.count > 0) {
      const tierLabel = accessOf(nextAgent, skillName) >= 2100 ? 'Elite' : accessOf(nextAgent, skillName) >= 1800 ? 'Strong' : 'Verified'
      logActivity({
        kind: 'unlock',
        title: `${tierLabel} tier reached`,
        detail: `${summary.count} higher-value jobs unlocked (up to $${summary.maxBounty})`,
      })
    }
  }

  const setAutopilot = (config: Partial<AutopilotConfig>) => {
    setAgent((prev) => ({ ...prev, autopilot: { ...prev.autopilot, ...config } }))
  }

  const setMode = (mode: AgentMode) => {
    setAgent((prev) => ({ ...prev, mode, autopilot: { ...prev.autopilot, enabled: mode === 'autopilot' } }))
  }

  const simulateOvernightRun = () => {
    const attempted = 6
    const completed = 6
    const accepted = 5
    const running = 1
    const earned = 601
    const fees = Math.round(earned * 0.1 * 100) / 100
    const compute = 54
    const net = Math.round((earned - fees - compute) * 100) / 100
    const ratingBefore = agent.overallRating
    const ratingAfter = ratingBefore + 13

    setLastOvernightRun({
      awayFrom: Date.now() - 8 * 60 * 60 * 1000 - 32 * 60 * 1000,
      awayTo: Date.now(),
      attempted,
      completed,
      accepted,
      running,
      earned,
      fees,
      compute,
      net,
      ratingBefore,
      ratingAfter,
    })

    setAgent((prev) => ({
      ...prev,
      earnings: prev.earnings + net,
      paidJobsCount: prev.paidJobsCount + accepted,
      totalJobsAttempted: prev.totalJobsAttempted + attempted,
      acceptedJobs: prev.acceptedJobs + accepted,
      overallRating: ratingAfter,
      lastSeenAt: Date.now(),
      skills: prev.skills.Backend
        ? { ...prev.skills, Backend: { ...prev.skills.Backend, rating: (prev.skills.Backend.rating ?? 0) + 13, jobs: prev.skills.Backend.jobs + accepted } }
        : prev.skills,
    }))

    logActivity({
      kind: 'autopilot',
      title: 'Autopilot completed overnight run',
      detail: `Attempted ${attempted} jobs while you were away · ${accepted} accepted · 1 still running.`,
      amount: net,
    })
  }

  const applyDemoPreset = (preset: DemoPreset) => {
    const baseSkills = (): Agent['skills'] => ({
      Backend: { name: 'Backend', verified: false, rating: null, uncertainty: null, proofs: 0, jobs: 0 },
      Go: { name: 'Go', verified: false, rating: null, uncertainty: null, proofs: 0, jobs: 0 },
      Database: { name: 'Database', verified: false, rating: null, uncertainty: null, proofs: 0, jobs: 0 },
    })

    let nextAgent: Agent = { ...INITIAL_AGENT, skills: baseSkills(), autopilot: { ...INITIAL_AUTOPILOT } }
    let nextJobs: Job[] = JOBS.map((j) => ({ ...j, status: 'open' }))
    let nextActivity: ActivityEvent[] = []
    let nextOvernight: OvernightRunSummary | null = null

    switch (preset) {
      case 'fresh':
        break
      case 'operational':
        nextAgent.stage = 'operational'
        break
      case 'qualified':
        nextAgent.stage = 'qualified'
        nextAgent.overallRating = 1842
        nextAgent.skills.Backend = { name: 'Backend', verified: true, rating: 1842, uncertainty: 52, proofs: 1, jobs: 0 }
        nextActivity = [
          {
            id: nextId(),
            timestamp: Date.now(),
            kind: 'qualification',
            title: 'Backend verified',
            detail: '12 jobs unlocked · $1,175 total · jobs up to $150',
          },
        ]
        break
      case 'first-money': {
        nextAgent.stage = 'qualified'
        nextAgent.skills.Backend = { name: 'Backend', verified: true, rating: 1869, uncertainty: 40, proofs: 1, jobs: 1 }
        nextAgent.overallRating = 1869
        nextAgent.earnings = 68.9
        nextAgent.paidJobsCount = 1
        nextAgent.totalJobsAttempted = 1
        nextAgent.acceptedJobs = 1
        nextAgent.recentResults = ['picked']
        nextJobs = nextJobs.map((j) => (j.id === 'job-flaky-retry' ? { ...j, status: 'completed' } : j))
        nextActivity = [
          {
            id: nextId(),
            timestamp: Date.now(),
            kind: 'unlock',
            title: 'Strong tier reached',
            detail: '4 higher-value jobs unlocked (up to $625)',
          },
          {
            id: nextId(),
            timestamp: Date.now() - 1000,
            kind: 'payment',
            title: 'Job completed',
            detail: 'Customer accepted the submitted solution. 2 other attempts passed · $20.00 each.',
            amount: 68.9,
          },
        ]
        break
      }
      case 'proven':
        nextAgent.stage = 'proven'
        nextAgent.skills.Backend = { name: 'Backend', verified: true, rating: 2050, uncertainty: 45, proofs: 2, jobs: 4 }
        nextAgent.overallRating = 2050
        nextAgent.earnings = 612.4
        nextAgent.paidJobsCount = 4
        nextAgent.totalJobsAttempted = 4
        nextAgent.acceptedJobs = 3
        nextAgent.recentResults = ['picked', 'passed', 'picked']
        break
      case 'trusted':
        nextAgent.stage = 'trusted'
        nextAgent.skills.Backend = { name: 'Backend', verified: true, rating: 2300, uncertainty: 90, proofs: 4, jobs: 22 }
        nextAgent.skills.Database = { name: 'Database', verified: true, rating: 1780, uncertainty: 50, proofs: 1, jobs: 3 }
        nextAgent.overallRating = 2300
        nextAgent.earnings = 5840.2
        nextAgent.paidJobsCount = 22
        nextAgent.totalJobsAttempted = 25
        nextAgent.acceptedJobs = 22
        nextAgent.recentResults = ['picked', 'picked', 'passed', 'picked', 'passed', 'picked', 'picked', 'passed', 'picked', 'picked']
        break
      case 'autopilot-overnight':
        nextAgent.stage = 'trusted'
        nextAgent.mode = 'autopilot'
        nextAgent.autopilot = { ...INITIAL_AUTOPILOT, enabled: true }
        nextAgent.skills.Backend = { name: 'Backend', verified: true, rating: 2300, uncertainty: 60, proofs: 4, jobs: 30 }
        nextAgent.overallRating = 2300
        nextAgent.earnings = 6120.35
        nextAgent.paidJobsCount = 30
        nextAgent.totalJobsAttempted = 34
        nextAgent.acceptedJobs = 30
        nextAgent.recentResults = ['picked', 'picked', 'passed', 'picked', 'passed', 'picked', 'picked', 'passed', 'picked', 'picked']
        nextAgent.lastSeenAt = Date.now() - 9 * 60 * 60 * 1000
        nextOvernight = {
          awayFrom: Date.now() - 9 * 60 * 60 * 1000,
          awayTo: Date.now(),
          attempted: 6,
          completed: 5,
          accepted: 5,
          running: 0,
          earned: 601,
          fees: 60,
          compute: 54,
          net: 487,
          ratingBefore: 2287,
          ratingAfter: 2300,
        }
        break
      case 'version-changed':
        nextAgent.stage = 'trusted'
        nextAgent.skills.Backend = { name: 'Backend', verified: true, rating: 2286, uncertainty: 40, proofs: 4, jobs: 24 }
        nextAgent.overallRating = 2286
        nextAgent.earnings = 5210
        nextAgent.paidJobsCount = 24
        nextAgent.totalJobsAttempted = 27
        nextAgent.acceptedJobs = 24
        nextAgent.recentResults = ['picked', 'passed', 'picked', 'picked', 'passed', 'picked', 'picked', 'picked', 'passed', 'picked']
        nextAgent.versions = [
          { ...INITIAL_AGENT.versions[0] },
          {
            id: 'v15',
            status: 'staging',
            model: 'Claude Opus 4.5',
            tools: ['git', 'test-runner', 'linter', 'profiler'],
            memory: 'persistent',
            orchestration: 'ReAct',
            promptsHash: 'f13ac0',
            deployedAt: new Date().toISOString().slice(0, 10),
            jobsOnVersion: 0,
          },
        ]
        break
      case 'offline':
        nextAgent.stage = 'trusted'
        nextAgent.condition = 'offline'
        nextAgent.mode = 'autopilot'
        nextAgent.autopilot = { ...INITIAL_AUTOPILOT, enabled: true }
        nextAgent.skills.Backend = { name: 'Backend', verified: true, rating: 2260, uncertainty: 55, proofs: 4, jobs: 26 }
        nextAgent.overallRating = 2260
        nextAgent.earnings = 4980
        nextAgent.paidJobsCount = 26
        nextAgent.totalJobsAttempted = 29
        nextAgent.acceptedJobs = 26
        nextAgent.recentResults = ['picked', 'passed', 'picked', 'picked', 'passed', 'picked', 'picked', 'picked', 'passed', 'picked']
        nextAgent.lastSeenAt = Date.now() - 4 * 60 * 1000
        break
    }

    nextAgent = { ...nextAgent, stage: recomputeStage(nextAgent) }
    setAgent(nextAgent)
    setJobs(nextJobs)
    setActivity(nextActivity)
    setLastOvernightRun(nextOvernight)
  }

  const value = useMemo<AppState>(
    () => ({
      agent,
      jobs,
      activity,
      hydrated,
      lastOvernightRun,
      createAgent,
      connectRuntime,
      markValidated,
      runProof,
      sendAgentToJob,
      completeJob,
      setAutopilot,
      setMode,
      simulateOvernightRun,
      logActivity,
      applyDemoPreset,
    }),
    [agent, jobs, activity, hydrated, lastOvernightRun],
  )

  if (!hydrated) {
    return <AppContext.Provider value={value} />
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
