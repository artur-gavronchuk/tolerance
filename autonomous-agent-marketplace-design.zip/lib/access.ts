import type { Agent, Job } from './types'

/**
 * accessRating(skill) = rating − uncertainty (0 if the skill is not verified).
 * This is the single number every lock and unlock in the app is computed from.
 */
export function accessRating(agent: Agent, skillName: string): number {
  const skill = agent.skills[skillName]
  if (!skill || !skill.verified || skill.rating == null) return 0
  return skill.rating - (skill.uncertainty ?? 0)
}

export type Tier = 'none' | 'verified' | 'strong' | 'elite'

export function tierFor(access: number): Tier {
  if (access >= 2100) return 'elite'
  if (access >= 1800) return 'strong'
  if (access >= 1500) return 'verified'
  return 'none'
}

function lerp(lo: number, hi: number, outLo: number, outHi: number, x: number) {
  const clamped = Math.max(lo, Math.min(x, hi))
  const frac = (clamped - lo) / (hi - lo)
  return Math.round(outLo + frac * (outHi - outLo))
}

function inverseLerp(lo: number, hi: number, outLo: number, outHi: number, y: number) {
  const clampedY = Math.max(outLo, Math.min(y, outHi))
  const frac = (clampedY - outLo) / (outHi - outLo)
  return Math.round(lo + frac * (hi - lo))
}

const STRONG_CEILING_MAX = 1000

/** True elite pricing requires stage 'trusted' AND at least 20 jobs in that skill. */
function eliteUnlocked(agent: Agent, skillName?: string): boolean {
  if (agent.stage !== 'trusted') return false
  if (!skillName) return true
  return (agent.skills[skillName]?.jobs ?? 0) >= 20
}

/** The dollar ceiling a given access rating buys, given the agent's overall stage. */
export function ceilingFor(access: number, agent: Agent, skillName?: string): number {
  const tier = tierFor(access)
  if (tier === 'none') return 0
  if (tier === 'verified') return lerp(1500, 1800, 80, 160, access)
  if (tier === 'strong') return lerp(1800, 2100, 600, 1000, access)
  // elite
  if (!eliteUnlocked(agent, skillName)) return STRONG_CEILING_MAX
  return lerp(2100, 2400, 1000, 2000, access)
}

/** The smallest access rating whose ceiling reaches a given bounty (ignores the trusted/jobs gate). */
export function requiredAccessFor(bounty: number): number {
  if (bounty <= 160) return inverseLerp(1500, 1800, 80, 160, bounty)
  if (bounty <= 1000) return inverseLerp(1800, 2100, 600, 1000, bounty)
  return inverseLerp(2100, 2400, 1000, 2000, bounty)
}

export function isChallenge(job: Job): boolean {
  return job.attempts >= 10
}

export function isEligible(agent: Agent, job: Job): boolean {
  if (agent.condition === 'restricted') return false
  const skill = agent.skills[job.primarySkill]
  if (!skill?.verified) return false

  const access = accessRating(agent, job.primarySkill)
  const tier = tierFor(access)

  if (isChallenge(job)) {
    const perAttempt = job.bounty / job.attempts
    if (ceilingFor(access, agent, job.primarySkill) < perAttempt) return false
  } else if (ceilingFor(access, agent, job.primarySkill) < job.bounty) {
    return false
  }

  if (job.repoVisibility === 'private' && tier !== 'elite') return false
  return true
}

export function lockReason(agent: Agent, job: Job): string {
  const skill = agent.skills[job.primarySkill]
  if (!skill?.verified) return `Needs ${job.primarySkill} (unverified)`

  const access = accessRating(agent, job.primarySkill)
  const tier = tierFor(access)
  const value = isChallenge(job) ? job.bounty / job.attempts : job.bounty

  if (job.repoVisibility === 'private' && tier !== 'elite') {
    return 'Needs Elite (access 2100 + Trusted)'
  }

  const required = requiredAccessFor(value)
  if (required >= 2100 && !eliteUnlocked(agent, job.primarySkill)) {
    return 'Needs Elite (access 2100 + Trusted)'
  }

  if (access < required) {
    return `Needs ${job.primarySkill} access ${required} — you're at ${access} (+${required - access})`
  }
  return `Needs Elite (access 2100 + Trusted)`
}

export interface NextUnlock {
  atAccess: number
  ceiling: number
  jobsCount: number
  totalValue: number
  distance: number
}

/** The next price ceiling above the agent's current one for a skill, and what it unlocks. */
export function nextUnlock(agent: Agent, skillName: string, jobs: Job[]): NextUnlock | null {
  const access = accessRating(agent, skillName)
  const currentCeiling = ceilingFor(access, agent, skillName)
  const candidates = jobs.filter((j) => j.primarySkill === skillName && j.bounty > currentCeiling)
  if (candidates.length === 0) return null

  const nextBounty = Math.min(...candidates.map((j) => j.bounty))
  const atAccess = requiredAccessFor(nextBounty)
  const unlockedAtNext = candidates.filter((j) => j.bounty <= nextBounty)

  return {
    atAccess,
    ceiling: nextBounty,
    jobsCount: unlockedAtNext.length,
    totalValue: unlockedAtNext.reduce((a, j) => a + j.bounty, 0),
    distance: Math.max(0, atAccess - access),
  }
}

export function eligibleJobs(agent: Agent, jobs: Job[]): Job[] {
  return jobs.filter((j) => j.status === 'open' && isEligible(agent, j))
}
