import { accessRating, tierFor } from './access'
import type { Agent, Job, JobDifficulty } from './types'

export const PLATFORM_FEE_RATE = 0.1

export interface PayoutBreakdown {
  gross: number
  fee: number
  compute: number
  net: number
  picked: boolean
  passed: boolean
  othersPassedCount: number
  /** Each passing attempt's cut of the 50% base pool (before any bonus). */
  baseShare: number
}

/**
 * 50% of the bounty is a bonus paid only to the attempt the customer picks.
 * The other 50% is split equally between every attempt that passed checks
 * (the picked one included). If only one attempt passed, it gets 100%.
 * A failing attempt earns nothing.
 */
export function computePayout(
  job: Job,
  opts: { picked: boolean; passed: boolean; othersPassedCount: number; compute: number },
): PayoutBreakdown {
  const bonus = job.bounty * 0.5
  const basePool = job.bounty * 0.5
  const totalPassed = opts.othersPassedCount + (opts.passed ? 1 : 0)

  let gross = 0
  let baseShare = 0
  if (opts.passed) {
    if (totalPassed <= 1) {
      gross = job.bounty
      baseShare = job.bounty
    } else {
      baseShare = basePool / totalPassed
      gross = baseShare + (opts.picked ? bonus : 0)
    }
  }

  const fee = Math.round(gross * PLATFORM_FEE_RATE * 100) / 100
  const net = Math.round((gross - fee - opts.compute) * 100) / 100

  return {
    gross: Math.round(gross * 100) / 100,
    fee,
    compute: opts.compute,
    net,
    picked: opts.picked,
    passed: opts.passed,
    othersPassedCount: opts.othersPassedCount,
    baseShare: Math.round(baseShare * 100) / 100,
  }
}

export function computeEstimate(difficulty: JobDifficulty): number {
  if (difficulty === 'easy') return 3
  if (difficulty === 'medium') return 4.5
  return 6
}

export interface ExpectedNet {
  expected: number
  passChance: number
  pickChance: number
  compute: number
}

/**
 * expectedNet(job, agent) = passChance × baseShare + pickChance × bonus,
 * minus the 10% platform fee, minus the compute estimate.
 */
export function expectedNet(job: Job, agent: Agent): ExpectedNet {
  const access = accessRating(agent, job.primarySkill)
  const tier = tierFor(access)
  const passChance = tier === 'strong' || tier === 'elite' ? 0.85 : tier === 'verified' ? 0.8 : 0.5

  const pickChance = Math.min(0.9, (passChance / job.attempts) * 1.1)
  const compute = computeEstimate(job.difficulty)

  const bonus = job.bounty * 0.5
  const baseShare = job.bounty * 0.5 / job.attempts

  const grossExpected = passChance * baseShare + pickChance * bonus
  const fee = grossExpected * PLATFORM_FEE_RATE
  const expected = Math.round((grossExpected - fee - compute) * 100) / 100

  return { expected, passChance, pickChance, compute }
}

export function formatExpectedNet(job: Job, agent: Agent): string {
  const { expected, passChance, pickChance, compute } = expectedNet(job, agent)
  return `Expected net ≈ $${expected.toFixed(0)} · pass ${Math.round(passChance * 100)}% · pick ${Math.round(pickChance * 100)}% · compute ~$${compute.toFixed(0)}`
}
