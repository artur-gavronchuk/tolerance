export type SkillCategory = 'Backend' | 'Go' | 'Frontend' | 'Database'

export interface SkillNode {
  name: string
  verified: boolean
  rating: number | null
  uncertainty: number | null
  proofs: number
  jobs: number
}

export interface QualificationCategory {
  id: SkillCategory
  label: string
  skills: string[]
  description: string
}

// registered -> connected -> operational -> qualified -> proven -> trusted
export type AgentStage = 'registered' | 'connected' | 'operational' | 'qualified' | 'proven' | 'trusted'

export type AgentMode = 'manual' | 'assisted' | 'autopilot'

export type AgentCondition = 'offline' | 'recalibrating' | 'restricted' | null

export interface AgentVersion {
  id: string
  status: 'production' | 'staging' | 'retired'
  model: string
  tools: string[]
  memory: 'none' | 'session' | 'persistent'
  orchestration: string
  promptsHash: string
  deployedAt: string
  jobsOnVersion: number
}

export type AttemptResult = 'picked' | 'passed' | 'failed'

export interface Agent {
  id: string
  name: string
  description: string
  claimedSkills: string[]
  languages: string[]
  stage: AgentStage
  mode: AgentMode
  condition: AgentCondition
  skills: Record<string, SkillNode>
  overallRating: number
  earnings: number
  paidJobsCount: number
  totalJobsAttempted: number
  acceptedJobs: number
  failedChecks: number
  lastSeenAt: number
  proofsLeftToday: number
  versions: AgentVersion[]
  autopilot: AutopilotConfig
  /** Most recent result first, capped at 10, used for pass-rate stage checks. */
  recentResults: AttemptResult[]
}

export interface AutopilotConfig {
  enabled: boolean
  minBounty: number
  minExpectedNet: number
  maxCompute: number
  categories: string[]
  dailyBudget: number
  maxConcurrent: number
  reposPublicOnly: boolean
  exclude: string[]
}

export type JobStatus = 'open' | 'in_progress' | 'evaluating' | 'completed'

export type JobDifficulty = 'easy' | 'medium' | 'hard'

export interface Job {
  id: string
  title: string
  bounty: number
  skills: string[]
  primarySkill: string
  attempts: number
  difficulty: JobDifficulty
  repoVisibility: 'public' | 'private'
  claimWithinMin: number
  deadlineHours: number
  agentsRequested: number
  slotsFilled: number
  evaluationMethod: string
  status: JobStatus
}

export interface ActivityEvent {
  id: string
  timestamp: number
  kind: 'validation' | 'qualification' | 'job' | 'competition' | 'autopilot' | 'payment' | 'unlock'
  title: string
  detail: string
  amount?: number
}

export interface OvernightRunSummary {
  awayFrom: number
  awayTo: number
  attempted: number
  completed: number
  accepted: number
  running: number
  earned: number
  fees: number
  compute: number
  net: number
  ratingBefore: number
  ratingAfter: number
}

export interface CustomerJob {
  id: string
  title: string
  bounty: number
  agentCount: number
  status: 'running' | 'complete'
  solutions: {
    agentName: string
    testsPassed: string
    hiddenTests: number
    performance: string
    security: 'Passed' | 'Failed'
    evaluation: number
  }[]
}
