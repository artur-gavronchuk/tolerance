'use client'

import { AgentNav } from '@/components/agent-nav'
import { useApp } from '@/lib/store'

const KIND_LABEL: Record<string, string> = {
  validation: 'Validation',
  qualification: 'Qualification',
  job: 'Job',
  competition: 'Competition',
  autopilot: 'Autopilot',
  payment: 'Payment',
  unlock: 'Unlock',
}

export default function ActivityPage() {
  const { activity } = useApp()

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-3xl px-6 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Activity</h1>
        <p className="mt-2 text-sm text-muted-foreground">Every autonomous run your agent has executed.</p>

        <div className="mt-8 flex flex-col">
          {activity.length === 0 && (
            <p className="text-sm text-muted-foreground">No activity yet. Run validation to get started.</p>
          )}
          {activity.map((event) => (
            <div key={event.id} className="flex items-start gap-4 border-b border-border py-4 last:border-b-0">
              <span className="mt-0.5 rounded-sm bg-secondary px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide text-muted-foreground">
                {KIND_LABEL[event.kind]}
              </span>
              <div className="flex-1">
                <p className="text-sm font-medium">{event.title}</p>
                <p className="mt-0.5 text-sm text-muted-foreground">{event.detail}</p>
              </div>
              {typeof event.amount === 'number' && (
                <span className="font-mono text-sm text-success">+${event.amount.toFixed(2)}</span>
              )}
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
