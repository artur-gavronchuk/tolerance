'use client'

import { useState } from 'react'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { AgentNav } from '@/components/agent-nav'
import { Button } from '@/components/ui/button'
import { MonoStat } from '@/components/mono-stat'
import { useApp } from '@/lib/store'

export default function EarningsPage() {
  const { agent, simulateOvernightRun, jobs, lastOvernightRun } = useApp()
  const [showReturn, setShowReturn] = useState(false)
  const completedJobs = jobs.filter((j) => j.status === 'completed')

  const handleSimulate = () => {
    simulateOvernightRun()
    setShowReturn(true)
  }

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-3xl px-6 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Earnings</h1>
        <p className="mt-2 text-sm text-muted-foreground">Revenue and cost of running {agent.name}.</p>

        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3">
          <div className="rounded-md border border-border bg-card p-5">
            <MonoStat label="Total earned" value={`$${agent.earnings.toFixed(2)}`} size="lg" positive />
          </div>
          <div className="rounded-md border border-border bg-card p-5">
            <MonoStat label="Paid jobs" value={String(agent.paidJobsCount)} size="lg" />
          </div>
          <div className="rounded-md border border-border bg-card p-5">
            <MonoStat label="Jobs attempted" value={String(agent.totalJobsAttempted)} size="lg" />
          </div>
        </div>

        {completedJobs.length > 0 && (
          <>
            <h2 className="mt-10 font-mono text-xs uppercase tracking-widest text-muted-foreground">
              Completed jobs
            </h2>
            <div className="mt-3 flex flex-col gap-2">
              {completedJobs.map((job) => (
                <div
                  key={job.id}
                  className="flex items-center justify-between rounded-md border border-border bg-card p-4"
                >
                  <p className="text-sm font-medium">{job.title}</p>
                  <span className="font-mono text-sm text-success">${job.bounty}</span>
                </div>
              ))}
            </div>
          </>
        )}

        <div className="mt-10 flex items-center justify-between rounded-md border border-border bg-card p-5">
          <div>
            <p className="text-sm font-medium">Autopilot</p>
            <p className="text-sm text-muted-foreground">
              {agent.autopilot.enabled ? 'Enabled — accepting matching work automatically.' : 'Disabled.'}
            </p>
          </div>
          <Button variant="outline" render={<Link href="/agent/autopilot" />} nativeButton={false}>
            Configure <ArrowRight className="size-4" />
          </Button>
        </div>

        {agent.autopilot.enabled && !showReturn && (
          <Button size="lg" className="mt-8" onClick={handleSimulate}>
            Simulate returning after autopilot worked overnight
          </Button>
        )}

        {showReturn && lastOvernightRun && (
          <div className="mt-8 rounded-md border-2 border-foreground bg-card p-6">
            <p className="text-xl font-semibold">Good morning.</p>
            <p className="mt-1 text-sm text-muted-foreground">
              {agent.name} worked while you were away.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-4 sm:grid-cols-4">
              <MonoStat label="Attempted" value={`${lastOvernightRun.attempted} jobs`} />
              <MonoStat label="Completed" value={String(lastOvernightRun.completed)} />
              <MonoStat label="Accepted" value={String(lastOvernightRun.accepted)} />
              <MonoStat label="Running" value={String(lastOvernightRun.running)} />
            </div>
            <div className="mt-5 grid grid-cols-4 gap-4 border-t border-border pt-5">
              <MonoStat label="Earned" value={`$${lastOvernightRun.earned.toFixed(2)}`} positive />
              <MonoStat label="Fees" value={`$${lastOvernightRun.fees.toFixed(2)}`} negative />
              <MonoStat label="Compute" value={`$${lastOvernightRun.compute.toFixed(2)}`} negative />
              <MonoStat label="Net" value={`$${lastOvernightRun.net.toFixed(2)}`} positive />
            </div>
            <p className="mt-5 text-sm text-muted-foreground">
              Rating{' '}
              <span className="font-mono text-foreground">
                {lastOvernightRun.ratingBefore} → {lastOvernightRun.ratingAfter}
              </span>
            </p>
            <Button className="mt-5" render={<Link href="/agent/activity" />} nativeButton={false}>
              View activity <ArrowRight className="size-4" />
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
