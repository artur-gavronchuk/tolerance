'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { AgentNav } from '@/components/agent-nav'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'

const CATEGORIES = ['Backend', 'Go', 'Database', 'Frontend']

export default function AutopilotPage() {
  const router = useRouter()
  const { agent, setAutopilot, setMode } = useApp()
  const [config, setConfig] = useState(agent.autopilot)

  const toggleCategory = (cat: string) => {
    setConfig((c) => ({
      ...c,
      categories: c.categories.includes(cat) ? c.categories.filter((x) => x !== cat) : [...c.categories, cat],
    }))
  }

  const handleEnable = () => {
    setAutopilot({ ...config, enabled: true })
    setMode('autopilot')
    router.push('/agent/earnings')
  }

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-2xl px-6 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Autopilot</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Let {agent.name} automatically accept matching work. Build once, let it work.
        </p>

        <div className="mt-8 flex flex-col gap-6">
          <div className="flex flex-col gap-2">
            <Label>Minimum bounty</Label>
            <Input
              type="number"
              value={config.minBounty}
              onChange={(e) => setConfig((c) => ({ ...c, minBounty: Number(e.target.value) }))}
              className="font-mono"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>Maximum compute per job ($)</Label>
            <Input
              type="number"
              value={config.maxCompute}
              onChange={(e) => setConfig((c) => ({ ...c, maxCompute: Number(e.target.value) }))}
              className="font-mono"
            />
          </div>

          <div className="flex flex-col gap-3">
            <Label>Categories</Label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => toggleCategory(cat)}
                  className={cn(
                    'rounded-sm border px-3 py-1.5 text-sm transition',
                    config.categories.includes(cat)
                      ? 'border-foreground bg-foreground text-background'
                      : 'border-border text-muted-foreground hover:border-foreground/40',
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <Label>Minimum expected net ($)</Label>
            <Input
              type="number"
              value={config.minExpectedNet}
              onChange={(e) => setConfig((c) => ({ ...c, minExpectedNet: Number(e.target.value) }))}
              className="font-mono"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>Maximum concurrent jobs</Label>
            <Input
              type="number"
              value={config.maxConcurrent}
              onChange={(e) => setConfig((c) => ({ ...c, maxConcurrent: Number(e.target.value) }))}
              className="font-mono"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>Daily compute budget ($)</Label>
            <Input
              type="number"
              value={config.dailyBudget}
              onChange={(e) => setConfig((c) => ({ ...c, dailyBudget: Number(e.target.value) }))}
              className="font-mono"
            />
          </div>

          <Button size="lg" onClick={handleEnable} className="w-fit">
            Enable Autopilot
          </Button>
        </div>
      </main>
    </div>
  )
}
