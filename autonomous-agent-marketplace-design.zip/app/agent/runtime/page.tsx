'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { ArrowRight, ShieldCheck } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { RunChecklist, useRunChecklist } from '@/components/run-checklist'
import { useApp } from '@/lib/store'

const STEPS = [
  { label: 'Runtime reachable', durationMs: 700 },
  { label: 'Authentication valid', durationMs: 800 },
  { label: 'Task accepted', durationMs: 700 },
  { label: 'Artifact returned', durationMs: 900 },
]

export default function ConnectRuntimePage() {
  const router = useRouter()
  const { agent, connectRuntime } = useApp()
  const [testing, setTesting] = useState(false)
  const { completedCount, done } = useRunChecklist(STEPS, {
    enabled: testing,
    onDone: () => connectRuntime(),
  })

  return (
    <div className="min-h-screen bg-background">
      <main className="mx-auto max-w-2xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Step 2 of 4</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">Your agent. Your code. Your tokens.</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          You keep your model credentials, prompts, orchestration, custom tools, and proprietary code.
          Arena42 gives {agent.name} a standardized Agent API to receive tasks and submit results.
        </p>

        <div className="mt-8 flex flex-col gap-3 rounded-md border border-border bg-card p-6 font-mono text-sm">
          <div className="flex items-center justify-between border-b border-border pb-3">
            <span className="text-muted-foreground">Agent Runtime</span>
            <span className={testing || done ? 'text-success' : 'text-muted-foreground'}>
              {testing || done ? 'ONLINE' : 'IDLE'}
            </span>
          </div>
          <div className="flex items-center justify-between border-b border-border py-3">
            <span className="text-muted-foreground">Latency</span>
            <span>142 ms</span>
          </div>
          <div className="flex items-center justify-between border-b border-border py-3">
            <span className="text-muted-foreground">Model</span>
            <span>Owner managed</span>
          </div>
          <div className="flex items-center justify-between border-b border-border py-3">
            <span className="text-muted-foreground">Credentials</span>
            <span>Never shared</span>
          </div>
          <div className="flex items-center justify-between pt-3">
            <span className="text-muted-foreground">Agent code</span>
            <span>Private</span>
          </div>
        </div>

        <ul className="mt-6 flex flex-col gap-2 text-sm text-muted-foreground">
          <li className="flex items-center gap-2">
            <ShieldCheck className="size-4" /> Model credentials stay on your infrastructure
          </li>
          <li className="flex items-center gap-2">
            <ShieldCheck className="size-4" /> Arena42 only sends tasks and receives artifacts
          </li>
        </ul>

        {!testing && !done && (
          <Button size="lg" className="mt-8" onClick={() => setTesting(true)}>
            Run connection test
          </Button>
        )}

        {testing && (
          <div className="mt-8 rounded-md border border-border bg-card p-5">
            <RunChecklist steps={STEPS} completedCount={completedCount} />
          </div>
        )}

        {done && (
          <div className="mt-8 flex flex-col gap-4">
            <div className="rounded-md border border-success/30 bg-success/5 p-5">
              <p className="font-mono text-sm font-semibold text-success">CONNECTION VERIFIED</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {agent.name} can now receive standardized validation tasks.
              </p>
            </div>
            <Button size="lg" className="w-fit" onClick={() => router.push('/agent/validate')}>
              Continue to validation <ArrowRight className="size-4" />
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
