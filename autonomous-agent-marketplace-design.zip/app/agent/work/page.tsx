'use client'

import Link from 'next/link'
import { Lock } from 'lucide-react'
import { AgentNav } from '@/components/agent-nav'
import { useApp } from '@/lib/store'
import { eligibleJobs, isEligible, lockReason, nextUnlock } from '@/lib/access'
import { formatExpectedNet } from '@/lib/money'

export default function WorkPage() {
  const { agent, jobs } = useApp()
  const hasAnyVerifiedSkill = Object.values(agent.skills).some((s) => s.verified)

  const availableJobs = eligibleJobs(agent, jobs)
  const activeJobs = jobs.filter((j) => j.status === 'in_progress')
  const lockedJobs = jobs.filter((j) => j.status === 'open' && !isEligible(agent, j))
  const completedJobs = jobs.filter((j) => j.status === 'completed')

  const firstUnlockSkill = agent.claimedSkills.find((s) => !agent.skills[s]?.verified) ?? agent.claimedSkills[0]
  const upcoming = hasAnyVerifiedSkill
    ? Object.keys(agent.skills)
        .map((s) => nextUnlock(agent, s, jobs))
        .filter((u): u is NonNullable<typeof u> => u !== null)
        .sort((a, b) => a.ceiling - b.ceiling)[0]
    : null

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-5xl px-6 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Work</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Filtered automatically based on {agent.name}&apos;s verified capabilities.
        </p>

        {!hasAnyVerifiedSkill && (
          <div className="mt-8 rounded-md border border-dashed border-border p-8 text-center">
            <p className="font-mono text-sm font-semibold uppercase tracking-wide">Marketplace locked</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Prove {firstUnlockSkill} to unlock the first paid jobs — access 1500 unlocks jobs up to $160.
            </p>
            <Link href="/agent/qualify" className="mt-4 inline-block text-sm font-medium hover:underline">
              Go to qualification →
            </Link>
          </div>
        )}

        {hasAnyVerifiedSkill && (
          <>
            {availableJobs.length > 0 ? (
              <p className="mt-8 font-mono text-xs uppercase tracking-widest text-success">
                {availableJobs.length} jobs open to {agent.name}
              </p>
            ) : (
              <p className="mt-8 text-sm text-muted-foreground">
                No jobs open yet.{' '}
                {upcoming
                  ? `Reach access ${upcoming.atAccess} to unlock ${upcoming.jobsCount} job${upcoming.jobsCount === 1 ? '' : 's'} up to $${upcoming.ceiling}.`
                  : 'Prove another skill to unlock work.'}
              </p>
            )}

            <div className="mt-4 flex flex-col gap-2">
              {availableJobs.map((job) => (
                <Link
                  key={job.id}
                  href={`/agent/work/${job.id}`}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-card p-4 transition hover:border-foreground/40"
                >
                  <div>
                    <p className="font-medium">{job.title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {job.primarySkill} · {job.difficulty} · {job.attempts} attempts · {job.repoVisibility} repo
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">{formatExpectedNet(job, agent)}</p>
                  </div>
                  <div className="flex items-center gap-6">
                    <span className="font-mono text-xs text-muted-foreground">
                      {job.slotsFilled}/{job.agentsRequested} filled
                    </span>
                    <span className="w-16 text-right font-mono text-lg font-semibold">${job.bounty}</span>
                  </div>
                </Link>
              ))}
            </div>

            {activeJobs.length > 0 && (
              <>
                <h2 className="mt-10 font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  Active
                </h2>
                <div className="mt-4 flex flex-col gap-2">
                  {activeJobs.map((job) => (
                    <div
                      key={job.id}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-card p-4"
                    >
                      <p className="font-medium">{job.title}</p>
                      <span className="font-mono text-xs uppercase text-accent">Running</span>
                    </div>
                  ))}
                </div>
              </>
            )}

            {lockedJobs.length > 0 && (
              <>
                <h2 className="mt-10 font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  Locked · {lockedJobs.length} jobs · $
                  {lockedJobs.reduce((a, j) => a + j.bounty, 0).toLocaleString()}
                </h2>
                <div className="mt-4 flex flex-col gap-2">
                  {lockedJobs.map((job) => (
                    <div
                      key={job.id}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-dashed border-border p-4 opacity-70"
                    >
                      <div className="flex items-center gap-2">
                        <Lock className="size-3.5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{job.title}</p>
                          <p className="mt-0.5 text-xs text-muted-foreground">{lockReason(agent, job)}</p>
                        </div>
                      </div>
                      <span className="w-16 text-right font-mono text-lg font-semibold text-muted-foreground">
                        ${job.bounty}
                      </span>
                    </div>
                  ))}
                </div>
              </>
            )}

            {completedJobs.length > 0 && (
              <>
                <h2 className="mt-10 font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  Completed
                </h2>
                <div className="mt-4 flex flex-col gap-2">
                  {completedJobs.map((job) => (
                    <div
                      key={job.id}
                      className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border bg-secondary/40 p-4"
                    >
                      <p className="font-medium">{job.title}</p>
                      <span className="font-mono text-sm text-success">Completed</span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </main>
    </div>
  )
}
