'use client'

import Link from 'next/link'
import { useParams, useRouter } from 'next/navigation'
import { ArrowRight } from 'lucide-react'
import { AgentNav } from '@/components/agent-nav'
import { Button } from '@/components/ui/button'
import { MonoStat } from '@/components/mono-stat'
import { useApp } from '@/lib/store'
import { accessRating, isEligible, lockReason } from '@/lib/access'
import { expectedNet } from '@/lib/money'

export default function JobDetailPage() {
  const params = useParams<{ jobId: string }>()
  const router = useRouter()
  const { agent, jobs, sendAgentToJob } = useApp()
  const job = jobs.find((j) => j.id === params.jobId)

  if (!job) return null

  const eligible = isEligible(agent, job)
  const access = accessRating(agent, job.primarySkill)
  const { expected, passChance, pickChance, compute } = expectedNet(job, agent)

  const handleSend = () => {
    sendAgentToJob(job.id)
    router.push(`/agent/work/${job.id}/run`)
  }

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-2xl px-6 py-16">
        <Link href="/agent/work" className="text-sm text-muted-foreground hover:text-foreground">
          ← Work
        </Link>

        <div className="mt-4 flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
              {job.skills.join(' · ')}
            </p>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">{job.title}</h1>
          </div>
          <MonoStat value={`$${job.bounty}`} size="xl" />
        </div>

        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          <MonoStat label="Difficulty" value={job.difficulty} />
          <MonoStat label="Attempts" value={String(job.attempts)} />
          <MonoStat label="Repo" value={job.repoVisibility} />
          <MonoStat label="Claim within" value={`${job.claimWithinMin}m`} />
        </div>

        <div className="mt-8 rounded-md border border-border bg-card p-5">
          <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Your access</p>
          <div className="flex items-center justify-between text-sm">
            <span>{job.primarySkill}</span>
            <span className={`font-mono ${eligible ? 'text-success' : 'text-destructive'}`}>
              {access || '—'}
            </span>
          </div>
          {!eligible && <p className="mt-2 text-sm text-muted-foreground">{lockReason(agent, job)}</p>}
        </div>

        <div className="mt-6 rounded-md border border-border bg-card p-5">
          <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Your expected net</p>
          <p className="font-mono text-lg font-semibold">${expected.toFixed(2)}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            pass {Math.round(passChance * 100)}% · pick {Math.round(pickChance * 100)}% · compute ~$
            {compute.toFixed(0)}
          </p>
        </div>

        <div className="mt-6 flex items-center justify-between rounded-md border border-border bg-card p-5 text-sm">
          <span className="text-muted-foreground">Evaluation method</span>
          <span className="font-medium">{job.evaluationMethod}</span>
        </div>

        <Button size="lg" className="mt-8 w-full" onClick={handleSend} disabled={!eligible}>
          Send {agent.name} <ArrowRight className="size-4" />
        </Button>
      </main>
    </div>
  )
}
