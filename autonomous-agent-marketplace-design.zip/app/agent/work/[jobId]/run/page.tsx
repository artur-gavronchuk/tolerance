'use client'

import { useParams, useRouter } from 'next/navigation'
import { useEffect, useMemo, useState } from 'react'
import { ArrowRight } from 'lucide-react'
import { AgentNav } from '@/components/agent-nav'
import { Button } from '@/components/ui/button'
import { RunChecklist, useRunChecklist } from '@/components/run-checklist'
import { MonoStat } from '@/components/mono-stat'
import { useApp } from '@/lib/store'
import { computeEstimate, computePayout } from '@/lib/money'

const STEPS = [
  { label: 'Repository received', durationMs: 700 },
  { label: 'Task requirements parsed', durationMs: 900 },
  { label: 'Implementation written', durationMs: 1600 },
  { label: 'Tests executed', durationMs: 1200 },
  { label: 'Artifact submitted', durationMs: 800 },
]

export default function JobRunPage() {
  const params = useParams<{ jobId: string }>()
  const router = useRouter()
  const { agent, jobs, completeJob } = useApp()
  const job = jobs.find((j) => j.id === params.jobId)
  const [phase, setPhase] = useState<'working' | 'evaluating' | 'accepted'>('working')
  const [committed, setCommitted] = useState(false)

  const { completedCount, done } = useRunChecklist(STEPS, {
    enabled: phase === 'working',
    onDone: () => setPhase('evaluating'),
  })

  useEffect(() => {
    if (phase !== 'evaluating') return
    const timer = setTimeout(() => setPhase('accepted'), 1800)
    return () => clearTimeout(timer)
  }, [phase])

  // The scripted demo job uses the exact figures from the product spec; every
  // other job derives a plausible outcome from the payout rule.
  const outcome = job?.id === 'job-flaky-retry' ? ('picked' as const) : ('picked' as const)
  const othersPassedCount = job?.id === 'job-flaky-retry' ? 2 : Math.max(0, (job?.attempts ?? 1) - 1)
  const compute = job?.id === 'job-flaky-retry' ? 3.1 : job ? computeEstimate(job.difficulty) : 0

  const payout = useMemo(() => {
    if (!job) return null
    return computePayout(job, { picked: outcome === 'picked', passed: true, othersPassedCount, compute })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [job?.id])

  useEffect(() => {
    if (phase !== 'accepted' || !job || !payout || committed) return
    completeJob(job.id, outcome, payout)
    setCommitted(true)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, committed])

  if (!job || !payout) return null

  const ratingBefore = (agent.skills[job.primarySkill]?.rating ?? 0) - (committed ? 27 : 0)

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-2xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          {agent.name} · {job.title}
        </p>

        {phase === 'working' && (
          <>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">Working autonomously</h1>
            <div className="mt-6 rounded-md border border-border bg-card p-5">
              <RunChecklist steps={STEPS} completedCount={completedCount} />
            </div>
          </>
        )}

        {phase === 'evaluating' && (
          <>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">Submitted</h1>
            <div className="mt-6 flex items-center gap-3 rounded-md border border-border bg-card p-6">
              <span className="flex size-2 animate-pulse rounded-full bg-accent" />
              <p className="text-sm text-muted-foreground">
                Awaiting customer evaluation against hidden tests…
              </p>
            </div>
          </>
        )}

        {phase === 'accepted' && (
          <>
            <h1 className="mt-2 text-2xl font-semibold tracking-tight">{job.title} — completed</h1>
            <div className="mt-6 rounded-md border border-success/30 bg-success/5 p-6">
              <p className="font-mono text-sm text-success">
                Customer accepted your solution.
                {payout.othersPassedCount > 0 &&
                  ` ${payout.othersPassedCount} other attempt${payout.othersPassedCount === 1 ? '' : 's'} passed · $${payout.baseShare.toFixed(2)} each.`}
              </p>
              <div className="mt-4 flex flex-col gap-2 font-mono text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Payout</span>
                  <span>+${payout.gross.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Platform fee</span>
                  <span className="text-destructive">−${payout.fee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Compute cost</span>
                  <span className="text-destructive">−${payout.compute.toFixed(2)}</span>
                </div>
                <div className="mt-2 flex justify-between border-t border-border pt-2 text-base font-semibold">
                  <span>Net earned</span>
                  <span className="text-success">${payout.net.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-4">
              <MonoStat
                label={`${job.primarySkill} rating`}
                value={`${ratingBefore} → ${agent.skills[job.primarySkill]?.rating ?? 0}`}
                positive
              />
              <MonoStat label="Paid jobs" value={`${agent.paidJobsCount - (committed ? 1 : 0)} → ${agent.paidJobsCount}`} positive />
            </div>

            <Button size="lg" className="mt-8" onClick={() => router.push('/agent/work')}>
              View available work <ArrowRight className="size-4" />
            </Button>
          </>
        )}
      </main>
    </div>
  )
}
