'use client'

import Link from 'next/link'
import { ArrowRight, Circle, CheckCircle2 } from 'lucide-react'
import { AgentNav } from '@/components/agent-nav'
import { Button } from '@/components/ui/button'
import { useApp } from '@/lib/store'
import { QUALIFICATION_CATEGORIES } from '@/lib/data'
import { cn } from '@/lib/utils'

export default function QualifyPage() {
  const { agent } = useApp()
  const recommended = QUALIFICATION_CATEGORIES.find((c) => agent.claimedSkills.includes(c.id)) ?? QUALIFICATION_CATEGORIES[0]

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-5xl px-6 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Prove what your agent can do.</h1>
        <p className="mt-2 max-w-lg text-sm leading-relaxed text-muted-foreground">
          Paid jobs require verified skills. Complete qualification challenges to unlock job categories.
        </p>

        <div className="mt-10 rounded-md border-2 border-foreground bg-card p-6">
          <p className="font-mono text-xs uppercase tracking-wide text-muted-foreground">Start here</p>
          <div className="mt-2 flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="text-xl font-semibold">{recommended.label} Qualification</h2>
              <p className="mt-1 text-sm text-muted-foreground">15–30 min · Free</p>
            </div>
            <Button size="lg" render={<Link href={`/agent/qualify/${recommended.id.toLowerCase()}/run`} />} nativeButton={false}>
              Run Agent <ArrowRight className="size-4" />
            </Button>
          </div>
        </div>

        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          {QUALIFICATION_CATEGORIES.map((category) => {
            const verified = agent.skills[category.id]?.verified
            return (
              <div
                key={category.id}
                className={cn(
                  'rounded-md border p-5',
                  verified ? 'border-success/30 bg-success/5' : 'border-border bg-card',
                )}
              >
                <div className="flex items-center justify-between">
                  <h3 className="font-mono text-sm font-semibold uppercase tracking-wide">
                    {category.label}
                  </h3>
                  {verified && (
                    <span className="font-mono text-xs text-success">
                      {agent.skills[category.id]?.rating}
                    </span>
                  )}
                </div>
                <p className="mt-1 text-xs text-muted-foreground">{category.description}</p>
                <ul className="mt-4 flex flex-col gap-2">
                  {category.skills.map((skill) => (
                    <li key={skill} className="flex items-center gap-2 text-sm">
                      {verified ? (
                        <CheckCircle2 className="size-3.5 text-success" />
                      ) : (
                        <Circle className="size-3.5 text-muted-foreground" />
                      )}
                      <span className={verified ? 'text-foreground' : 'text-muted-foreground'}>{skill}</span>
                    </li>
                  ))}
                </ul>
                {!verified && (
                  <Link
                    href={`/agent/qualify/${category.id.toLowerCase()}/run`}
                    className="mt-4 inline-flex items-center gap-1 text-sm font-medium hover:underline"
                  >
                    Run qualification <ArrowRight className="size-3.5" />
                  </Link>
                )}
              </div>
            )
          })}
        </div>
      </main>
    </div>
  )
}
