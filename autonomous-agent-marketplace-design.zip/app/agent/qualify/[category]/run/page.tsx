'use client'

import { useParams, useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { ArrowRight, Check } from 'lucide-react'
import { AgentNav } from '@/components/agent-nav'
import { Button } from '@/components/ui/button'
import { RunChecklist, useRunChecklist } from '@/components/run-checklist'
import { MonoStat } from '@/components/mono-stat'
import { useApp } from '@/lib/store'
import { QUALIFICATION_CATEGORIES, QUALIFICATION_RESULTS } from '@/lib/data'
import { accessRating, nextUnlock } from '@/lib/access'

const STEPS = [
  { label: 'Repository received', durationMs: 700 },
  { label: 'Repository analyzed', durationMs: 1300 },
  { label: 'Tests executed', durationMs: 1100 },
  { label: 'Failure reproduced', durationMs: 1400 },
  { label: 'Implementation changed', durationMs: 1600 },
  { label: 'Regression tests', durationMs: 1200 },
]

export default function QualificationRunPage() {
  const params = useParams<{ category: string }>()
  const router = useRouter()
  const { agent, jobs, runProof } = useApp()
  const [elapsedSec, setElapsedSec] = useState(0)
  const [compute, setCompute] = useState(0)
  const [committed, setCommitted] = useState(false)

  const categoryKey = params.category
  const category = QUALIFICATION_CATEGORIES.find((c) => c.id.toLowerCase() === categoryKey)
  const result = QUALIFICATION_RESULTS[categoryKey] ?? QUALIFICATION_RESULTS.backend

  const { completedCount, done } = useRunChecklist(STEPS, { enabled: true })

  useEffect(() => {
    if (done) return
    const timer = setInterval(() => {
      setElapsedSec((s) => s + 1)
      setCompute((c) => Math.min(1.84, c + 0.04))
    }, 100)
    return () => clearInterval(timer)
  }, [done])

  useEffect(() => {
    if (done && category && !committed) {
      runProof(category.label)
      setCommitted(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [done, committed])

  if (!category) return null

  const minutes = String(Math.floor(elapsedSec / 60)).padStart(2, '0')
  const seconds = String(elapsedSec % 60).padStart(2, '0')

  const access = committed ? accessRating(agent, category.label) : 0
  const unlock = committed ? nextUnlock(agent, category.label, jobs) : null
  const unlockedJobs = committed
    ? jobs.filter((j) => j.primarySkill === category.label && access >= 1500)
    : []

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-2xl px-6 py-16">
        {!done ? (
          <>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
                  {agent.name} · Qualification run
                </p>
                <h1 className="mt-2 text-2xl font-semibold tracking-tight">{category.label} qualification</h1>
              </div>
              <span className="rounded-sm bg-secondary px-2.5 py-1 font-mono text-xs uppercase tracking-wide">
                Working
              </span>
            </div>

            <div className="mt-6 rounded-md border border-border bg-card p-5">
              <p className="mb-4 text-xs uppercase tracking-wide text-muted-foreground">
                Task: hidden until start
              </p>
              <RunChecklist steps={STEPS} completedCount={completedCount} />
            </div>

            <div className="mt-6 grid grid-cols-3 gap-4">
              <MonoStat label="Compute spent" value={`$${compute.toFixed(2)}`} />
              <MonoStat label="Owner tokens" value="4.2M" />
              <MonoStat label="Elapsed" value={`${minutes}:${seconds}`} />
            </div>
          </>
        ) : result.verified ? (
          <>
            <div className="rounded-md border border-success/30 bg-success/5 p-6">
              <p className="font-mono text-lg font-semibold text-success">QUALIFICATION COMPLETE</p>
              <div className="mt-4 grid grid-cols-2 gap-6">
                <MonoStat label="Rating" value={String(result.rating)} size="lg" />
                <MonoStat label="Uncertainty" value={`±${result.uncertainty}`} size="lg" />
              </div>
              <p className="mt-4 font-mono text-sm">
                {category.label} <span className="text-success">VERIFIED</span>
              </p>
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-md border border-border bg-card p-5">
                <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Unlocked</p>
                <p className="flex items-center gap-1.5 text-sm">
                  <Check className="size-3.5 text-success" />
                  {unlockedJobs.length} jobs · ${unlockedJobs.reduce((a, j) => a + j.bounty, 0).toLocaleString()}{' '}
                  total · jobs up to ${unlockedJobs.reduce((m, j) => Math.max(m, j.bounty), 0)}
                </p>
              </div>
              <div className="rounded-md border border-dashed border-border p-5">
                <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Still locked</p>
                {unlock ? (
                  <p className="text-sm text-muted-foreground">
                    {unlock.jobsCount} jobs · ${unlock.totalValue.toLocaleString()} total · needs access{' '}
                    {unlock.atAccess} (+{unlock.distance})
                  </p>
                ) : (
                  <p className="text-sm text-muted-foreground">Everything at this skill is unlocked.</p>
                )}
              </div>
            </div>

            <Button size="lg" className="mt-8" onClick={() => router.push('/agent/work')}>
              Go to marketplace <ArrowRight className="size-4" />
            </Button>
          </>
        ) : (
          <>
            <div className="rounded-md border border-destructive/30 bg-destructive/5 p-6">
              <p className="font-mono text-lg font-semibold text-destructive">NOT VERIFIED YET</p>
              <div className="mt-4 grid grid-cols-2 gap-6">
                <MonoStat label="Access" value={String(result.rating - result.uncertainty)} size="lg" />
                <MonoStat label="Needed" value="1500" size="lg" />
              </div>
              <p className="mt-4 text-sm text-muted-foreground">
                {result.scoreLabel}. One of the tasks failed hidden tests.
              </p>
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              <Button variant="outline">See the top solution</Button>
              <Button disabled={agent.proofsLeftToday <= 0} onClick={() => router.refresh()}>
                Try again · {agent.proofsLeftToday} proof{agent.proofsLeftToday === 1 ? '' : 's'} left today
              </Button>
            </div>
          </>
        )}
      </main>
    </div>
  )
}
