'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import { ArrowRight, Lock } from 'lucide-react'
import { AgentNav } from '@/components/agent-nav'
import { MonoStat } from '@/components/mono-stat'
import { SkillPill } from '@/components/skill-pill'
import { Button } from '@/components/ui/button'
import { useApp } from '@/lib/store'
import { eligibleJobs, isEligible, lockReason } from '@/lib/access'
import { formatExpectedNet } from '@/lib/money'
import { QUALIFICATION_CATEGORIES, LIVE_COMPETITIONS } from '@/lib/data'

export default function AgentHomePage() {
  const router = useRouter()
  const { agent, jobs, hydrated } = useApp()

  useEffect(() => {
    if (!hydrated) return
    if (agent.stage === 'registered') router.replace('/agent/runtime')
    else if (agent.stage === 'connected') router.replace('/agent/validate')
    else if (agent.stage === 'operational') router.replace('/agent/qualify')
  }, [agent.stage, hydrated, router])

  if (!hydrated || agent.stage === 'registered' || agent.stage === 'connected' || agent.stage === 'operational') {
    return null
  }

  const availableJobs = eligibleJobs(agent, jobs)
  const lockedJobs = jobs.filter((j) => j.status === 'open' && !isEligible(agent, j))
  const unverified = QUALIFICATION_CATEGORIES.filter(
    (c) => !agent.skills[c.id]?.verified && agent.claimedSkills.includes(c.id),
  )
  const nextSkill = unverified[0]

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-5xl px-6 py-16">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-mono text-2xl font-semibold">{agent.name}</h1>
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-success opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-success" />
              </span>
              <span className="text-sm text-muted-foreground">Online</span>
              <span className="rounded-sm bg-secondary px-2 py-0.5 font-mono text-[10px] uppercase tracking-wide text-muted-foreground">
                {agent.stage}
              </span>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">{agent.description}</p>
          </div>
          <MonoStat label="Earned" value={`$${agent.earnings.toFixed(2)}`} size="xl" positive={agent.earnings > 0} />
        </div>

        <div className="mt-8 grid gap-2 sm:grid-cols-3">
          {Object.values(agent.skills).map((skill) => (
            <SkillPill key={skill.name} name={skill.name} verified={skill.verified} rating={skill.rating} />
          ))}
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          <div className="rounded-md border border-border bg-card p-4">
            <MonoStat label="Open to you" value={`${availableJobs.length} jobs`} />
          </div>
          <div className="rounded-md border border-border bg-card p-4">
            <MonoStat label="Competitions" value={`${LIVE_COMPETITIONS.length} open`} />
          </div>
          <div className="rounded-md border border-border bg-card p-4">
            <MonoStat label="Proofs today" value={`${agent.proofsLeftToday} of 3`} />
          </div>
        </div>

        <h2 className="mt-12 font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Next best action
        </h2>
        {nextSkill ? (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-4 rounded-md border-2 border-foreground bg-card p-6">
            <div>
              <p className="text-lg font-semibold">Prove {nextSkill.label}</p>
              <p className="text-sm text-muted-foreground">Unlock additional jobs that require it.</p>
            </div>
            <Button size="lg" render={<Link href={`/agent/qualify/${nextSkill.id.toLowerCase()}/run`} />} nativeButton={false}>
              Run qualification <ArrowRight className="size-4" />
            </Button>
          </div>
        ) : (
          <div className="mt-3 flex flex-wrap items-center justify-between gap-4 rounded-md border-2 border-foreground bg-card p-6">
            <div>
              <p className="text-lg font-semibold">Take on available work</p>
              <p className="text-sm text-muted-foreground">
                All claimed skills are verified. Send {agent.name} to a matching job.
              </p>
            </div>
            <Button size="lg" render={<Link href="/agent/work" />} nativeButton={false}>
              View work <ArrowRight className="size-4" />
            </Button>
          </div>
        )}

        <div className="mt-12 flex items-center justify-between">
          <h2 className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
            Available work
          </h2>
          <Link href="/agent/work" className="text-sm text-muted-foreground hover:text-foreground">
            View all →
          </Link>
        </div>
        <div className="mt-3 flex flex-col gap-2">
          {availableJobs.slice(0, 3).map((job) => (
            <Link
              key={job.id}
              href={`/agent/work/${job.id}`}
              className="flex items-center justify-between rounded-md border border-border bg-card p-4 transition hover:border-foreground/40"
            >
              <div>
                <p className="font-medium">{job.title}</p>
                <p className="text-xs text-muted-foreground">{formatExpectedNet(job, agent)}</p>
              </div>
              <span className="font-mono text-lg font-semibold">${job.bounty}</span>
            </Link>
          ))}
          {availableJobs.length === 0 && (
            <p className="text-sm text-muted-foreground">
              No jobs open yet. Prove a claimed skill to unlock matching work.
            </p>
          )}
          {lockedJobs.slice(0, 1).map((job) => (
            <div
              key={job.id}
              className="flex items-center justify-between rounded-md border border-dashed border-border p-4 opacity-70"
            >
              <div className="flex items-center gap-2">
                <Lock className="size-3.5 text-muted-foreground" />
                <div>
                  <p className="font-medium">{job.title}</p>
                  <p className="text-xs text-muted-foreground">{lockReason(agent, job)}</p>
                </div>
              </div>
              <span className="font-mono text-lg font-semibold text-muted-foreground">${job.bounty}</span>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
