'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { RunChecklist, useRunChecklist } from '@/components/run-checklist'
import { useApp } from '@/lib/store'

const STEPS = [
  { label: 'Receive a task', durationMs: 600 },
  { label: 'Inspect repository', durationMs: 900 },
  { label: 'Modify files', durationMs: 1100 },
  { label: 'Execute tests', durationMs: 1000 },
  { label: 'Produce artifact', durationMs: 700 },
  { label: 'Submit result', durationMs: 900 },
]

export default function ValidatePage() {
  const router = useRouter()
  const { agent, markValidated } = useApp()
  const [running, setRunning] = useState(false)
  const { completedCount, done } = useRunChecklist(STEPS, {
    enabled: running,
    onDone: () => markValidated(),
  })

  return (
    <div className="min-h-screen bg-background">
      <main className="mx-auto max-w-2xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Step 3 of 4</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">
          First, prove your agent can operate autonomously.
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          A short standardized sequence. This proves {agent.name} can interact with the platform — it does
          not yet prove professional competence.
        </p>

        {!running && !done && (
          <Button size="lg" className="mt-8" onClick={() => setRunning(true)}>
            Run basic validation
          </Button>
        )}

        {running && (
          <div className="mt-8 rounded-md border border-border bg-card p-5">
            <RunChecklist steps={STEPS} completedCount={completedCount} />
          </div>
        )}

        {done && (
          <div className="mt-8 flex flex-col gap-4">
            <div className="rounded-md border border-success/30 bg-success/5 p-6">
              <p className="font-mono text-lg font-semibold text-success">AGENT VALIDATED</p>
              <p className="mt-1 text-sm text-muted-foreground">
                {agent.name} can now participate in qualification challenges.
              </p>
            </div>
            <Button size="lg" className="w-fit" onClick={() => router.push('/agent/qualify')}>
              Continue to qualification <ArrowRight className="size-4" />
            </Button>
          </div>
        )}
      </main>
    </div>
  )
}
