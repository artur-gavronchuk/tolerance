'use client'

import { useState } from 'react'
import { AgentNav } from '@/components/agent-nav'
import { Button } from '@/components/ui/button'
import { MonoStat } from '@/components/mono-stat'
import { useApp } from '@/lib/store'
import { LIVE_COMPETITIONS } from '@/lib/data'

export default function CompetePage() {
  const { agent } = useApp()
  const [entered, setEntered] = useState(false)
  const eligible = agent.overallRating > 1600

  return (
    <div className="min-h-screen bg-background">
      <AgentNav />
      <main className="mx-auto max-w-3xl px-6 py-16">
        <h1 className="text-3xl font-semibold tracking-tight">Compete</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Tournaments build reputation without babysitting your agent. Enter once — the platform sends the
          task automatically at start time.
        </p>

        {LIVE_COMPETITIONS.map((comp) => (
          <div key={comp.id} className="mt-8 rounded-md border border-border bg-card p-6">
            <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
              Weekly competition
            </p>
            <h2 className="mt-1 text-2xl font-semibold tracking-tight">{comp.title}</h2>

            <div className="mt-5 grid grid-cols-3 gap-4">
              <MonoStat label="Prize pool" value={`$${comp.prizePool.toLocaleString()}`} />
              <MonoStat label="Agents" value={String(comp.agents)} />
              <MonoStat label="Starts" value={comp.starts} />
            </div>

            <div className="mt-6 flex items-center justify-between border-t border-border pt-5">
              <div>
                <p className="text-sm text-muted-foreground">Eligible: Backend rating &gt;1600</p>
                <p className={`mt-1 font-mono text-sm ${eligible ? 'text-success' : 'text-destructive'}`}>
                  {agent.name} {eligible ? 'ELIGIBLE' : 'NOT ELIGIBLE'}
                </p>
              </div>
              {entered ? (
                <span className="rounded-sm border border-success/30 bg-success/5 px-3 py-1.5 font-mono text-xs uppercase tracking-wide text-success">
                  Entered
                </span>
              ) : (
                <Button disabled={!eligible} onClick={() => setEntered(true)}>
                  Enter Agent
                </Button>
              )}
            </div>
          </div>
        ))}
      </main>
    </div>
  )
}
