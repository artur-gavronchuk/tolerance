'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { ArrowRight } from 'lucide-react'
import { PublicNav } from '@/components/public-nav'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'

const CAPABILITY_OPTIONS = ['Backend', 'Frontend', 'Database', 'Debugging', 'DevOps']
const LANGUAGE_OPTIONS = ['Go', 'Python', 'SQL', 'TypeScript', 'Rust']

export default function CreateAgentPage() {
  const router = useRouter()
  const { createAgent } = useApp()
  const [name, setName] = useState('FIXER-7')
  const [description, setDescription] = useState(
    'Autonomous backend engineering agent optimized for debugging Go services.',
  )
  const [capabilities, setCapabilities] = useState<string[]>(['Backend', 'Debugging', 'Database'])
  const [languages, setLanguages] = useState<string[]>(['Go', 'Python', 'SQL'])

  const toggle = (list: string[], setList: (v: string[]) => void, item: string) => {
    setList(list.includes(item) ? list.filter((x) => x !== item) : [...list, item])
  }

  const handleSubmit = () => {
    createAgent({ name, description, claimedSkills: capabilities, languages })
    router.push('/agent/runtime')
  }

  return (
    <div className="min-h-screen bg-background">
      <PublicNav />
      <main className="mx-auto max-w-2xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Step 1 of 4</p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">Create your agent</h1>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Give your agent an identity. What you claim here isn&apos;t trusted yet — your agent will have to
          prove it.
        </p>

        <div className="mt-10 flex flex-col gap-8">
          <div className="flex flex-col gap-2">
            <Label htmlFor="name">Agent name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} className="font-mono" />
          </div>

          <div className="flex flex-col gap-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
            />
          </div>

          <div className="flex flex-col gap-3">
            <Label>Capabilities claimed by owner</Label>
            <div className="flex flex-wrap gap-2">
              {CAPABILITY_OPTIONS.map((cap) => (
                <button
                  key={cap}
                  type="button"
                  onClick={() => toggle(capabilities, setCapabilities, cap)}
                  className={cn(
                    'rounded-sm border px-3 py-1.5 text-sm transition',
                    capabilities.includes(cap)
                      ? 'border-foreground bg-foreground text-background'
                      : 'border-border text-muted-foreground hover:border-foreground/40',
                  )}
                >
                  {cap}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <Label>Languages</Label>
            <div className="flex flex-wrap gap-2">
              {LANGUAGE_OPTIONS.map((lang) => (
                <button
                  key={lang}
                  type="button"
                  onClick={() => toggle(languages, setLanguages, lang)}
                  className={cn(
                    'rounded-sm border px-3 py-1.5 font-mono text-sm transition',
                    languages.includes(lang)
                      ? 'border-foreground bg-foreground text-background'
                      : 'border-border text-muted-foreground hover:border-foreground/40',
                  )}
                >
                  {lang}
                </button>
              ))}
            </div>
          </div>

          {capabilities.length > 0 && (
            <div className="rounded-md border border-dashed border-border p-4">
              <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">
                Anyone can claim a skill. Your agent has to prove it.
              </p>
              <div className="flex flex-wrap gap-2">
                {capabilities.map((cap) => (
                  <span
                    key={cap}
                    className="flex items-center gap-2 rounded-sm border border-border bg-card px-2.5 py-1 text-xs"
                  >
                    {cap}
                    <span className="font-mono text-[10px] text-muted-foreground">UNVERIFIED</span>
                  </span>
                ))}
              </div>
            </div>
          )}

          <Button size="lg" onClick={handleSubmit} disabled={!name.trim()} className="w-fit">
            Continue to connect runtime <ArrowRight className="size-4" />
          </Button>
        </div>

        <Link href="/" className="mt-10 block text-sm text-muted-foreground hover:text-foreground">
          ← Back to home
        </Link>
      </main>
    </div>
  )
}
