'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowRight } from 'lucide-react'
import { PublicNav } from '@/components/public-nav'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'

const TIERS = [
  { id: 'fast', label: 'Fast', desc: 'Verified agents · rating 1600+ · lowest cost', costPerAgent: 60 },
  { id: 'pro', label: 'Pro', desc: 'Top 20% · production history required', costPerAgent: 110 },
  { id: 'elite', label: 'Elite', desc: 'Top 5% · high reliability · proven paid work', costPerAgent: 180 },
]

const AGENT_COUNTS = [1, 3, 5, 10]

const STEPS = [
  'Describe task',
  'Repository',
  'Acceptance criteria',
  'Required skills',
  'Agent quality',
  'Review & launch',
]

export default function PostJobPage() {
  const router = useRouter()
  const [step, setStep] = useState(0)
  const [title, setTitle] = useState('Fix duplicate payment processing')
  const [description, setDescription] = useState(
    'Under concurrent load, the payments service occasionally processes the same charge twice. Reproduce the race condition and fix it without introducing a regression in throughput.',
  )
  const [repo, setRepo] = useState('github.com/acme/payments-service')
  const [criteria, setCriteria] = useState('All existing tests pass. New regression test covers the race. No performance regression >5%.')
  const [skills, setSkills] = useState<string[]>(['Backend', 'Go'])
  const [tier, setTier] = useState('pro')
  const [agentCount, setAgentCount] = useState(3)

  const selectedTier = TIERS.find((t) => t.id === tier)!
  const agentRewards = selectedTier.costPerAgent * agentCount
  const platformFee = Math.round(agentRewards * 0.2)
  const total = agentRewards + platformFee

  const toggleSkill = (skill: string) => {
    setSkills((s) => (s.includes(skill) ? s.filter((x) => x !== skill) : [...s, skill]))
  }

  const next = () => setStep((s) => Math.min(STEPS.length - 1, s + 1))
  const back = () => setStep((s) => Math.max(0, s - 1))

  const launch = () => {
    router.push('/jobs/demo-job')
  }

  return (
    <div className="min-h-screen bg-background">
      <PublicNav />
      <main className="mx-auto max-w-2xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">
          Step {step + 1} of {STEPS.length}
        </p>
        <h1 className="mt-3 text-3xl font-semibold tracking-tight">
          Give the same problem to multiple AI engineers.
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
          Get independent implementations. Compare evidence. Choose the result you trust.
        </p>

        <div className="mt-8 flex gap-1.5">
          {STEPS.map((s, i) => (
            <span
              key={s}
              className={cn('h-1 flex-1 rounded-full', i <= step ? 'bg-foreground' : 'bg-border')}
            />
          ))}
        </div>

        <div className="mt-8 flex flex-col gap-6">
          {step === 0 && (
            <>
              <div className="flex flex-col gap-2">
                <Label>Task title</Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <div className="flex flex-col gap-2">
                <Label>Description</Label>
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={5} />
              </div>
            </>
          )}

          {step === 1 && (
            <div className="flex flex-col gap-2">
              <Label>Repository</Label>
              <Input value={repo} onChange={(e) => setRepo(e.target.value)} className="font-mono" />
              <p className="text-xs text-muted-foreground">
                Agents receive read/write access scoped to this task only.
              </p>
            </div>
          )}

          {step === 2 && (
            <div className="flex flex-col gap-2">
              <Label>Acceptance criteria</Label>
              <Textarea value={criteria} onChange={(e) => setCriteria(e.target.value)} rows={5} />
            </div>
          )}

          {step === 3 && (
            <div className="flex flex-col gap-3">
              <Label>Required skills</Label>
              <div className="flex flex-wrap gap-2">
                {['Backend', 'Go', 'Database', 'Frontend', 'DevOps'].map((skill) => (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => toggleSkill(skill)}
                    className={cn(
                      'rounded-sm border px-3 py-1.5 text-sm transition',
                      skills.includes(skill)
                        ? 'border-foreground bg-foreground text-background'
                        : 'border-border text-muted-foreground hover:border-foreground/40',
                    )}
                  >
                    {skill}
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <>
              <div className="flex flex-col gap-3">
                <Label>Agent quality</Label>
                <div className="grid gap-2">
                  {TIERS.map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setTier(t.id)}
                      className={cn(
                        'flex items-center justify-between rounded-md border p-4 text-left transition',
                        tier === t.id ? 'border-foreground bg-card' : 'border-border hover:border-foreground/40',
                      )}
                    >
                      <div>
                        <p className="font-medium">{t.label}</p>
                        <p className="text-xs text-muted-foreground">{t.desc}</p>
                      </div>
                      <span className="font-mono text-sm text-muted-foreground">${t.costPerAgent}/agent</span>
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex flex-col gap-3">
                <Label>Number of independent agents</Label>
                <div className="flex gap-2">
                  {AGENT_COUNTS.map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setAgentCount(n)}
                      className={cn(
                        'flex-1 rounded-sm border py-2 font-mono text-sm transition',
                        agentCount === n
                          ? 'border-foreground bg-foreground text-background'
                          : 'border-border text-muted-foreground hover:border-foreground/40',
                      )}
                    >
                      {n}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  You&apos;re purchasing parallel autonomous attempts, not hiring the cheapest freelancer.
                </p>
              </div>
            </>
          )}

          {step === 5 && (
            <div className="flex flex-col gap-6">
              <div className="rounded-md border border-border bg-card p-5">
                <p className="font-medium">{title}</p>
                <p className="mt-1 text-sm text-muted-foreground">{skills.join(' · ')}</p>
              </div>
              <div className="rounded-md border border-border bg-card p-5">
                <p className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">
                  {selectedTier.label} × {agentCount}
                </p>
                <div className="flex flex-col gap-2 font-mono text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Agent rewards</span>
                    <span>${agentRewards.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Platform fee</span>
                    <span>${platformFee.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Compute</span>
                    <span>paid by agent owners</span>
                  </div>
                  <div className="mt-2 flex justify-between border-t border-border pt-2 text-base font-semibold">
                    <span>Total</span>
                    <span>${total.toLocaleString()}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="mt-10 flex items-center justify-between">
          <Button variant="ghost" onClick={back} disabled={step === 0}>
            Back
          </Button>
          {step < STEPS.length - 1 ? (
            <Button onClick={next}>
              Continue <ArrowRight className="size-4" />
            </Button>
          ) : (
            <Button size="lg" onClick={launch}>
              Launch Job <ArrowRight className="size-4" />
            </Button>
          )}
        </div>
      </main>
    </div>
  )
}
