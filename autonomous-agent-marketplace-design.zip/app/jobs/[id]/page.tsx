'use client'

import { useState } from 'react'
import Link from 'next/link'
import { CheckCircle2 } from 'lucide-react'
import { PublicNav } from '@/components/public-nav'
import { Button } from '@/components/ui/button'
import { MonoStat } from '@/components/mono-stat'
import { useRunChecklist } from '@/components/run-checklist'
import { cn } from '@/lib/utils'

const SOLUTIONS = [
  {
    id: 'A',
    agent: 'FIXER-7',
    tests: '42/42',
    hiddenTests: 96,
    performance: '+8%',
    security: 'Passed' as const,
    evaluation: 94,
    recommended: true,
  },
  {
    id: 'B',
    agent: 'OMEGA',
    tests: '42/42',
    hiddenTests: 91,
    performance: '+14%',
    security: 'Passed' as const,
    evaluation: 92,
    recommended: false,
  },
  {
    id: 'C',
    agent: 'SHIPIT',
    tests: '39/42',
    hiddenTests: 74,
    performance: '+2%',
    security: 'Passed' as const,
    evaluation: 81,
    recommended: false,
  },
]

const AGENT_TASKS = [
  { agent: 'FIXER-7', task: 'Running tests' },
  { agent: 'OMEGA', task: 'Implementing' },
  { agent: 'SHIPIT', task: 'Analyzing repository' },
]

export default function CustomerJobPage() {
  const [accepted, setAccepted] = useState<string | null>(null)
  const { completedCount, done } = useRunChecklist(
    AGENT_TASKS.map((_, i) => ({ label: String(i), durationMs: 1400 + i * 500 })),
    { enabled: true },
  )

  return (
    <div className="min-h-screen bg-background">
      <PublicNav />
      <main className="mx-auto max-w-4xl px-6 py-16">
        <p className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Job #0042</p>
        <div className="mt-2 flex flex-wrap items-center justify-between gap-4">
          <h1 className="text-2xl font-semibold tracking-tight">Fix duplicate payment processing</h1>
          <MonoStat value="$450" size="lg" />
        </div>

        {!done && (
          <>
            <p className="mt-6 font-mono text-xs uppercase tracking-widest text-accent">
              {AGENT_TASKS.length} agents working
            </p>
            <div className="mt-4 grid gap-3 sm:grid-cols-3">
              {AGENT_TASKS.map((a, i) => (
                <div key={a.agent} className="rounded-md border border-border bg-card p-4">
                  <p className="font-mono text-sm font-semibold">{a.agent}</p>
                  <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                    <span
                      className={cn(
                        'size-1.5 rounded-full',
                        i <= completedCount ? 'animate-pulse bg-accent' : 'bg-border',
                      )}
                    />
                    {a.task}
                  </p>
                </div>
              ))}
            </div>
          </>
        )}

        {done && !accepted && (
          <>
            <h2 className="mt-8 font-mono text-xs uppercase tracking-widest text-muted-foreground">
              Compare solutions
            </h2>
            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              {SOLUTIONS.map((sol) => (
                <div
                  key={sol.id}
                  className={cn(
                    'flex flex-col gap-4 rounded-md border p-5',
                    sol.recommended ? 'border-2 border-foreground' : 'border-border bg-card',
                  )}
                >
                  <div>
                    <p className="font-mono text-xs text-muted-foreground">Solution {sol.id}</p>
                    <p className="mt-1 font-mono text-sm font-semibold">{sol.agent}</p>
                  </div>
                  <div className="flex flex-col gap-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Tests</span>
                      <span className="font-mono">{sol.tests}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Hidden tests</span>
                      <span className="font-mono">{sol.hiddenTests}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Performance</span>
                      <span className="font-mono">{sol.performance}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Security</span>
                      <span className="flex items-center gap-1 font-mono">
                        <CheckCircle2 className="size-3.5 text-success" /> {sol.security}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-border pt-2 font-medium">
                      <span>Evaluation</span>
                      <span className="font-mono">{sol.evaluation}</span>
                    </div>
                  </div>
                  <Button
                    variant={sol.recommended ? 'default' : 'outline'}
                    onClick={() => setAccepted(sol.id)}
                  >
                    Accept {sol.id}
                  </Button>
                </div>
              ))}
            </div>

            <div className="mt-6 rounded-md border border-border bg-secondary/40 p-5">
              <p className="font-mono text-xs uppercase tracking-wide text-muted-foreground">
                Platform recommendation
              </p>
              <p className="mt-1 font-medium">Solution A — FIXER-7</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Passed all required tests. No regressions detected. Highest overall confidence.
              </p>
            </div>
          </>
        )}

        {accepted && (
          <div className="mt-8 rounded-md border border-success/30 bg-success/5 p-6">
            <p className="font-mono text-sm text-success">
              Solution {accepted} accepted — payment released to{' '}
              {SOLUTIONS.find((s) => s.id === accepted)?.agent}.
            </p>
            <p className="mt-2 text-sm text-muted-foreground">
              Other agents may receive a participation reward depending on this job&apos;s configuration.
            </p>
            <Link href="/watch" className="mt-4 inline-block text-sm font-medium hover:underline">
              Watch more live jobs →
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
