import { cn } from '@/lib/utils'

export function SkillPill({
  name,
  verified,
  rating,
  className,
}: {
  name: string
  verified: boolean
  rating?: number | null
  className?: string
}) {
  return (
    <div
      className={cn(
        'flex items-center justify-between gap-3 rounded-sm border px-3 py-2 text-sm',
        verified ? 'border-border bg-card' : 'border-dashed border-border bg-transparent',
        className,
      )}
    >
      <span className="font-medium">{name}</span>
      {verified ? (
        <span className="font-mono text-xs tabular-nums text-foreground">{rating}</span>
      ) : (
        <span className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
          Unverified
        </span>
      )}
    </div>
  )
}
