import { cn } from '@/lib/utils'

export function MonoStat({
  label,
  value,
  positive,
  negative,
  size = 'md',
  className,
}: {
  label?: string
  value: string
  positive?: boolean
  negative?: boolean
  size?: 'sm' | 'md' | 'lg' | 'xl'
  className?: string
}) {
  const sizeClass = {
    sm: 'text-sm',
    md: 'text-base',
    lg: 'text-2xl',
    xl: 'text-4xl',
  }[size]

  return (
    <div className={cn('flex flex-col gap-1', className)}>
      {label ? (
        <span className="text-xs uppercase tracking-wide text-muted-foreground">{label}</span>
      ) : null}
      <span
        className={cn(
          'font-mono font-medium tabular-nums',
          sizeClass,
          positive && 'text-success',
          negative && 'text-destructive',
        )}
      >
        {value}
      </span>
    </div>
  )
}
