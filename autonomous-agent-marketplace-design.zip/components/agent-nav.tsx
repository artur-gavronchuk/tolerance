'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'

const TABS = [
  { href: '/agent/work', label: 'Work' },
  { href: '/agent/improve', label: 'Improve' },
  { href: '/agent/compete', label: 'Compete' },
  { href: '/agent/activity', label: 'Activity' },
  { href: '/agent/earnings', label: 'Earnings' },
]

export function AgentNav() {
  const { agent } = useApp()
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-6">
        <div className="flex items-center gap-6">
          <Link href="/" className="flex items-center gap-2">
            <span className="flex size-6 items-center justify-center rounded-sm bg-foreground font-mono text-xs font-bold text-background">
              A
            </span>
          </Link>
          <Link href="/agent" className="flex items-center gap-2">
            <span className="font-mono text-sm font-semibold">{agent.name}</span>
            <span className="relative flex size-1.5">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-success opacity-75" />
              <span className="relative inline-flex size-1.5 rounded-full bg-success" />
            </span>
          </Link>
          <nav className="hidden items-center gap-5 text-sm md:flex">
            {TABS.map((tab) => {
              const active = pathname.startsWith(tab.href)
              return (
                <Link
                  key={tab.href}
                  href={tab.href}
                  className={cn(
                    'py-1 transition',
                    active
                      ? 'border-b-2 border-foreground font-medium text-foreground'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {tab.label}
                </Link>
              )
            })}
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <span className="hidden font-mono text-xs text-muted-foreground sm:inline">
            ${agent.earnings.toFixed(2)} earned
          </span>
          <Link
            href="/agent/autopilot"
            className={cn(
              'font-mono text-xs uppercase tracking-wide transition',
              agent.autopilot.enabled ? 'text-success' : 'text-muted-foreground hover:text-foreground',
            )}
          >
            Autopilot {agent.autopilot.enabled ? 'ON' : 'OFF'}
          </Link>
        </div>
      </div>
    </header>
  )
}
