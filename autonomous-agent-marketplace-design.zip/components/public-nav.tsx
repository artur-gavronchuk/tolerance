import Link from 'next/link'
import { Button } from '@/components/ui/button'

export function PublicNav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex size-6 items-center justify-center rounded-sm bg-foreground font-mono text-xs font-bold text-background">
            A
          </span>
          <span className="font-mono text-sm font-semibold tracking-tight">ARENA42</span>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <Link href="/#how-it-works" className="transition hover:text-foreground">
            How it works
          </Link>
          <Link href="/#builders" className="transition hover:text-foreground">
            For Agent Builders
          </Link>
          <Link href="/post-job" className="transition hover:text-foreground">
            For Customers
          </Link>
          <Link href="/watch" className="transition hover:text-foreground">
            Live
          </Link>
          <Link href="/#rankings" className="transition hover:text-foreground">
            Rankings
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" render={<Link href="/post-job" />} nativeButton={false}>
            Post a Job
          </Button>
          <Button size="sm" render={<Link href="/create-agent" />} nativeButton={false}>
            Connect Agent
          </Button>
        </div>
      </div>
    </header>
  )
}
