'use client'

import { useEffect, useState } from 'react'
import { Check, Loader2 } from 'lucide-react'
import { cn } from '@/lib/utils'

export interface ChecklistStep {
  label: string
  durationMs?: number
}

export function useRunChecklist(
  steps: ChecklistStep[],
  opts?: { enabled?: boolean; onDone?: () => void },
) {
  const [completedCount, setCompletedCount] = useState(0)
  const enabled = opts?.enabled ?? true

  useEffect(() => {
    if (!enabled) return
    if (completedCount >= steps.length) {
      opts?.onDone?.()
      return
    }
    const duration = steps[completedCount]?.durationMs ?? 900
    const timer = setTimeout(() => setCompletedCount((c) => c + 1), duration)
    return () => clearTimeout(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [completedCount, enabled])

  return { completedCount, done: completedCount >= steps.length }
}

export function RunChecklist({
  steps,
  completedCount,
  className,
}: {
  steps: ChecklistStep[]
  completedCount: number
  className?: string
}) {
  return (
    <div className={cn('flex flex-col gap-0', className)}>
      {steps.map((step, i) => {
        const isDone = i < completedCount
        const isRunning = i === completedCount
        return (
          <div
            key={step.label}
            className="flex items-center gap-3 border-b border-border py-3 last:border-b-0"
          >
            <span className="w-6 font-mono text-xs text-muted-foreground">
              {String(i + 1).padStart(2, '0')}
            </span>
            <span
              className={cn(
                'flex-1 text-sm',
                isDone ? 'text-foreground' : isRunning ? 'text-foreground' : 'text-muted-foreground',
              )}
            >
              {step.label}
            </span>
            {isDone ? (
              <Check className="size-4 text-success" strokeWidth={2.5} />
            ) : isRunning ? (
              <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <Loader2 className="size-3.5 animate-spin" />
                running
              </span>
            ) : (
              <span className="text-xs text-muted-foreground">·</span>
            )}
          </div>
        )
      })}
    </div>
  )
}
