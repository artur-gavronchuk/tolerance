'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { ChevronUp } from 'lucide-react'
import { useApp, type DemoPreset } from '@/lib/store'
import { cn } from '@/lib/utils'

const PRESETS: { id: DemoPreset; label: string; href: string }[] = [
  { id: 'fresh', label: 'Fresh', href: '/create-agent' },
  { id: 'operational', label: 'Operational', href: '/agent/qualify' },
  { id: 'qualified', label: 'Qualified', href: '/agent' },
  { id: 'first-money', label: 'First money', href: '/agent' },
  { id: 'proven', label: 'Proven', href: '/agent' },
  { id: 'trusted', label: 'Trusted', href: '/agent' },
  { id: 'autopilot-overnight', label: 'Autopilot overnight', href: '/agent/earnings' },
  { id: 'version-changed', label: 'Version changed', href: '/agent' },
  { id: 'offline', label: 'Offline', href: '/agent' },
]

export function DemoPill() {
  const { applyDemoPreset } = useApp()
  const router = useRouter()
  const [open, setOpen] = useState(false)

  const handlePreset = (preset: (typeof PRESETS)[number]) => {
    applyDemoPreset(preset.id)
    setOpen(false)
    router.push(preset.href)
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {open && (
        <div className="mb-2 flex w-56 flex-col gap-1 rounded-md border border-border bg-popover p-2 shadow-lg">
          <p className="px-2 py-1 font-mono text-[10px] uppercase tracking-widest text-muted-foreground">
            Jump to
          </p>
          {PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => handlePreset(p)}
              className="rounded-sm px-2 py-1.5 text-left text-sm text-popover-foreground transition hover:bg-secondary"
            >
              {p.label}
            </button>
          ))}
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className={cn(
          'flex items-center gap-1.5 rounded-full border border-border bg-foreground px-3.5 py-2 font-mono text-xs uppercase tracking-wide text-background shadow-lg transition',
          open && 'rounded-b-none',
        )}
      >
        Demo <ChevronUp className={cn('size-3.5 transition', !open && 'rotate-180')} />
      </button>
    </div>
  )
}
