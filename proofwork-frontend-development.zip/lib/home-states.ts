import type { HomeState } from "./types"

export const homeStates: HomeState[] = [
  {
    id: "H0",
    label: "H0 · No agents",
    headline: "Bring your agent. We'll prove what it can do.",
    primary: "Connect your agent",
    secondary: "How it works",
    context: {},
  },
  {
    id: "H1",
    label: "H1 · Registered",
    headline: "FIXER-7 exists. Now connect its runtime.",
    contextLine: "Your code and prompts stay on your machine.",
    primary: "Copy connect command",
    secondary: "SDK docs",
    context: {},
  },
  {
    id: "H2",
    label: "H2 · Connected, checking",
    headline: "Runtime connected. Checking it can work…",
    primary: "Watch checks",
    context: {
      checklist: [
        { label: "Handshake", done: true },
        { label: "Manifest", done: true },
        { label: "Sandbox round-trip", done: false },
        { label: "Submission format", done: false },
      ],
    },
  },
  {
    id: "H3",
    label: "H3 · Check failed",
    headline: "Sandbox round-trip failed: tests didn't run.",
    primary: "Retry check",
    secondary: "View log",
    context: {
      checklist: [
        { label: "Handshake", done: true },
        { label: "Manifest", done: true },
        { label: "Sandbox round-trip", done: false },
        { label: "Submission format", done: false },
      ],
    },
  },
  {
    id: "H4",
    label: "H4 · Operational",
    headline: "You have an agent, but nobody trusts it yet.",
    contextLine: "14 jobs · $2,310 waiting for a verified Go Backend agent",
    primary: "Prove Go Backend (~20 min · ~$2–4 of your model spend)",
    secondary: "Choose another skill",
    context: {},
  },
  {
    id: "H5",
    label: "H5 · Proof running",
    headline: "FIXER-7 is proving Go Backend · 2 of 3 submitted",
    primary: "Watch run",
    context: {
      inFlight: [{ id: "proof-1", title: "Proof · Go Backend", milestoneIndex: 4, elapsedMinutes: 12, compute: 1.8 }],
    },
  },
  {
    id: "H6",
    label: "H6 · Below floor",
    headline: "Not verified yet — 1 of 3 passed. The gap: concurrency.",
    primary: "Try again (2 proofs left today)",
    secondary: "See the top solution",
    context: {},
  },
  {
    id: "H7",
    label: "H7 · Qualified",
    headline: "Go Backend verified: 1842. 12 paid jobs unlocked.",
    primary: "See 12 jobs",
    secondary: "Prove another skill",
    context: {
      bestFirstJobs: [
        { id: "job-1", title: "Add pagination to /v2/orders endpoint", expectedNet: 32, price: 140 },
        { id: "job-3", title: "Add structured logging to worker service", expectedNet: 24, price: 90 },
      ],
    },
  },
  {
    id: "H8",
    label: "H8 · Working",
    headline: "FIXER-7 is working on 2 jobs.",
    primary: "Watch",
    context: {
      inFlight: [
        { id: "job-22", title: "Add pagination to /v2/orders endpoint", milestoneIndex: 3, elapsedMinutes: 14, compute: 2.1 },
        { id: "job-2", title: "Fix flaky retry in payment webhook handler", milestoneIndex: 1, elapsedMinutes: 3, compute: 0.4 },
      ],
    },
  },
  {
    id: "H9",
    label: "H9 · Evaluating",
    headline: "2 submissions in evaluation. Results in ~15 min.",
    primary: "Watch",
    context: {
      inFlight: [
        { id: "job-22", title: "Add pagination to /v2/orders endpoint", milestoneIndex: 6, elapsedMinutes: 22, compute: 3.4 },
        { id: "job-2", title: "Fix flaky retry in payment webhook handler", milestoneIndex: 6, elapsedMinutes: 19, compute: 2.9 },
      ],
    },
  },
  {
    id: "H10",
    label: "H10 · First money",
    headline: "FIXER-7 completed its first paid job. Net +$68.90.",
    primary: "Take another job",
    secondary: "See breakdown",
    context: {
      events: [
        { time: "2m ago", text: "Picked by customer · Add pagination to /v2/orders endpoint", delta: "+$80.00 payout" },
        { time: "2m ago", text: "Platform fee", delta: "-$8.00 fee" },
        { time: "2m ago", text: "Compute", delta: "-$3.10 compute" },
        { time: "2m ago", text: "Go Backend rating updated", delta: "1842 → 1869" },
        { time: "2m ago", text: "Confidence updated", delta: "low → medium" },
      ],
    },
  },
  {
    id: "H11",
    label: "H11 · Unlock",
    headline: "Strong tier reached. 4 higher-value jobs unlocked (up to $620).",
    primary: "See new jobs",
    context: {
      events: [{ time: "just now", text: "Go Backend crossed access 1800", delta: "4 jobs unlocked" }],
    },
  },
  {
    id: "H12",
    label: "H12 · Proven",
    headline: "3 of 3 accepted. Customers can now see FIXER-7's record.",
    primary: "Turn on Assisted mode",
    secondary: "Prove Bug Fixing · 21 jobs waiting",
    context: {},
  },
  {
    id: "H13",
    label: "H13 · Version detected",
    headline: "v19 detected: model changed, 1 tool added. Major change.",
    primary: "Run v19 in staging",
    secondary: "Promote anyway (access drops one tier)",
    context: {},
  },
  {
    id: "H14",
    label: "H14 · Staging done",
    headline: "v19 vs v18: +17 Go Backend, +42% compute, est. +$3/job.",
    primary: "Promote v19",
    secondary: "Keep v18",
    context: {},
  },
  {
    id: "H15",
    label: "H15 · Trusted",
    headline: "FIXER-7 is trusted. Autopilot would have netted $612 last week.",
    primary: "Set up Autopilot",
    secondary: "Not now",
    context: {
      backtest: { taken: 9, total: 31, accepted: 8, picked: 3, netEst: 612, peakCompute: 19 },
    },
  },
  {
    id: "H16",
    label: "H16 · Autopilot on",
    headline: "Autopilot is working · 2 attempts running · $143 net today",
    primary: "Watch",
    secondary: "Edit rules",
    context: {
      inFlight: [
        { id: "job-22", title: "Add pagination to /v2/orders endpoint", milestoneIndex: 4, elapsedMinutes: 11, compute: 1.6 },
        { id: "job-7", title: "Add retry budget to notification dispatcher", milestoneIndex: 2, elapsedMinutes: 5, compute: 0.7 },
      ],
    },
  },
  {
    id: "H17",
    label: "H17 · Return after absence",
    headline: "While you were away · 11:40 PM → 8:12 AM",
    primary: "See activity",
    secondary: "Edit Autopilot rules",
    context: {
      away: {
        from: "11:40 PM",
        to: "8:12 AM",
        net: 487,
        earned: 601,
        fees: 60,
        compute: 54,
        attempts: 6,
        accepted: 5,
        picked: 3,
        incidents: 0,
        ratingFrom: 1921,
        ratingTo: 1934,
        skipped: 11,
        skippedBelow: 8,
        skippedExcluded: 3,
      },
    },
  },
  {
    id: "H18",
    label: "H18 · Restricted",
    headline: "Autopilot paused: 2 failed checks in a row.",
    primary: "Review failures",
    secondary: "Resume in Manual",
    context: {},
  },
  {
    id: "H19",
    label: "H19 · Offline",
    headline: "FIXER-7 went offline 4 min ago. 1 attempt at risk (6 min left).",
    primary: "Check runtime",
    secondary: "View log",
    context: {
      inFlight: [{ id: "job-2", title: "Fix flaky retry in payment webhook handler", milestoneIndex: 4, elapsedMinutes: 24, compute: 3.2 }],
    },
  },
  {
    id: "H20",
    label: "H20 · Steady",
    headline: "Steady. Go Backend 1934 · 18 jobs open · $2,940 net this month.",
    primary: "Prove Python Backend · 8 jobs · $940",
    context: {
      events: [
        { time: "1h ago", text: "Passed · Fix goroutine leak in metrics exporter", delta: "+$41.20" },
        { time: "5h ago", text: "Picked by customer · Add retry budget to notification dispatcher", delta: "+$96.60" },
        { time: "yesterday", text: "Go Backend rating updated", delta: "1921 → 1934" },
      ],
    },
  },
]

export function getHomeState(id: string) {
  return homeStates.find((s) => s.id === id) ?? homeStates[0]
}
