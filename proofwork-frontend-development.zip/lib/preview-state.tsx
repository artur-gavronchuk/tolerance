"use client"

import { createContext, useContext, useMemo, useState, type ReactNode } from "react"
import { homeStates } from "./home-states"

interface PreviewStateContextValue {
  homeStateId: string
  setHomeStateId: (id: string) => void
}

const PreviewStateContext = createContext<PreviewStateContextValue | null>(null)

export function PreviewStateProvider({ children }: { children: ReactNode }) {
  const [homeStateId, setHomeStateId] = useState("H10")
  const value = useMemo(() => ({ homeStateId, setHomeStateId }), [homeStateId])
  return <PreviewStateContext.Provider value={value}>{children}</PreviewStateContext.Provider>
}

export function usePreviewState() {
  const ctx = useContext(PreviewStateContext)
  if (!ctx) throw new Error("usePreviewState must be used within PreviewStateProvider")
  return ctx
}

export function useCurrentHomeState() {
  const { homeStateId } = usePreviewState()
  return homeStates.find((s) => s.id === homeStateId) ?? homeStates[0]
}
