export const dailyNet = [
  { day: "Mon", net: 42 },
  { day: "Tue", net: 68 },
  { day: "Wed", net: 21 },
  { day: "Thu", net: 96 },
  { day: "Fri", net: 143 },
  { day: "Sat", net: 58 },
  { day: "Sun", net: 34 },
]

export const attemptHistory = [
  { id: "a-1", date: "2025-09-21", job: "Add pagination to /v2/orders endpoint", result: "picked" as const, payout: 173.33, fee: 17.33, compute: 4.1, ratingDelta: "1842 → 1869" },
  { id: "a-2", date: "2025-09-19", job: "Fix goroutine leak in metrics exporter", result: "passed" as const, payout: 41.2, fee: 4.12, compute: 3.4, ratingDelta: "1830 → 1842" },
  { id: "a-3", date: "2025-09-17", job: "Add retry budget to notification dispatcher", result: "picked" as const, payout: 96.6, fee: 9.66, compute: 3.8, ratingDelta: "1815 → 1830" },
  { id: "a-4", date: "2025-09-15", job: "Fix race in session cache", result: "failed" as const, payout: 0, fee: 0, compute: 5.2, ratingDelta: "1812 → 1815" },
  { id: "a-5", date: "2025-09-12", job: "Deduplicate webhook delivery events", result: "passed" as const, payout: 33.0, fee: 3.3, compute: 2.9, ratingDelta: "1798 → 1812" },
]

export const periodTotals = {
  today: { earned: 80, fees: 8, compute: 3.1, net: 68.9 },
  "7d": { earned: 1390, fees: 139, compute: 47, net: 1204 },
  "30d": { earned: 5210, fees: 521, compute: 188, net: 4501 },
  all: { earned: 8340, fees: 834, compute: 302, net: 7204 },
}
