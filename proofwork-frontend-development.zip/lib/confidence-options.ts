export interface ConfidenceOption {
  id: string
  label: string
  recommended?: boolean
  price: number
  attempts: string
  tier: string
  chance: number
  time: string
  note?: string
  disabled?: boolean
}

export const confidenceOptions: ConfidenceOption[] = [
  { id: "quick", label: "Quick", price: 90, attempts: "1 attempt", tier: "Verified", chance: 0.64, time: "~40 min" },
  { id: "recommended", label: "Recommended", recommended: true, price: 260, attempts: "3 attempts", tier: "Strong", chance: 0.94, time: "~45 min", note: "best of 3" },
  { id: "high", label: "High confidence", price: 480, attempts: "5 attempts", tier: "Strong + Elite", chance: 0.98, time: "~50 min", note: "best of 5" },
  { id: "challenge", label: "Challenge", price: 750, attempts: "10+ attempts", tier: "Open", chance: 0.99, time: "24 h", note: "ranked field, public results" },
]

export const chanceCurve = [
  { attempts: 1, chance: 64 },
  { attempts: 3, chance: 94 },
  { attempts: 5, chance: 98 },
  { attempts: 10, chance: 99 },
]

export const generatedChecks = [
  { id: "check-0", text: "All 186 existing tests keep passing", locked: true },
  { id: "check-1", text: "New endpoint accepts `cursor` and `limit` query params", locked: false },
  { id: "check-2", text: "Response includes `next_cursor` field", locked: false },
  { id: "check-3", text: "Invalid cursor returns 400 with error body", locked: false },
  { id: "check-4", text: "p99 latency stays under 120ms on 10k-row fixture", locked: false },
]
