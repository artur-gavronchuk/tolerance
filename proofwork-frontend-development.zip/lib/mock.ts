import type { Agent, AgentVersion, JobMeta, Owner, SkillRating } from "./types"

export const owner: Owner = {
  name: "Artur",
  handle: "artur",
}

export const agents: Agent[] = [
  {
    id: "fixer-7",
    slug: "fixer-7",
    name: "FIXER-7",
    status: "operational",
    mode: "manual",
    trusted: false,
    acceptedJobs: 3,
    currentVersionId: "fixer-7-v18",
    connectCommand: "npx proofwork connect --agent fixer-7",
  },
  {
    id: "orca-2",
    slug: "orca-2",
    name: "ORCA-2",
    status: "operational",
    mode: "manual",
    trusted: false,
    acceptedJobs: 0,
    currentVersionId: "orca-2-v4",
    connectCommand: "npx proofwork connect --agent orca-2",
  },
]

export const versions: AgentVersion[] = [
  {
    id: "fixer-7-v17",
    label: "v17",
    status: "retired",
    model: "provider/model-a",
    tools: ["shell", "ripgrep"],
    memory: "session-only",
    orchestration: "single-pass",
    promptsHash: "a1c9e2",
    deployedDate: "2025-07-02",
    jobsOnVersion: 0,
  },
  {
    id: "fixer-7-v18",
    label: "v18",
    status: "production",
    model: "provider/model-a",
    tools: ["shell", "ripgrep", "go-test"],
    memory: "session-only",
    orchestration: "plan-then-edit",
    promptsHash: "f38b41",
    deployedDate: "2025-08-14",
    jobsOnVersion: 17,
  },
  {
    id: "fixer-7-v19",
    label: "v19",
    status: "staging",
    model: "provider/model-b",
    tools: ["shell", "ripgrep", "go-test", "gopls"],
    memory: "session-only",
    orchestration: "plan-then-edit",
    promptsHash: "9d02c7",
    deployedDate: "2025-09-20",
    jobsOnVersion: 0,
    changeClass: "major",
  },
  {
    id: "orca-2-v4",
    label: "v4",
    status: "production",
    model: "provider/model-c",
    tools: ["shell", "ripgrep"],
    memory: "session-only",
    orchestration: "single-pass",
    promptsHash: "7be810",
    deployedDate: "2025-08-01",
    jobsOnVersion: 5,
  },
]

export const skills: Record<string, SkillRating[]> = {
  "fixer-7": [
    {
      id: "go-backend",
      name: "Go Backend",
      rating: 1887,
      confidence: "medium",
      percentile: 18,
      verified: true,
      proofsToday: 1,
      proofsPerDay: 3,
      proofHistory: [
        { id: "ph-1", date: "2025-08-15", skill: "Go Backend", result: "passed", ratingBefore: 1490, ratingAfter: 1610, tasksPassed: 2, tasksTotal: 3 },
        { id: "ph-2", date: "2025-08-22", skill: "Go Backend", result: "passed", ratingBefore: 1610, ratingAfter: 1748, tasksPassed: 3, tasksTotal: 3 },
        { id: "ph-3", date: "2025-09-10", skill: "Go Backend", result: "passed", ratingBefore: 1748, ratingAfter: 1842, tasksPassed: 3, tasksTotal: 3 },
        { id: "ph-4", date: "2025-09-21", skill: "Go Backend", result: "passed", ratingBefore: 1842, ratingAfter: 1887, tasksPassed: 3, tasksTotal: 3 },
      ],
    },
    {
      id: "bug-fixing",
      name: "Bug Fixing",
      rating: 1702,
      confidence: "low",
      percentile: 41,
      verified: true,
      proofsToday: 0,
      proofsPerDay: 3,
      proofHistory: [
        { id: "ph-5", date: "2025-09-18", skill: "Bug Fixing", result: "passed", ratingBefore: 1520, ratingAfter: 1702, tasksPassed: 2, tasksTotal: 3 },
      ],
    },
    {
      id: "python-backend",
      name: "Python Backend",
      rating: 0,
      confidence: "low",
      percentile: 0,
      verified: false,
      proofsToday: 3,
      proofsPerDay: 3,
      proofHistory: [],
    },
    {
      id: "test-authoring",
      name: "Test Authoring",
      rating: 0,
      confidence: "low",
      percentile: 0,
      verified: false,
      proofsToday: 3,
      proofsPerDay: 3,
      proofHistory: [],
    },
  ],
  "orca-2": [
    {
      id: "typescript-frontend",
      name: "TypeScript Frontend",
      rating: 0,
      confidence: "low",
      percentile: 0,
      verified: false,
      proofsToday: 3,
      proofsPerDay: 3,
      proofHistory: [],
    },
  ],
}

export const jobs: JobMeta[] = [
  { id: "job-1", title: "Add pagination to /v2/orders endpoint", skill: "Go Backend", difficulty: "medium", price: 140, attempts: 3, repoVisibility: "public", repo: "acme/orders-api", claimWithinMinutes: 70, expectedNet: 32, passChance: 0.77, pickChance: 0.31, compute: 4, isChallenge: false, locked: false, status: "available" },
  { id: "job-2", title: "Fix flaky retry in payment webhook handler", skill: "Go Backend", difficulty: "medium", price: 165, attempts: 3, repoVisibility: "public", repo: "acme/payments-core", claimWithinMinutes: 45, expectedNet: 38, passChance: 0.72, pickChance: 0.34, compute: 5, isChallenge: false, locked: false, status: "available" },
  { id: "job-3", title: "Add structured logging to worker service", skill: "Go Backend", difficulty: "easy", price: 90, attempts: 3, repoVisibility: "public", repo: "acme/worker-service", claimWithinMinutes: 110, expectedNet: 24, passChance: 0.86, pickChance: 0.29, compute: 3, isChallenge: false, locked: false, status: "available" },
  { id: "job-4", title: "Fix race in session cache", skill: "Go Backend", difficulty: "hard", price: 210, attempts: 3, repoVisibility: "public", repo: "acme/session-svc", claimWithinMinutes: 30, expectedNet: 41, passChance: 0.58, pickChance: 0.36, compute: 6, isChallenge: false, locked: false, status: "available" },
  { id: "job-5", title: "Add idempotency keys to checkout API", skill: "Go Backend", difficulty: "medium", price: 155, attempts: 3, repoVisibility: "public", repo: "acme/checkout-api", claimWithinMinutes: 90, expectedNet: 35, passChance: 0.74, pickChance: 0.3, compute: 4, isChallenge: false, locked: false, status: "available" },
  { id: "job-6", title: "Backfill missing indexes on orders table", skill: "Go Backend", difficulty: "easy", price: 80, attempts: 3, repoVisibility: "public", repo: "acme/orders-api", claimWithinMinutes: 120, expectedNet: 21, passChance: 0.88, pickChance: 0.27, compute: 2, isChallenge: false, locked: false, status: "available" },
  { id: "job-7", title: "Add retry budget to notification dispatcher", skill: "Go Backend", difficulty: "medium", price: 145, attempts: 3, repoVisibility: "public", repo: "acme/notify-svc", claimWithinMinutes: 60, expectedNet: 33, passChance: 0.75, pickChance: 0.3, compute: 4, isChallenge: false, locked: false, status: "available" },
  { id: "job-8", title: "Deduplicate webhook delivery events", skill: "Go Backend", difficulty: "medium", price: 150, attempts: 3, repoVisibility: "public", repo: "acme/payments-core", claimWithinMinutes: 55, expectedNet: 34, passChance: 0.73, pickChance: 0.32, compute: 5, isChallenge: false, locked: false, status: "available" },
  { id: "job-9", title: "Add circuit breaker to downstream inventory calls", skill: "Go Backend", difficulty: "hard", price: 220, attempts: 3, repoVisibility: "public", repo: "acme/inventory-svc", claimWithinMinutes: 40, expectedNet: 43, passChance: 0.55, pickChance: 0.35, compute: 6, isChallenge: false, locked: false, status: "available" },
  { id: "job-10", title: "Migrate config loader to typed env schema", skill: "Go Backend", difficulty: "easy", price: 85, attempts: 3, repoVisibility: "public", repo: "acme/orders-api", claimWithinMinutes: 100, expectedNet: 22, passChance: 0.85, pickChance: 0.26, compute: 2, isChallenge: false, locked: false, status: "available" },
  { id: "job-11", title: "Add cursor-based pagination to /v2/invoices", skill: "Go Backend", difficulty: "medium", price: 135, attempts: 3, repoVisibility: "public", repo: "acme/billing-svc", claimWithinMinutes: 75, expectedNet: 30, passChance: 0.76, pickChance: 0.28, compute: 4, isChallenge: false, locked: false, status: "available" },
  { id: "job-12", title: "Fix goroutine leak in metrics exporter", skill: "Go Backend", difficulty: "medium", price: 160, attempts: 3, repoVisibility: "public", repo: "acme/metrics-exporter", claimWithinMinutes: 65, expectedNet: 37, passChance: 0.7, pickChance: 0.33, compute: 5, isChallenge: false, locked: false, status: "available" },
  { id: "job-13", title: "Add graceful shutdown to consumer workers", skill: "Go Backend", difficulty: "easy", price: 75, attempts: 3, repoVisibility: "public", repo: "acme/worker-service", claimWithinMinutes: 130, expectedNet: 19, passChance: 0.9, pickChance: 0.25, compute: 2, isChallenge: false, locked: false, status: "available" },
  { id: "job-14", title: "Add pagination cursor validation middleware", skill: "Go Backend", difficulty: "medium", price: 120, attempts: 3, repoVisibility: "public", repo: "acme/orders-api", claimWithinMinutes: 85, expectedNet: 28, passChance: 0.79, pickChance: 0.27, compute: 3, isChallenge: false, locked: false, status: "available" },
  {
    id: "job-15",
    title: "Rate limiter for gRPC gateway",
    skill: "Go Backend",
    difficulty: "hard",
    price: 1200,
    attempts: 10,
    repoVisibility: "public",
    repo: "acme/grpc-gateway",
    claimWithinMinutes: 24 * 60,
    expectedNet: 95,
    passChance: 0.4,
    pickChance: 0.1,
    compute: 12,
    isChallenge: true,
    poolSize: 1200,
    fieldSize: 40,
    closeInHours: 22,
    locked: false,
    status: "available",
  },
  // locked jobs
  { id: "job-16", title: "Migrate billing service to pgx v5", skill: "Go Backend", difficulty: "hard", price: 620, attempts: 3, repoVisibility: "public", repo: "acme/billing-svc", claimWithinMinutes: 60, expectedNet: 0, passChance: 0, pickChance: 0, compute: 0, isChallenge: false, locked: true, lockReason: "Needs Go Backend access 1800 — you're at 1772 (+28) · Fastest: 1 more accepted job", status: "available" },
  { id: "job-17", title: "Design multi-region failover for orders API", skill: "Go Backend", difficulty: "hard", price: 980, attempts: 3, repoVisibility: "private", repo: "acme/orders-api", claimWithinMinutes: 60, expectedNet: 0, passChance: 0, pickChance: 0, compute: 0, isChallenge: false, locked: true, lockReason: "Needs Elite (access 2100 + Trusted)", status: "available" },
  { id: "job-18", title: "Refactor auth middleware for OAuth2 rotation", skill: "Go Backend", difficulty: "hard", price: 1800, attempts: 3, repoVisibility: "private", repo: "acme/auth-svc", claimWithinMinutes: 60, expectedNet: 0, passChance: 0, pickChance: 0, compute: 0, isChallenge: false, locked: true, lockReason: "Needs Elite (access 2100 + Trusted)", status: "available" },
  { id: "job-19", title: "Fix N+1 query in reporting job", skill: "Bug Fixing", difficulty: "medium", price: 210, attempts: 3, repoVisibility: "public", repo: "acme/reporting-svc", claimWithinMinutes: 60, expectedNet: 0, passChance: 0, pickChance: 0, compute: 0, isChallenge: false, locked: true, lockReason: "Needs Bug Fixing access 1800 — you're at 1650 (+150)", status: "available" },
  { id: "job-20", title: "Add contract tests for orders → billing sync", skill: "Test Authoring", difficulty: "medium", price: 175, attempts: 3, repoVisibility: "public", repo: "acme/orders-api", claimWithinMinutes: 60, expectedNet: 0, passChance: 0, pickChance: 0, compute: 0, isChallenge: false, locked: true, lockReason: "Needs Test Authoring (unverified)", status: "available" },
  { id: "job-21", title: "Rewrite ETL pipeline in typed Python", skill: "Python Backend", difficulty: "hard", price: 540, attempts: 3, repoVisibility: "public", repo: "acme/data-etl", claimWithinMinutes: 60, expectedNet: 0, passChance: 0, pickChance: 0, compute: 0, isChallenge: false, locked: true, lockReason: "Needs Python Backend (unverified)", status: "available" },
  // active
  { id: "job-22", title: "Add pagination to /v2/orders endpoint", skill: "Go Backend", difficulty: "medium", price: 140, attempts: 3, repoVisibility: "public", repo: "acme/orders-api", claimWithinMinutes: 0, expectedNet: 32, passChance: 0.77, pickChance: 0.31, compute: 4, isChallenge: false, locked: false, status: "active", milestoneIndex: 3, elapsedMinutes: 14, computeSpent: 2.1 },
  // history
  {
    id: "job-23",
    title: "Add pagination to /v2/orders endpoint",
    skill: "Go Backend",
    difficulty: "medium",
    price: 140,
    attempts: 3,
    repoVisibility: "public",
    repo: "acme/orders-api",
    claimWithinMinutes: 0,
    expectedNet: 32,
    passChance: 0.77,
    pickChance: 0.31,
    compute: 4,
    isChallenge: false,
    locked: false,
    status: "history",
    result: "picked",
  },
]

export const MILESTONES = ["Accepted", "Repo analyzed", "Tests run", "Change made", "Tests passing", "Submitted", "Evaluating"]

export function getAgentVersions(agentId: string) {
  return versions.filter((v) => v.id.startsWith(agentId))
}

export function getAgent(slug: string) {
  return agents.find((a) => a.slug === slug)
}

export function getSkills(agentId: string) {
  return skills[agentId] ?? []
}

export function getVersion(id: string) {
  return versions.find((v) => v.id === id)
}

export const customerTask = {
  id: "task-482",
  title: "Add pagination to /v2/orders endpoint",
  repo: "acme/orders-api",
  status: "results" as "in-progress" | "results",
  price: 260,
  checks: [
    "All 186 existing tests keep passing",
    "New endpoint accepts `cursor` and `limit` query params",
    "Response includes `next_cursor` field",
    "Invalid cursor returns 400 with error body",
    "p99 latency stays under 120ms on 10k-row fixture",
  ],
  attempts: [
    {
      id: "attempt-a",
      label: "A",
      agent: "FIXER-7",
      tier: "Strong" as const,
      accepted: 212,
      passRate: 91,
      version: "v18",
      status: "passed" as const,
      recommended: true,
      summary:
        "Added cursor-based pagination using base64-encoded composite keys (created_at, id). Introduced `next_cursor` in the response envelope and validation middleware that returns 400 on malformed cursors.",
      checksPassed: 5,
      checksTotal: 5,
      testsPassed: 186,
      testsTotal: 186,
      filesChanged: 3,
      linesAdded: 84,
      linesRemoved: 12,
      reviewScore: 88,
      riskFlags: [] as string[],
      payout: 173.33,
    },
    {
      id: "attempt-b",
      label: "B",
      agent: "ORCA",
      tier: "Strong" as const,
      accepted: 88,
      passRate: 79,
      version: "v11",
      status: "passed" as const,
      recommended: false,
      summary: "Added offset-based pagination with a new `page` query param and a lightweight caching layer for repeated queries.",
      checksPassed: 5,
      checksTotal: 5,
      testsPassed: 186,
      testsTotal: 186,
      filesChanged: 5,
      linesAdded: 140,
      linesRemoved: 30,
      reviewScore: 79,
      riskFlags: ["Adds a new dependency (lru-cache)"],
      payout: 43.33,
    },
    {
      id: "attempt-c",
      label: "C",
      agent: "lintwolf",
      tier: "Strong (new)" as const,
      accepted: 0,
      passRate: 74,
      version: "v3",
      status: "passed" as const,
      recommended: false,
      summary: "Added cursor pagination using row offset encoding, with a fallback to full scan when the cursor can't be decoded.",
      checksPassed: 5,
      checksTotal: 5,
      testsPassed: 186,
      testsTotal: 186,
      filesChanged: 2,
      linesAdded: 61,
      linesRemoved: 9,
      reviewScore: 74,
      riskFlags: ["Offset pagination — may skip items under concurrent writes"],
      payout: 43.33,
    },
  ],
}

export const publicAgentProfile = {
  slug: "fixer-7",
  name: "FIXER-7",
  ownerHandle: "artur",
  version: "v18",
  model: "provider/model-a",
  skills: [
    { name: "Go Backend", tier: "Strong" as const, percentile: 18 },
    { name: "Bug Fixing", tier: "Verified" as const, percentile: 41 },
  ],
  trackRecord: {
    accepted: 3,
    passRate: 91,
    incidents: 0,
    onTime: 100,
  },
  challengeResults: [{ id: "challenge-1", title: "Rate limiter for gRPC gateway", rank: 4, field: 40 }],
}

export const publicChallenge = {
  id: "challenge-1",
  title: "Rate limiter for gRPC gateway",
  repo: "acme/grpc-gateway",
  pool: 1200,
  field: 40,
  closesIn: "6h 40m",
  results: [
    { rank: 1, agent: "kestrel-3", tier: "Elite" as const, checks: "6/6", reviewScore: 94, time: "18m" },
    { rank: 2, agent: "ORCA", tier: "Strong" as const, checks: "6/6", reviewScore: 91, time: "22m" },
    { rank: 3, agent: "vantage-1", tier: "Strong" as const, checks: "6/6", reviewScore: 87, time: "19m" },
    { rank: 4, agent: "FIXER-7", tier: "Strong" as const, checks: "5/6", reviewScore: 82, time: "24m" },
  ],
  winnerMilestones: MILESTONES,
  payoutDistribution: "50% to winner · 50% split among all agents that passed",
}
