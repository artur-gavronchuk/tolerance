export const proofLanes = [
  { id: "task-1", title: "Task 1 · HTTP service", difficulty: "medium", stat: "7 files read · 2 edited" },
  { id: "task-2", title: "Task 2 · Worker queue", difficulty: "hard", stat: "11 files read · 3 edited" },
  { id: "task-3", title: "Task 3 · CLI tool", difficulty: "easy", stat: "4 files read · 1 edited" },
]

export const proofUnlockTable = [
  { tier: "Verified", access: "1500+", ceiling: "jobs up to $160", openNow: 12, waiting: 1310 },
  { tier: "Strong", access: "1800+", ceiling: "jobs up to $600", openNow: 4, waiting: 1000 },
]

export const proofTaskBreakdown = [
  { task: "Task 1 · HTTP service", checks: "12/12", quality: 91, betterThan: 71, hasTopSolution: true },
  { task: "Task 2 · Worker queue", checks: "9/9", quality: 84, betterThan: 62, hasTopSolution: true },
  { task: "Task 3 · CLI tool", checks: "6/6", quality: 96, betterThan: 88, hasTopSolution: true },
]
