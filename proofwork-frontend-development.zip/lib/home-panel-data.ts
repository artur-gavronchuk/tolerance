import type { Confidence } from "./types"

export interface AccessPanelData {
  visible: boolean
  skillName: string
  rating: number
  confidence: Confidence
  percentile: number
  accessRating: number
  tierMarkerPct: number // 0-100 position on the Verified..Elite ladder
  ceilingText: string
  nextText: string
  fastest: string
}

export interface MoneyPanelData {
  waiting: boolean
  waitingText?: string
  proofsLeftText?: string
  netLabel?: string
  net?: number
  earned?: number
  fees?: number
  compute?: number
}

export interface NowAction {
  primaryHref: string
  secondaryHref?: string
  borderTone?: "default" | "destructive"
}

const laddderPct = (access: number) => Math.min(100, Math.max(0, ((access - 1500) / (2400 - 1500)) * 100))

export function getAccessPanel(stateId: string): AccessPanelData {
  const na: AccessPanelData = {
    visible: false,
    skillName: "Go Backend",
    rating: 0,
    confidence: "low",
    percentile: 0,
    accessRating: 0,
    tierMarkerPct: 0,
    ceilingText: "",
    nextText: "",
    fastest: "",
  }
  switch (stateId) {
    case "H0":
    case "H1":
    case "H2":
    case "H3":
    case "H4":
    case "H5":
      return na
    case "H6":
      return {
        ...na,
        visible: true,
        rating: 1490,
        confidence: "low",
        percentile: 61,
        accessRating: 1435,
        tierMarkerPct: laddderPct(1435),
        ceilingText: "Proofs only — not yet at access 1500",
        nextText: "Needs access 1500 (+65)",
        fastest: "Fastest: 2 proofs left today",
      }
    case "H7":
      return {
        ...na,
        visible: true,
        rating: 1842,
        confidence: "low",
        percentile: 24,
        accessRating: 1790,
        tierMarkerPct: laddderPct(1790),
        ceilingText: "jobs up to $150",
        nextText: "jobs up to $620 · needs access 1800 (+10)",
        fastest: "Fastest: 1 paid job or 2 proofs",
      }
    case "H10":
      return {
        ...na,
        visible: true,
        rating: 1869,
        confidence: "medium",
        percentile: 21,
        accessRating: 1822,
        tierMarkerPct: laddderPct(1822),
        ceilingText: "jobs up to $610",
        nextText: "jobs up to $1,000 · needs access 2100 (+278)",
        fastest: "Fastest: 6 more accepted jobs",
      }
    case "H11":
      return {
        ...na,
        visible: true,
        rating: 1869,
        confidence: "medium",
        percentile: 21,
        accessRating: 1822,
        tierMarkerPct: laddderPct(1822),
        ceilingText: "jobs up to $620",
        nextText: "jobs up to $1,000 · needs access 2100 (+278)",
        fastest: "Fastest: 6 more accepted jobs",
      }
    case "H20":
      return {
        ...na,
        visible: true,
        rating: 1934,
        confidence: "high",
        percentile: 14,
        accessRating: 1926,
        tierMarkerPct: laddderPct(1926),
        ceilingText: "jobs up to $760",
        nextText: "jobs up to $1,000 · needs access 2100 (+174)",
        fastest: "Fastest: 4 more accepted jobs",
      }
    default:
      return {
        ...na,
        visible: true,
        rating: 1887,
        confidence: "medium",
        percentile: 18,
        accessRating: 1831,
        tierMarkerPct: laddderPct(1831),
        ceilingText: "jobs up to $640",
        nextText: "jobs up to $1,000 · needs access 2100 (+269)",
        fastest: "Fastest: 2 more proofs or 1 paid job",
      }
  }
}

export function getMoneyPanel(stateId: string): MoneyPanelData {
  switch (stateId) {
    case "H0":
    case "H1":
    case "H2":
    case "H3":
      return { waiting: true, waitingText: "Connect an agent to see what's waiting for it." }
    case "H4":
      return { waiting: true, waitingText: "$2,310 waiting for a verified Go Backend agent", proofsLeftText: "Proofs today: 3 of 3 left" }
    case "H5":
      return { waiting: true, waitingText: "$2,310 waiting for a verified Go Backend agent", proofsLeftText: "Proofs today: 1 of 3 left" }
    case "H6":
      return { waiting: true, waitingText: "$2,310 waiting for a verified Go Backend agent", proofsLeftText: "Proofs today: 2 of 3 left" }
    case "H7":
      return { waiting: true, waitingText: "$1,310 waiting · 12 jobs open now", proofsLeftText: "Proofs today: 1 of 3 left" }
    case "H10":
      return { waiting: false, netLabel: "Net today", net: 68.9, earned: 80, fees: 8, compute: 3.1 }
    case "H16":
      return { waiting: false, netLabel: "Net today", net: 143, earned: 168, fees: 16.8, compute: 8.2 }
    case "H17":
      return { waiting: false, netLabel: "Net this week", net: 487, earned: 601, fees: 60, compute: 54 }
    case "H20":
      return { waiting: false, netLabel: "Net this month", net: 2940, earned: 3402, fees: 340, compute: 122 }
    default:
      return { waiting: false, netLabel: "Net this week", net: 1204, earned: 1390, fees: 139, compute: 47 }
  }
}

export const NOW_ACTIONS: Record<string, NowAction> = {
  H0: { primaryHref: "/app", secondaryHref: "/" },
  H1: { primaryHref: "/app", secondaryHref: "/" },
  H2: { primaryHref: "/app" },
  H3: { primaryHref: "/app", secondaryHref: "/app", borderTone: "destructive" },
  H4: { primaryHref: "/app/proof/proof-1", secondaryHref: "/app/skills" },
  H5: { primaryHref: "/app/proof/proof-1" },
  H6: { primaryHref: "/app/proof/proof-1", secondaryHref: "/app/proof/proof-1" },
  H7: { primaryHref: "/app/work", secondaryHref: "/app/skills" },
  H8: { primaryHref: "/app/work" },
  H9: { primaryHref: "/app/work" },
  H10: { primaryHref: "/app/work", secondaryHref: "/app/earnings" },
  H11: { primaryHref: "/app/work" },
  H12: { primaryHref: "/app/work", secondaryHref: "/app/skills" },
  H13: { primaryHref: "/app/versions", secondaryHref: "/app/versions" },
  H14: { primaryHref: "/app/versions", secondaryHref: "/app/versions" },
  H15: { primaryHref: "/app/work", secondaryHref: "/app" },
  H16: { primaryHref: "/app/work", secondaryHref: "/app/work" },
  H17: { primaryHref: "/app/earnings", secondaryHref: "/app/work" },
  H18: { primaryHref: "/app/work", secondaryHref: "/app/work" },
  H19: { primaryHref: "/app", secondaryHref: "/app", borderTone: "destructive" },
  H20: { primaryHref: "/app/skills" },
}
