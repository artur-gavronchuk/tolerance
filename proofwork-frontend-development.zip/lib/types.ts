export type Confidence = "low" | "medium" | "high"
export type Tier = "none" | "verified" | "strong" | "elite"
export type AgentStatus = "no-agent" | "registered" | "connected" | "checking" | "check-failed" | "operational" | "offline"
export type WorkMode = "manual" | "assisted" | "autopilot"

export interface Owner {
  name: string
  handle: string
}

export interface AgentVersion {
  id: string
  label: string // "v18"
  status: "production" | "staging" | "retired"
  model: string
  tools: string[]
  memory: string
  orchestration: string
  promptsHash: string
  deployedDate: string
  jobsOnVersion: number
  changeClass?: "patch" | "minor" | "major"
}

export interface SkillRating {
  id: string
  name: string
  rating: number
  confidence: Confidence
  percentile: number // top X%
  verified: boolean
  proofsToday: number
  proofsPerDay: number
  proofHistory: ProofHistoryEntry[]
}

export interface ProofHistoryEntry {
  id: string
  date: string
  skill: string
  result: "passed" | "failed" | "partial"
  ratingBefore: number
  ratingAfter: number
  tasksPassed: number
  tasksTotal: number
}

export interface Agent {
  id: string
  slug: string
  name: string
  status: AgentStatus
  mode: WorkMode
  trusted: boolean
  acceptedJobs: number
  currentVersionId: string
  connectCommand: string
}

export interface JobMeta {
  id: string
  title: string
  skill: string
  difficulty: "easy" | "medium" | "hard"
  price: number
  attempts: number
  repoVisibility: "public" | "private"
  repo: string
  claimWithinMinutes: number
  expectedNet: number
  passChance: number
  pickChance: number
  compute: number
  isChallenge: boolean
  poolSize?: number
  fieldSize?: number
  closeInHours?: number
  locked: boolean
  lockReason?: string
  status?: "available" | "active" | "history"
  milestoneIndex?: number
  elapsedMinutes?: number
  computeSpent?: number
  result?: "picked" | "passed" | "failed"
}

export interface HomeStateContext {
  bestFirstJobs?: { id: string; title: string; expectedNet: number; price: number }[]
  inFlight?: { id: string; title: string; milestoneIndex: number; elapsedMinutes: number; compute: number }[]
  checklist?: { label: string; done: boolean }[]
  events?: { time: string; text: string; delta?: string }[]
  backtest?: { taken: number; total: number; accepted: number; picked: number; netEst: number; peakCompute: number }
  away?: {
    from: string
    to: string
    net: number
    earned: number
    fees: number
    compute: number
    attempts: number
    accepted: number
    picked: number
    incidents: number
    ratingFrom: number
    ratingTo: number
    skipped: number
    skippedBelow: number
    skippedExcluded: number
  }
}

export interface HomeState {
  id: string
  label: string
  headline: string
  contextLine?: string
  primary: string
  secondary?: string
  context: HomeStateContext
}
