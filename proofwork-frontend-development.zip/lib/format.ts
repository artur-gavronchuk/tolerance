export function money(value: number, decimals: 0 | 2 = 2) {
  const sign = value < 0 ? "-" : ""
  const abs = Math.abs(value)
  return `${sign}$${abs.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}`
}

export function moneyRounded(value: number) {
  return money(Math.round(value), 0)
}

export function pct(value: number) {
  return `${Math.round(value * 100)}%`
}
