import type { Tier } from "./types"

// Access rating = rating - uncertainty. For mock purposes we treat the stored
// rating as the access rating directly unless a raw rating + confidence pair
// is supplied, in which case uncertainty shaves a bit off.
export function toAccessRating(rating: number, confidence: "low" | "medium" | "high") {
  const uncertainty = confidence === "low" ? 55 : confidence === "medium" ? 25 : 8
  return Math.max(0, Math.round(rating - uncertainty))
}

export function getTier(accessRating: number): Tier {
  if (accessRating >= 2100) return "elite"
  if (accessRating >= 1800) return "strong"
  if (accessRating >= 1500) return "verified"
  return "none"
}

export function tierLabel(tier: Tier) {
  switch (tier) {
    case "elite":
      return "Elite"
    case "strong":
      return "Strong"
    case "verified":
      return "Verified"
    default:
      return "Unverified"
  }
}

const BANDS: { tier: Tier; min: number; max: number; priceMin: number; priceMax: number }[] = [
  { tier: "verified", min: 1500, max: 1799, priceMin: 80, priceMax: 160 },
  { tier: "strong", min: 1800, max: 2099, priceMin: 600, priceMax: 1000 },
  { tier: "elite", min: 2100, max: 2500, priceMin: 1000, priceMax: 2000 },
]

/** Linear interpolation of the job ceiling ($) for a given access rating. */
export function jobCeiling(accessRating: number): number {
  if (accessRating < 1500) return 0
  const band = BANDS.find((b) => accessRating >= b.min && accessRating <= b.max) ?? BANDS[BANDS.length - 1]
  const span = band.max - band.min
  const pct = span > 0 ? (accessRating - band.min) / span : 1
  return Math.round(band.priceMin + pct * (band.priceMax - band.priceMin))
}

/** Distance (in access points) and the next threshold that raises the ceiling. */
export function nextThreshold(accessRating: number): { nextAt: number; distance: number; nextCeiling: number; nextTier: Tier } | null {
  const thresholds: { at: number; tier: Tier }[] = [
    { at: 1500, tier: "verified" },
    { at: 1800, tier: "strong" },
    { at: 2100, tier: "elite" },
  ]
  const next = thresholds.find((t) => accessRating < t.at)
  if (!next) return null
  return {
    nextAt: next.at,
    distance: next.at - accessRating,
    nextCeiling: jobCeiling(next.at),
    nextTier: next.tier,
  }
}

export function computePayout(price: number, passingAttempts: number, wasPicked: boolean) {
  const bonusPool = price * 0.5
  const basePool = price * 0.5
  const baseShare = passingAttempts > 0 ? basePool / passingAttempts : 0
  const payout = baseShare + (wasPicked ? bonusPool : 0)
  const fee = payout * 0.1
  return { payout, fee, bonusPool, baseShare }
}

export function expectedNet(price: number, passChance: number, pickChance: number, compute: number) {
  const bonusPool = price * 0.5
  const baseShare = price * 0.5 // approximation for a 3-attempt job (split among passers)
  const gross = passChance * baseShare + pickChance * bonusPool
  const fee = gross * 0.1
  return Math.max(0, gross - fee - compute)
}
