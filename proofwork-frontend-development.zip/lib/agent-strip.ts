export type DoingStatus = "idle" | "working" | "proving" | "offline" | "autopilot" | "checking" | "none"

export interface AgentStripData {
  doingStatus: DoingStatus
  doingText: string
  provenText: string
  accessText: string
  accessHref: string
  earnedText: string
  nextText: string
  nextHref: string
}

const base: Omit<AgentStripData, "doingStatus" | "doingText" | "nextText" | "nextHref"> = {
  provenText: "Go Backend 1887 · Bug Fixing 1702",
  accessText: "16 jobs open to you",
  accessHref: "/app/work",
  earnedText: "Net this week $1,204",
}

const unqualifiedBase = {
  provenText: "No verified skills",
  accessText: "$2,310 waiting",
  accessHref: "/app/skills",
  earnedText: "Net this week $0.00",
}

export function getAgentStripData(stateId: string): AgentStripData {
  switch (stateId) {
    case "H0":
      return { doingStatus: "none", doingText: "No agent connected", nextText: "Connect your agent →", nextHref: "/app", ...unqualifiedBase }
    case "H1":
      return { doingStatus: "checking", doingText: "FIXER-7 · Waiting for handshake", nextText: "Copy connect command →", nextHref: "/app", ...unqualifiedBase }
    case "H2":
      return { doingStatus: "checking", doingText: "FIXER-7 · Checking runtime…", nextText: "Watch checks →", nextHref: "/app", ...unqualifiedBase }
    case "H3":
      return { doingStatus: "offline", doingText: "FIXER-7 · Check failed", nextText: "Retry check →", nextHref: "/app", ...unqualifiedBase }
    case "H4":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", nextText: "Prove Go Backend →", nextHref: "/app/skills", ...unqualifiedBase }
    case "H5":
      return { doingStatus: "proving", doingText: "FIXER-7 v18 · Proving Go Backend", nextText: "Watch run →", nextHref: "/app/proof/proof-1", ...unqualifiedBase, earnedText: "Net this week $0.00" }
    case "H6":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", nextText: "Try again →", nextHref: "/app/skills", ...unqualifiedBase }
    case "H7":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", provenText: "Go Backend 1842", accessText: "12 jobs open to you", accessHref: "/app/work", earnedText: "Net this week $0.00", nextText: "See 12 jobs →", nextHref: "/app/work" }
    case "H8":
      return { doingStatus: "working", doingText: "FIXER-7 v18 · Working on 2 jobs", nextText: "Watch →", nextHref: "/app/work", ...base, earnedText: "Net this week $0.00" }
    case "H9":
      return { doingStatus: "working", doingText: "FIXER-7 v18 · Evaluating 2 submissions", nextText: "Watch →", nextHref: "/app/work", ...base, earnedText: "Net this week $0.00" }
    case "H10":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", provenText: "Go Backend 1869", nextText: "Take another job →", nextHref: "/app/work", accessText: "12 jobs open to you", accessHref: "/app/work", earnedText: "Net this week $68.90" }
    case "H11":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", provenText: "Go Backend 1869", nextText: "See new jobs →", nextHref: "/app/work", accessText: "16 jobs open to you", accessHref: "/app/work", earnedText: "Net this week $68.90" }
    case "H12":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", nextText: "Prove Bug Fixing →", nextHref: "/app/skills", ...base }
    case "H13":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", nextText: "Run v19 in staging →", nextHref: "/app/versions", ...base }
    case "H14":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", nextText: "Promote v19 →", nextHref: "/app/versions", ...base }
    case "H15":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", nextText: "Set up Autopilot →", nextHref: "/app/work", ...base }
    case "H16":
      return { doingStatus: "autopilot", doingText: "FIXER-7 v18 · Autopilot on · 2 attempts running", nextText: "Edit rules →", nextHref: "/app/work", ...base, earnedText: "Net today $143.00" }
    case "H17":
      return { doingStatus: "autopilot", doingText: "FIXER-7 v18 · Autopilot on", nextText: "See activity →", nextHref: "/app", ...base, earnedText: "Net this week $487.00" }
    case "H18":
      return { doingStatus: "offline", doingText: "FIXER-7 v18 · Autopilot paused", nextText: "Review failures →", nextHref: "/app/work", ...base }
    case "H19":
      return { doingStatus: "offline", doingText: "FIXER-7 v18 · Offline", nextText: "Check runtime →", nextHref: "/app", ...base }
    case "H20":
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", provenText: "Go Backend 1934", nextText: "Prove Python Backend →", nextHref: "/app/skills", accessText: "18 jobs open to you", accessHref: "/app/work", earnedText: "Net this month $2,940.00" }
    default:
      return { doingStatus: "idle", doingText: "FIXER-7 v18 · Idle", nextText: "See jobs →", nextHref: "/app/work", ...base }
  }
}
