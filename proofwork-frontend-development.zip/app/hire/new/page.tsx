"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { WizardHeader } from "@/components/hire/wizard-header"
import { SummaryCard } from "@/components/hire/summary-card"
import { StepDescribe } from "@/components/hire/step-describe"
import { StepReview } from "@/components/hire/step-review"
import { StepConfidence } from "@/components/hire/step-confidence"
import { StepPay } from "@/components/hire/step-pay"
import { confidenceOptions, generatedChecks } from "@/lib/confidence-options"

export default function NewTaskPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [description, setDescription] = useState("")
  const [repo, setRepo] = useState("acme/orders-api")
  const [issueLink, setIssueLink] = useState("")
  const [selectedOption, setSelectedOption] = useState("recommended")

  const option = confidenceOptions.find((o) => o.id === selectedOption) ?? confidenceOptions[1]

  return (
    <div className="space-y-8">
      <WizardHeader step={step} />

      <div className="grid gap-8 lg:grid-cols-3">
        <div className="lg:col-span-2">
          {step === 1 && (
            <StepDescribe
              description={description}
              setDescription={setDescription}
              repo={repo}
              setRepo={setRepo}
              issueLink={issueLink}
              setIssueLink={setIssueLink}
              onContinue={() => setStep(2)}
            />
          )}
          {step === 2 && <StepReview onContinue={() => setStep(3)} />}
          {step === 3 && <StepConfidence selected={selectedOption} setSelected={setSelectedOption} onContinue={() => setStep(4)} />}
          {step === 4 && <StepPay option={option} repo={repo} onPay={() => router.push("/hire/tasks/task-482")} />}
        </div>
        {step >= 2 && (
          <div>
            <SummaryCard repo={repo} checkCount={generatedChecks.length} option={step >= 3 ? option : undefined} />
          </div>
        )}
      </div>
    </div>
  )
}
