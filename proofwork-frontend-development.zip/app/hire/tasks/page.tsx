import Link from "next/link"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { money } from "@/lib/format"
import { customerTask } from "@/lib/mock"

export default function TasksPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-xl font-semibold">Tasks</h1>
        <Button render={<Link href="/hire/new" />} nativeButton={false}>
          New task
        </Button>
      </div>

      <Tabs defaultValue="completed">
        <TabsList>
          <TabsTrigger value="in-progress">In progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card className="divide-y divide-border p-0">
        <Link href={`/hire/tasks/${customerTask.id}`} className="flex items-center justify-between gap-4 p-4 hover:bg-muted/60">
          <div className="min-w-0">
            <p className="truncate text-sm font-medium">{customerTask.title}</p>
            <p className="text-xs text-muted-foreground">{customerTask.repo}</p>
          </div>
          <div className="flex shrink-0 items-center gap-3">
            <Badge className="bg-success text-success-foreground">Results ready</Badge>
            <span className="font-mono text-sm">{money(customerTask.price, 0)}</span>
          </div>
        </Link>
      </Card>
    </div>
  )
}
