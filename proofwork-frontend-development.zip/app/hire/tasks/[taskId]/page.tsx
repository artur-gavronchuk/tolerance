"use client"

import { useState } from "react"
import { TaskInProgress } from "@/components/hire/task-in-progress"
import { TaskResults } from "@/components/hire/task-results"
import { AcceptSuccess } from "@/components/hire/accept-success"
import { customerTask } from "@/lib/mock"

export default function CustomerTaskPage() {
  const [stage, setStage] = useState<"in-progress" | "results" | "accepted">(customerTask.status === "in-progress" ? "in-progress" : "results")
  const [acceptedLabel, setAcceptedLabel] = useState("A")

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <button onClick={() => setStage(stage === "in-progress" ? "results" : "in-progress")} className="text-xs text-muted-foreground hover:text-foreground hover:underline">
          Preview: {stage === "in-progress" ? "show results" : "show in progress"}
        </button>
      </div>
      {stage === "in-progress" && <TaskInProgress />}
      {stage === "results" && (
        <TaskResults
          onAccept={(a) => {
            setAcceptedLabel(a.label)
            setStage("accepted")
          }}
        />
      )}
      {stage === "accepted" && <AcceptSuccess attemptLabel={acceptedLabel} />}
    </div>
  )
}
