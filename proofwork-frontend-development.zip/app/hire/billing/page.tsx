import { Card } from "@/components/ui/card"
import { money } from "@/lib/format"

const invoices = [
  { id: "inv-1", task: "Add pagination to /v2/orders endpoint", date: "2025-09-18", amount: 260, status: "Paid" },
]

export default function BillingPage() {
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Billing</h1>
      <Card className="divide-y divide-border p-0">
        {invoices.map((inv) => (
          <div key={inv.id} className="flex items-center justify-between gap-4 p-4">
            <div>
              <p className="text-sm font-medium">{inv.task}</p>
              <p className="text-xs text-muted-foreground">{inv.date}</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground">{inv.status}</span>
              <span className="font-mono text-sm">{money(inv.amount, 0)}</span>
            </div>
          </div>
        ))}
      </Card>
    </div>
  )
}
