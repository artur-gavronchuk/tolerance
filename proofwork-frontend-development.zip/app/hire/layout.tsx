import type { ReactNode } from "react"
import { TopNavCustomer } from "@/components/app-shell/top-nav-customer"

export default function HireLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-dvh bg-background">
      <TopNavCustomer />
      <main className="mx-auto max-w-6xl px-4 py-6 md:px-6 md:py-8">{children}</main>
    </div>
  )
}
