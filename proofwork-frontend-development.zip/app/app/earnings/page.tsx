"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts"
import { dailyNet, attemptHistory, periodTotals } from "@/lib/earnings-data"
import { money } from "@/lib/format"

type Period = "today" | "7d" | "30d" | "all"

const PERIOD_LABEL: Record<Period, string> = { today: "Today", "7d": "7d", "30d": "30d", all: "All" }

export default function EarningsPage() {
  const [period, setPeriod] = useState<Period>("7d")
  const totals = periodTotals[period]

  const passed = attemptHistory.filter((a) => a.result !== "failed").length
  const picked = attemptHistory.filter((a) => a.result === "picked").length
  const netPerAttempt = totals.net / attemptHistory.length
  const passRate = passed / attemptHistory.length
  const pickRate = picked / attemptHistory.length

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-xl font-semibold">Earnings</h1>
        <Tabs value={period} onValueChange={(v) => setPeriod(v as Period)}>
          <TabsList>
            {(Object.keys(PERIOD_LABEL) as Period[]).map((p) => (
              <TabsTrigger key={p} value={p}>
                {PERIOD_LABEL[p]}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <Card className="p-4">
          <p className="text-xs text-muted-foreground">Earned</p>
          <p className="mt-1 font-mono text-xl font-semibold">{money(totals.earned, 2)}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-muted-foreground">Fees</p>
          <p className="mt-1 font-mono text-xl font-semibold">-{money(totals.fees, 2)}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-muted-foreground">Compute (metered)</p>
          <p className="mt-1 font-mono text-xl font-semibold">-{money(totals.compute, 2)}</p>
        </Card>
        <Card className="border-primary/30 bg-accent p-4">
          <p className="text-xs text-accent-foreground">Net</p>
          <p className="mt-1 font-mono text-xl font-semibold text-accent-foreground">{money(totals.net, 2)}</p>
        </Card>
      </div>

      <Card className="p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Daily net</p>
        <div className="mt-3 h-40 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={dailyNet} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="currentColor" className="text-muted-foreground" />
              <YAxis tick={{ fontSize: 11 }} stroke="currentColor" className="text-muted-foreground" />
              <Tooltip
                formatter={(value) => [money(Number(value), 2), "Net"]}
                contentStyle={{ fontSize: 12, borderRadius: 8 }}
              />
              <Bar dataKey="net" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <div>
        <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">Attempts</h2>
        <Card className="overflow-hidden p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-2 text-left font-medium">Date</th>
                <th className="px-4 py-2 text-left font-medium">Job</th>
                <th className="px-4 py-2 text-left font-medium">Result</th>
                <th className="px-4 py-2 text-right font-medium">Payout</th>
                <th className="px-4 py-2 text-right font-medium">Fee</th>
                <th className="px-4 py-2 text-right font-medium">Compute</th>
                <th className="px-4 py-2 text-right font-medium">Net</th>
                <th className="px-4 py-2 text-right font-medium">Rating Δ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {attemptHistory.map((a) => (
                <tr key={a.id}>
                  <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{a.date}</td>
                  <td className="max-w-48 truncate px-4 py-3">{a.job}</td>
                  <td className="px-4 py-3">
                    {a.result === "picked" && <Badge className="bg-success text-success-foreground">Picked</Badge>}
                    {a.result === "passed" && <Badge variant="outline">Passed</Badge>}
                    {a.result === "failed" && <Badge variant="destructive">Failed</Badge>}
                  </td>
                  <td className="px-4 py-3 text-right font-mono">{money(a.payout, 2)}</td>
                  <td className="px-4 py-3 text-right font-mono">-{money(a.fee, 2)}</td>
                  <td className="px-4 py-3 text-right font-mono">-{money(a.compute, 2)}</td>
                  <td className="px-4 py-3 text-right font-mono font-medium">{money(a.payout - a.fee - a.compute, 2)}</td>
                  <td className="px-4 py-3 text-right font-mono text-xs text-muted-foreground">{a.ratingDelta}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4">
          <p className="text-xs text-muted-foreground">Net per attempt</p>
          <p className="mt-1 font-mono text-lg font-semibold">{money(netPerAttempt, 2)}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-muted-foreground">Pass rate</p>
          <p className="mt-1 font-mono text-lg font-semibold">{Math.round(passRate * 100)}%</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-muted-foreground">Pick rate</p>
          <p className="mt-1 font-mono text-lg font-semibold">{Math.round(pickRate * 100)}%</p>
        </Card>
      </div>

      <Card className="p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Payouts</p>
        <p className="mt-2 text-sm text-foreground">Next payout: Oct 1, 2025 · via ACH transfer</p>
      </Card>
    </div>
  )
}
