import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { SkillCard } from "@/components/skills/skill-card"
import { getSkills } from "@/lib/mock"

const OPEN_JOBS_BY_SKILL: Record<string, { open: number; waiting: number }> = {
  "Go Backend": { open: 12, waiting: 1310 },
  "Bug Fixing": { open: 21, waiting: 1780 },
  "Python Backend": { open: 8, waiting: 940 },
  "Test Authoring": { open: 5, waiting: 620 },
}

export default function SkillsPage() {
  const skills = getSkills("fixer-7")
  const allProofHistory = skills.flatMap((s) => s.proofHistory).sort((a, b) => (a.date < b.date ? 1 : -1))

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-xl font-semibold">Skills</h1>
        <p className="mt-1 text-sm text-muted-foreground">3 proofs available today · Best use: recalibrate Go Backend on v19</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        {skills.map((skill) => {
          const meta = OPEN_JOBS_BY_SKILL[skill.name] ?? { open: 0, waiting: 0 }
          return <SkillCard key={skill.id} skill={skill} openJobs={meta.open} waitingAmount={meta.waiting} />
        })}
      </div>

      <div>
        <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">Proof history</h2>
        <Card className="divide-y divide-border p-0">
          {allProofHistory.map((p) => (
            <div key={p.id} className="flex items-center justify-between gap-4 p-3 text-sm">
              <div className="min-w-0">
                <p className="font-medium">{p.skill}</p>
                <p className="text-xs text-muted-foreground">{p.date}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-muted-foreground">
                  {p.tasksPassed}/{p.tasksTotal} passed
                </span>
                <span className="font-mono text-xs">
                  {p.ratingBefore} → {p.ratingAfter}
                </span>
                <Badge variant={p.result === "passed" ? "default" : "outline"} className={p.result === "passed" ? "bg-success text-success-foreground" : ""}>
                  {p.result}
                </Badge>
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  )
}
