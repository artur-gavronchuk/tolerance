"use client"

import { useEffect, useRef, useState } from "react"
import { ProofPreRun } from "@/components/proof/pre-run"
import { ProofRunning } from "@/components/proof/running"
import { ProofResultSuccess } from "@/components/proof/result-success"
import { ProofResultFailure } from "@/components/proof/result-failure"

type Phase = "pre-run" | "running" | "result-success" | "result-failure"

export default function ProofPage() {
  const [phase, setPhase] = useState<Phase>("pre-run")
  const [elapsedSeconds, setElapsedSeconds] = useState(0)
  const [laneProgress, setLaneProgress] = useState([0, 0, 0])
  const [compute, setCompute] = useState(0)
  const tickRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (phase !== "running") {
      if (tickRef.current) clearInterval(tickRef.current)
      return
    }
    tickRef.current = setInterval(() => {
      setElapsedSeconds((s) => s + 1)
      setCompute((c) => Math.min(3.8, c + 0.05))
      setLaneProgress((lanes) => {
        const next = [...lanes]
        const idx = next.findIndex((v) => v < 6)
        if (idx !== -1) next[idx] = Math.min(6, next[idx] + 1)
        return next
      })
    }, 350)
    return () => {
      if (tickRef.current) clearInterval(tickRef.current)
    }
  }, [phase])

  useEffect(() => {
    if (phase === "running" && laneProgress.every((v) => v >= 6)) {
      const timeout = setTimeout(() => setPhase("result-success"), 600)
      return () => clearTimeout(timeout)
    }
  }, [phase, laneProgress])

  return (
    <div>
      {phase === "pre-run" && <ProofPreRun onStart={() => setPhase("running")} />}
      {phase === "running" && <ProofRunning elapsedSeconds={elapsedSeconds} laneProgress={laneProgress} compute={compute} />}
      {phase === "result-success" && <ProofResultSuccess />}
      {phase === "result-failure" && (
        <ProofResultFailure
          onRetry={() => {
            setElapsedSeconds(0)
            setCompute(0)
            setLaneProgress([0, 0, 0])
            setPhase("running")
          }}
        />
      )}
    </div>
  )
}
