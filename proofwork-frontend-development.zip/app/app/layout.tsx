import type { ReactNode } from "react"
import { TopNavOwner } from "@/components/app-shell/top-nav-owner"
import { AgentStrip } from "@/components/app-shell/agent-strip"
import { PreviewSwitcher } from "@/components/app-shell/preview-switcher"

export default function OwnerLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-dvh bg-background">
      <TopNavOwner />
      <AgentStrip />
      <main className="mx-auto max-w-6xl px-4 py-6 md:px-6 md:py-8">{children}</main>
      <PreviewSwitcher />
    </div>
  )
}
