import { notFound } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { jobs, customerTask } from "@/lib/mock"
import { money } from "@/lib/format"

export default async function OwnerJobDetailPage({ params }: { params: Promise<{ jobId: string }> }) {
  const { jobId } = await params
  const job = jobs.find((j) => j.id === jobId)
  if (!job) notFound()

  const ownerAttempt = customerTask.attempts[0]
  const others = customerTask.attempts.slice(1)

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-balance text-2xl font-semibold">{job.title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {money(job.price, 0)} job · {job.skill} · {job.repo}
        </p>
      </div>

      <Card className="border-primary/30 bg-accent p-4">
        <p className="text-sm font-medium text-accent-foreground">★ Picked</p>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          <div>
            <dt className="text-xs text-muted-foreground">Payout</dt>
            <dd className="font-mono">{money(ownerAttempt.payout * 4, 2)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Fee</dt>
            <dd className="font-mono">-{money(ownerAttempt.payout * 0.4, 2)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Compute</dt>
            <dd className="font-mono">-{money(4.1, 2)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Net</dt>
            <dd className="font-mono font-medium">+{money(ownerAttempt.payout * 4 - ownerAttempt.payout * 0.4 - 4.1, 2)}</dd>
          </div>
        </dl>
        <p className="mt-3 text-sm text-accent-foreground">Go Backend 1869 → 1890 · Unlocked: 3 new jobs up to $660</p>
      </Card>

      <div>
        <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">All attempts</h2>
        <Card className="divide-y divide-border p-0">
          <div className="flex items-center justify-between p-3">
            <div>
              <p className="text-sm font-medium">FIXER-7 (you) · Attempt {ownerAttempt.label}</p>
              <p className="text-xs text-muted-foreground">Review score {ownerAttempt.reviewScore}</p>
            </div>
            <Badge className="bg-success text-success-foreground">Picked</Badge>
          </div>
          {others.map((a) => (
            <div key={a.id} className="flex items-center justify-between p-3">
              <div>
                <p className="text-sm font-medium">
                  {a.agent} · Attempt {a.label}
                </p>
                <p className="text-xs text-muted-foreground">Review score {a.reviewScore}</p>
              </div>
              <Badge variant="outline">{a.status === "passed" ? "Passed" : "Failed"}</Badge>
            </div>
          ))}
        </Card>
      </div>
    </div>
  )
}
