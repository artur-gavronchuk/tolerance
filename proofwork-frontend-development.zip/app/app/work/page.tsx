"use client"

import { useMemo, useState } from "react"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { MilestoneStepper } from "@/components/milestone-stepper"
import { ModeBar } from "@/components/work/mode-bar"
import { JobRow, LockedJobRow } from "@/components/work/job-row"
import { JobDrawer } from "@/components/work/job-drawer"
import { AutopilotSheet } from "@/components/work/autopilot-sheet"
import { Card } from "@/components/ui/card"
import { jobs } from "@/lib/mock"
import { money } from "@/lib/format"
import type { JobMeta, WorkMode } from "@/lib/types"

export default function WorkPage() {
  const [tab, setTab] = useState<"available" | "active" | "history">("available")
  const [mode, setMode] = useState<WorkMode>("manual")
  const [skillFilter, setSkillFilter] = useState("all")
  const [challengesOnly, setChallengesOnly] = useState(false)
  const [selectedJob, setSelectedJob] = useState<JobMeta | null>(null)
  const [autopilotOpen, setAutopilotOpen] = useState(false)

  const available = jobs.filter((j) => j.status === "available" && !j.locked)
  const locked = jobs.filter((j) => j.status === "available" && j.locked)
  const active = jobs.filter((j) => j.status === "active")
  const history = jobs.filter((j) => j.status === "history")

  const filteredAvailable = useMemo(() => {
    return available
      .filter((j) => skillFilter === "all" || j.skill === skillFilter)
      .filter((j) => !challengesOnly || j.isChallenge)
      .sort((a, b) => b.expectedNet - a.expectedNet)
  }, [available, skillFilter, challengesOnly])

  const lockedTotal = locked.reduce((sum, j) => sum + j.price, 0)

  const skills = Array.from(new Set(jobs.map((j) => j.skill)))

  function handleModeSelect(next: WorkMode) {
    if (next === "autopilot") {
      setAutopilotOpen(true)
      return
    }
    setMode(next)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-xl font-semibold">Work</h1>
        <ModeBar
          mode={mode}
          onSelect={handleModeSelect}
          options={[
            { id: "manual", label: "Manual", locked: false },
            { id: "assisted", label: "Assisted", locked: true, lockReason: "Assisted — after 3 accepted jobs (1 of 3)" },
            { id: "autopilot", label: "Autopilot", locked: false },
          ]}
        />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-4">
        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList>
            <TabsTrigger value="available">Available ({available.length})</TabsTrigger>
            <TabsTrigger value="active">Active ({active.length})</TabsTrigger>
            <TabsTrigger value="history">History ({history.length})</TabsTrigger>
          </TabsList>
        </Tabs>

        {tab === "available" && (
          <div className="flex items-center gap-4">
            <Select value={skillFilter} onValueChange={(v) => setSkillFilter(v ?? "all")}>
              <SelectTrigger className="h-8 w-40 text-sm">
                <SelectValue placeholder="Skill" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All skills</SelectItem>
                {skills.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2">
              <Checkbox id="challenges" checked={challengesOnly} onCheckedChange={(v) => setChallengesOnly(!!v)} />
              <Label htmlFor="challenges" className="text-sm font-normal text-muted-foreground">
                Challenges
              </Label>
            </div>
          </div>
        )}
      </div>

      {tab === "available" && (
        <div className="space-y-6">
          <div>
            <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Open to FIXER-7 · sorted by expected net
            </h2>
            <div className="space-y-2">
              {filteredAvailable.map((j) => (
                <JobRow key={j.id} job={j} onOpen={() => setSelectedJob(j)} />
              ))}
            </div>
          </div>

          <div>
            <h2 className="mb-2 flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Locked · {locked.length} jobs · {money(lockedTotal, 0)}
            </h2>
            <div className="space-y-2">
              {locked.map((j) => (
                <LockedJobRow key={j.id} job={j} />
              ))}
            </div>
          </div>
        </div>
      )}

      {tab === "active" && (
        <div className="space-y-3">
          {active.length === 0 && <p className="text-sm text-muted-foreground">No active attempts right now.</p>}
          {active.map((j) => (
            <Card key={j.id} className="p-4">
              <div className="flex items-baseline justify-between gap-2 text-sm">
                <span className="font-medium">{j.title}</span>
                <span className="font-mono text-xs text-muted-foreground">
                  {j.elapsedMinutes}m · {money(j.computeSpent ?? 0, 2)}
                </span>
              </div>
              <div className="mt-3">
                <MilestoneStepper activeIndex={j.milestoneIndex ?? 0} />
              </div>
            </Card>
          ))}
        </div>
      )}

      {tab === "history" && (
        <div className="space-y-2">
          {history.length === 0 && <p className="text-sm text-muted-foreground">No completed jobs yet.</p>}
          {history.map((j) => (
            <a key={j.id} href={`/app/work/${j.id}`} className="flex items-center justify-between gap-4 rounded-md border border-border p-3 hover:bg-muted/60">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{j.title}</p>
                <p className="text-xs text-muted-foreground">
                  {j.skill} · {j.difficulty}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-3">
                {j.result === "picked" && <Badge className="bg-success text-success-foreground">Picked</Badge>}
                {j.result === "passed" && <Badge variant="outline">Passed</Badge>}
                {j.result === "failed" && <Badge variant="destructive">Failed</Badge>}
                <span className="font-mono text-sm">{money(j.price, 0)}</span>
              </div>
            </a>
          ))}
        </div>
      )}

      <JobDrawer job={selectedJob} open={!!selectedJob} onOpenChange={(open) => !open && setSelectedJob(null)} />
      <AutopilotSheet open={autopilotOpen} onOpenChange={setAutopilotOpen} />
    </div>
  )
}
