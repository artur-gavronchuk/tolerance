"use client"

import { useCurrentHomeState } from "@/lib/preview-state"
import { getAccessPanel, getMoneyPanel, NOW_ACTIONS } from "@/lib/home-panel-data"
import { NowCard } from "@/components/home/now-card"
import { InFlight } from "@/components/home/in-flight"
import { ContextBlock } from "@/components/home/context-block"
import { EventFeed } from "@/components/home/event-feed"
import { AccessPanel } from "@/components/home/access-panel"
import { MoneyPanel } from "@/components/home/money-panel"

export default function OwnerHomePage() {
  const state = useCurrentHomeState()
  const action = NOW_ACTIONS[state.id] ?? { primaryHref: "/app" }
  const accessData = getAccessPanel(state.id)
  const moneyData = getMoneyPanel(state.id)

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="space-y-6 lg:col-span-2">
        <NowCard state={state} action={action} />
        {state.context.inFlight && <InFlight rows={state.context.inFlight} />}
        <ContextBlock context={state.context} />
        {state.context.events && <EventFeed events={state.context.events} />}
      </div>
      <div className="space-y-6">
        <AccessPanel data={accessData} />
        <MoneyPanel data={moneyData} />
      </div>
    </div>
  )
}
