import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { getAgentVersions } from "@/lib/mock"

const STATUS_LABEL: Record<string, string> = {
  production: "Production",
  staging: "Staging",
  retired: "Retired",
}

export default function VersionsPage() {
  const versions = getAgentVersions("fixer-7").sort((a, b) => b.label.localeCompare(a.label))
  const v19 = versions.find((v) => v.label === "v19")
  const v18 = versions.find((v) => v.label === "v18")

  return (
    <div className="space-y-8">
      <h1 className="text-xl font-semibold">Versions</h1>

      <div className="space-y-3">
        {versions.map((v) => (
          <Card key={v.id} className="p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-semibold">{v.label}</span>
                <Badge variant={v.status === "production" ? "default" : "outline"} className={v.status === "production" ? "bg-primary text-primary-foreground" : ""}>
                  {STATUS_LABEL[v.status]}
                </Badge>
                {v.changeClass && (
                  <Badge variant="outline" className="capitalize">
                    {v.changeClass}
                  </Badge>
                )}
              </div>
              <span className="text-xs text-muted-foreground">Deployed {v.deployedDate}</span>
            </div>
            <dl className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
              <div>
                <dt className="text-muted-foreground">Model</dt>
                <dd className="font-mono">{v.model}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Tools</dt>
                <dd className="font-mono">{v.tools.join(", ")}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Prompts hash</dt>
                <dd className="font-mono">{v.promptsHash}</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Jobs on version</dt>
                <dd className="font-mono">{v.jobsOnVersion}</dd>
              </div>
            </dl>
            {v.status === "staging" && (
              <p className="mt-3 text-sm text-warning">Major change: access limited one tier below until 3 recalibration proofs</p>
            )}
          </Card>
        ))}
      </div>

      {v19 && v18 && (
        <div>
          <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">v19 vs v18</h2>
          <Card className="overflow-hidden p-0">
            <table className="w-full text-sm">
              <thead className="border-b border-border text-xs text-muted-foreground">
                <tr>
                  <th className="px-4 py-2 text-left font-medium">Metric</th>
                  <th className="px-4 py-2 text-right font-medium">v18</th>
                  <th className="px-4 py-2 text-right font-medium">v19</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                <tr>
                  <td className="px-4 py-3">Go Backend rating</td>
                  <td className="px-4 py-3 text-right font-mono">1887</td>
                  <td className="px-4 py-3 text-right font-mono">1904 (+17, 4 proofs)</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">Pass rate</td>
                  <td className="px-4 py-3 text-right font-mono">83%</td>
                  <td className="px-4 py-3 text-right font-mono">88%</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">Avg compute</td>
                  <td className="px-4 py-3 text-right font-mono">$0.92</td>
                  <td className="px-4 py-3 text-right font-mono">$1.31 (+42%)</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">Avg time</td>
                  <td className="px-4 py-3 text-right font-mono">14m</td>
                  <td className="px-4 py-3 text-right font-mono">11m</td>
                </tr>
                <tr>
                  <td className="px-4 py-3">Est. net/job</td>
                  <td className="px-4 py-3 text-right font-mono">$38</td>
                  <td className="px-4 py-3 text-right font-mono">$41</td>
                </tr>
              </tbody>
            </table>
          </Card>
          <div className="mt-4 flex gap-3">
            <Button>Promote v19</Button>
            <Button variant="outline">Keep v18</Button>
          </div>
        </div>
      )}

      <div>
        <h2 className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">Runtime health</h2>
        <Card className="grid grid-cols-3 gap-4 p-4 text-sm">
          <div>
            <p className="text-muted-foreground">Heartbeat</p>
            <p className="mt-1 font-mono">2s ago</p>
          </div>
          <div>
            <p className="text-muted-foreground">Latency</p>
            <p className="mt-1 font-mono">340ms</p>
          </div>
          <div>
            <p className="text-muted-foreground">Last error</p>
            <p className="mt-1 font-mono">None in 7 days</p>
          </div>
        </Card>
      </div>
    </div>
  )
}
