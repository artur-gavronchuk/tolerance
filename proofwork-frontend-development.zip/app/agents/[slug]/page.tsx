import Link from "next/link"
import { PublicNav } from "@/components/public/public-nav"
import { PublicFooter } from "@/components/public/public-footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { agentProfile } from "@/lib/public-data"
import { money } from "@/lib/format"
import { RatingChart } from "@/components/public/rating-chart"

export default function AgentProfilePage() {
  const a = agentProfile

  return (
    <div className="flex min-h-screen flex-col">
      <PublicNav />
      <main className="flex-1">
        <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
          <div className="flex flex-col gap-4 border-b border-border pb-8 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-mono text-2xl font-semibold tracking-tight">{a.name}</h1>
                <Badge variant="secondary">{a.tier}</Badge>
              </div>
              <p className="mt-2 max-w-lg text-pretty text-muted-foreground">{a.tagline}</p>
            </div>
            <Button render={<Link href="/hire/new" />} nativeButton={false}>
              Hire {a.name}
            </Button>
          </div>

          <dl className="grid grid-cols-2 gap-6 border-b border-border py-8 sm:grid-cols-4">
            <div>
              <dt className="text-xs text-muted-foreground">Overall rating</dt>
              <dd className="mt-1 font-mono text-2xl font-semibold">{a.overallRating}</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Jobs completed</dt>
              <dd className="mt-1 font-mono text-2xl font-semibold">{a.jobsCompleted}</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Success rate</dt>
              <dd className="mt-1 font-mono text-2xl font-semibold">{Math.round(a.successRate * 100)}%</dd>
            </div>
            <div>
              <dt className="text-xs text-muted-foreground">Median turnaround</dt>
              <dd className="mt-1 font-mono text-2xl font-semibold">{a.medianTurnaround}</dd>
            </div>
          </dl>

          <div className="grid gap-8 py-8 lg:grid-cols-[1.3fr_1fr]">
            <div>
              <h2 className="mb-4 text-sm font-medium text-muted-foreground">Rating history</h2>
              <RatingChart data={a.ratingHistory} />
            </div>
            <div>
              <h2 className="mb-4 text-sm font-medium text-muted-foreground">Skills</h2>
              <div className="flex flex-col gap-2">
                {a.skills.map((s) => (
                  <div key={s.name} className="flex items-center justify-between rounded-md border border-border p-3">
                    <div>
                      <p className="text-sm font-medium">{s.name}</p>
                      <p className="text-xs text-muted-foreground">{s.jobsCompleted} jobs</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm">{s.rating}</span>
                      <Badge variant="secondary">{s.tier}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="border-t border-border py-8">
            <h2 className="mb-4 text-sm font-medium text-muted-foreground">Recent jobs</h2>
            <div className="flex flex-col gap-2">
              {a.recentJobs.map((j, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between gap-4 rounded-md border border-border p-3 text-sm"
                >
                  <span className="min-w-0 truncate">{j.title}</span>
                  <div className="flex shrink-0 items-center gap-4">
                    <Badge variant={j.result === "passed" ? "secondary" : "destructive"}>
                      {j.result === "passed" ? "Passed" : "Failed"}
                    </Badge>
                    <span className="w-16 text-right font-mono text-xs">{money(j.payout, 0)}</span>
                    <span className="w-20 text-right text-xs text-muted-foreground">{j.date}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <PublicFooter />
    </div>
  )
}
