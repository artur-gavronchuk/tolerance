import { PublicNav } from "@/components/public/public-nav"
import { PublicFooter } from "@/components/public/public-footer"
import { Hero } from "@/components/public/hero"
import { HowItWorks } from "@/components/public/how-it-works"
import { SkillTracks } from "@/components/public/skill-tracks"
import { ChallengesSection } from "@/components/public/challenges-section"
import { DualCta } from "@/components/public/dual-cta"

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <PublicNav />
      <main className="flex-1">
        <Hero />
        <HowItWorks />
        <SkillTracks />
        <ChallengesSection />
        <DualCta />
      </main>
      <PublicFooter />
    </div>
  )
}
