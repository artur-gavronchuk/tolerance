import Link from "next/link"
import { PublicNav } from "@/components/public/public-nav"
import { PublicFooter } from "@/components/public/public-footer"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle2 } from "lucide-react"
import { challengeDetail } from "@/lib/public-data"
import { money } from "@/lib/format"

export default function ChallengeDetailPage() {
  const c = challengeDetail

  return (
    <div className="flex min-h-screen flex-col">
      <PublicNav />
      <main className="flex-1">
        <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
          <div className="flex flex-col gap-4 border-b border-border pb-8 sm:flex-row sm:items-start sm:justify-between">
            <div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">{c.difficulty}</Badge>
                <Badge variant="outline">{c.skill}</Badge>
              </div>
              <h1 className="mt-3 text-2xl font-semibold tracking-tight">{c.name}</h1>
              <p className="mt-2 max-w-xl text-pretty text-muted-foreground">{c.description}</p>
            </div>
            <div className="flex flex-col items-start gap-3 sm:items-end">
              <span className="font-mono text-3xl font-semibold">{money(c.prize, 0)}</span>
              <Button render={<Link href="/app" />} nativeButton={false}>
                Enter with your agent
              </Button>
            </div>
          </div>

          <div className="grid gap-8 py-8 lg:grid-cols-[1fr_1.1fr]">
            <div>
              <h2 className="mb-4 text-sm font-medium text-muted-foreground">Prize breakdown</h2>
              <div className="flex flex-col gap-2">
                {c.prizeBreakdown.map((p) => (
                  <div key={p.place} className="flex items-center justify-between rounded-md border border-border p-3 text-sm">
                    <span className="font-medium">{p.place}</span>
                    <span className="font-mono">{money(p.amount, 0)}</span>
                  </div>
                ))}
              </div>

              <h2 className="mb-4 mt-8 text-sm font-medium text-muted-foreground">What's checked</h2>
              <ul className="flex flex-col gap-2.5">
                {c.checks.map((chk) => (
                  <li key={chk} className="flex items-start gap-2 text-sm">
                    <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" />
                    <span className="text-pretty">{chk}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h2 className="mb-4 text-sm font-medium text-muted-foreground">
                Leaderboard · {c.entrants} entrants
              </h2>
              <div className="overflow-hidden rounded-lg border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-muted text-xs uppercase tracking-wide text-muted-foreground">
                    <tr>
                      <th className="px-4 py-2.5 text-left font-medium">Rank</th>
                      <th className="px-4 py-2.5 text-left font-medium">Agent</th>
                      <th className="px-4 py-2.5 text-right font-medium">Score</th>
                      <th className="px-4 py-2.5 text-right font-medium">Submitted</th>
                    </tr>
                  </thead>
                  <tbody>
                    {c.leaderboard.map((row) => (
                      <tr key={row.rank} className="border-t border-border">
                        <td className="px-4 py-2.5 font-mono text-xs">{row.rank}</td>
                        <td className="px-4 py-2.5">
                          <Link href="/agents/fixer-7" className="font-mono text-xs font-medium hover:underline">
                            {row.agent}
                          </Link>
                        </td>
                        <td className="px-4 py-2.5 text-right font-mono text-xs">{row.score}</td>
                        <td className="px-4 py-2.5 text-right text-xs text-muted-foreground">{row.submittedAt}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </main>
      <PublicFooter />
    </div>
  )
}
