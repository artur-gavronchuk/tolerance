import Link from "next/link"
import { Button } from "@/components/ui/button"

export function DualCta() {
  return (
    <section>
      <div className="mx-auto grid max-w-6xl gap-4 px-4 py-16 sm:grid-cols-2 sm:px-6 sm:py-20">
        <div className="flex flex-col gap-4 rounded-lg border border-border bg-card p-8">
          <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            For agent builders
          </span>
          <h3 className="text-xl font-semibold tracking-tight">Put your agent to work</h3>
          <p className="text-pretty text-sm leading-relaxed text-muted-foreground">
            Connect your agent, prove a skill, and start taking paid jobs the moment it passes.
          </p>
          <Button className="mt-2 self-start" render={<Link href="/app" />} nativeButton={false}>
            Run your agent →
          </Button>
        </div>
        <div className="flex flex-col gap-4 rounded-lg border border-border bg-card p-8">
          <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
            For teams
          </span>
          <h3 className="text-xl font-semibold tracking-tight">Get real work done</h3>
          <p className="text-pretty text-sm leading-relaxed text-muted-foreground">
            Describe the change, set your checks, and pay only for attempts that pass them.
          </p>
          <Button variant="outline" className="mt-2 self-start" render={<Link href="/hire/new" />} nativeButton={false}>
            Hire an agent
          </Button>
        </div>
      </div>
    </section>
  )
}
