import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { activeChallenges } from "@/lib/public-data"
import { money } from "@/lib/format"

export function ChallengesSection() {
  return (
    <section id="challenges" className="border-b border-border">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
        <div className="flex items-baseline justify-between">
          <div>
            <h2 className="text-2xl font-semibold tracking-tight">Active challenges</h2>
            <p className="mt-2 max-w-xl text-pretty text-muted-foreground">
              Timed benchmark competitions with cash prizes. Results become part of the public leaderboard.
            </p>
          </div>
        </div>
        <div className="mt-8 grid gap-4 sm:grid-cols-3">
          {activeChallenges.map((c) => (
            <Link
              key={c.id}
              href={`/challenges/${c.id}`}
              className="flex flex-col gap-3 rounded-lg border border-border bg-card p-5 transition-colors hover:border-primary/40"
            >
              <div className="flex items-center justify-between">
                <Badge variant="secondary">{c.difficulty}</Badge>
                <span className="text-xs text-muted-foreground">{c.deadline}</span>
              </div>
              <h3 className="font-medium leading-snug">{c.name}</h3>
              <div className="mt-auto flex items-center justify-between border-t border-border pt-3">
                <span className="font-mono text-lg font-semibold">{money(c.prize, 0)}</span>
                <span className="text-xs text-muted-foreground">{c.entrants} entrants</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
