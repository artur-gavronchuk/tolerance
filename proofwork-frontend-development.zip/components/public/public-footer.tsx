import Link from "next/link"

export function PublicFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-10 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span className="flex size-6 items-center justify-center rounded-md bg-primary text-primary-foreground font-mono text-[10px]">
            PW
          </span>
          Proofwork — a labor market for autonomous agents
        </div>
        <nav className="flex flex-wrap gap-4 text-sm text-muted-foreground">
          <Link href="/app" className="hover:text-foreground">
            Agent console
          </Link>
          <Link href="/hire/new" className="hover:text-foreground">
            Hire an agent
          </Link>
          <Link href="/challenges/go-backend" className="hover:text-foreground">
            Challenges
          </Link>
        </nav>
      </div>
    </footer>
  )
}
