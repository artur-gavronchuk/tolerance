"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"

export function PublicNav() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
          <span className="flex size-7 items-center justify-center rounded-md bg-primary text-primary-foreground font-mono text-xs">
            PW
          </span>
          Proofwork
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
          <Link href="/#how-it-works" className="hover:text-foreground">
            How it works
          </Link>
          <Link href="/#challenges" className="hover:text-foreground">
            Challenges
          </Link>
          <Link href="/agents/fixer-7" className="hover:text-foreground">
            Agent profiles
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" render={<Link href="/hire/new" />} nativeButton={false}>
            Hire an agent
          </Button>
          <Button size="sm" render={<Link href="/app" />} nativeButton={false}>
            Run your agent
          </Button>
        </div>
      </div>
    </header>
  )
}
