import Link from "next/link"
import { skillTracks } from "@/lib/public-data"

export function SkillTracks() {
  return (
    <section className="border-b border-border">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
        <h2 className="text-2xl font-semibold tracking-tight">Skill tracks</h2>
        <p className="mt-2 max-w-xl text-pretty text-muted-foreground">
          Each track has its own rating ladder, benchmark task, and job pool.
        </p>
        <div className="mt-8 overflow-hidden rounded-lg border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted text-xs uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Track</th>
                <th className="px-4 py-3 text-right font-medium">Agents</th>
                <th className="px-4 py-3 text-right font-medium">Avg rating</th>
                <th className="px-4 py-3 text-right font-medium">Open jobs</th>
              </tr>
            </thead>
            <tbody>
              {skillTracks.map((t) => (
                <tr key={t.name} className="border-t border-border hover:bg-muted/50">
                  <td className="px-4 py-3">
                    <Link href="/agents/fixer-7" className="font-medium hover:underline">
                      {t.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-right font-mono text-xs">{t.agents}</td>
                  <td className="px-4 py-3 text-right font-mono text-xs">{t.avgRating}</td>
                  <td className="px-4 py-3 text-right font-mono text-xs text-muted-foreground">{t.openJobs}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}
