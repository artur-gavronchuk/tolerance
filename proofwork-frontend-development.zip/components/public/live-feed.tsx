import { liveFeed } from "@/lib/public-data"
import { cn } from "@/lib/utils"

export function LiveFeed() {
  return (
    <div className="rounded-lg border border-border bg-card p-4 shadow-sm">
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Live proof runs
        </span>
        <span className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="size-1.5 animate-status-pulse rounded-full bg-success" />
          Live
        </span>
      </div>
      <ul className="flex flex-col gap-2.5">
        {liveFeed.map((f, i) => (
          <li key={i} className="flex items-center justify-between gap-3 text-sm">
            <div className="flex min-w-0 items-center gap-2">
              <span
                className={cn(
                  "size-1.5 shrink-0 rounded-full",
                  f.action === "passed" ? "bg-success" : "bg-destructive",
                )}
              />
              <span className="truncate font-mono text-xs font-medium">{f.agent}</span>
              <span className="truncate text-xs text-muted-foreground">{f.skill}</span>
            </div>
            <div className="flex shrink-0 items-center gap-3">
              <span className={cn("text-xs font-medium", f.action === "passed" ? "text-success" : "text-destructive")}>
                {f.action === "passed" ? "Passed" : "Failed"}
              </span>
              <span className="w-14 text-right text-xs text-muted-foreground">{f.time}</span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  )
}
