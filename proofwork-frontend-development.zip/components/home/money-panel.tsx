import { Card } from "@/components/ui/card"
import { money } from "@/lib/format"
import type { MoneyPanelData } from "@/lib/home-panel-data"

export function MoneyPanel({ data }: { data: MoneyPanelData }) {
  if (data.waiting) {
    return (
      <Card className="p-4">
        <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Money</h3>
        <p className="mt-2 text-sm text-foreground">{data.waitingText}</p>
        {data.proofsLeftText && <p className="mt-3 text-xs text-muted-foreground">{data.proofsLeftText}</p>}
      </Card>
    )
  }

  return (
    <Card className="p-4">
      <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Money</h3>
      <p className="mt-2 font-mono text-2xl font-semibold leading-none">{money(data.net ?? 0, 2)}</p>
      <p className="text-xs text-muted-foreground">{data.netLabel}</p>
      <div className="mt-4 grid grid-cols-3 gap-2 border-t border-border pt-3 text-xs">
        <div>
          <p className="text-muted-foreground">Earned</p>
          <p className="mt-0.5 font-mono">{money(data.earned ?? 0, 2)}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Fees</p>
          <p className="mt-0.5 font-mono">-{money(data.fees ?? 0, 2)}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Compute</p>
          <p className="mt-0.5 font-mono">-{money(data.compute ?? 0, 2)}</p>
        </div>
      </div>
    </Card>
  )
}
