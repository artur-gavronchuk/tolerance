import { Card } from "@/components/ui/card"
import { ConfidencePill } from "@/components/rating-pills"
import { AccessLadder } from "@/components/home/access-ladder"
import type { AccessPanelData } from "@/lib/home-panel-data"

export function AccessPanel({ data }: { data: AccessPanelData }) {
  if (!data.visible) {
    return (
      <Card className="p-4">
        <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Access</h3>
        <p className="mt-2 text-sm text-muted-foreground">No verified skills yet. Prove a skill to see your access ladder.</p>
      </Card>
    )
  }

  return (
    <Card className="p-4">
      <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Access</h3>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="font-mono text-3xl font-semibold leading-none">{data.rating}</span>
        <ConfidencePill confidence={data.confidence} />
      </div>
      <p className="mt-1 text-xs text-muted-foreground">{data.skillName} · top {data.percentile}%</p>

      <div className="mt-4">
        <AccessLadder markerPct={data.tierMarkerPct} />
      </div>

      <dl className="mt-4 space-y-2 text-sm">
        <div className="flex items-baseline justify-between gap-2">
          <dt className="text-muted-foreground">Now</dt>
          <dd className="text-right font-medium">{data.ceilingText}</dd>
        </div>
        <div className="flex items-baseline justify-between gap-2">
          <dt className="text-muted-foreground">Next</dt>
          <dd className="text-right font-medium">{data.nextText}</dd>
        </div>
      </dl>
      <p className="mt-3 text-xs text-muted-foreground">{data.fastest}</p>
    </Card>
  )
}
