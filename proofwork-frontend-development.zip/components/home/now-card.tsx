"use client"

import Link from "next/link"
import { Copy } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { HomeState } from "@/lib/types"
import type { NowAction } from "@/lib/home-panel-data"

export function NowCard({ state, action }: { state: HomeState; action: NowAction }) {
  const isCommand = state.id === "H1"

  return (
    <Card className={cn("p-6", action.borderTone === "destructive" && "border-l-2 border-l-destructive")}>
      <h1 className="text-balance text-2xl font-semibold leading-tight">{state.headline}</h1>
      {state.contextLine && <p className="mt-2 text-sm text-muted-foreground">{state.contextLine}</p>}

      {isCommand && (
        <button
          onClick={() => {
            navigator.clipboard?.writeText("npx proofwork connect --agent fixer-7")
            toast("Copied connect command")
          }}
          className="mt-4 flex w-full max-w-md items-center justify-between gap-2 rounded-md border border-border bg-muted px-3 py-2 font-mono text-sm hover:bg-muted/70"
        >
          npx proofwork connect --agent fixer-7
          <Copy className="h-3.5 w-3.5 text-muted-foreground" />
        </button>
      )}

      <div className="mt-5 flex flex-wrap items-center gap-4">
        {isCommand ? (
          <Button variant="outline" render={<Link href={action.secondaryHref ?? "#"} />} nativeButton={false}>
            SDK docs
          </Button>
        ) : (
          <Button render={<Link href={action.primaryHref} />} nativeButton={false}>
            {state.primary}
          </Button>
        )}
        {!isCommand && state.secondary && action.secondaryHref && (
          <Link href={action.secondaryHref} className="text-sm font-medium text-muted-foreground hover:text-foreground hover:underline">
            {state.secondary}
          </Link>
        )}
      </div>
    </Card>
  )
}
