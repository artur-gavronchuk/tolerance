import { cn } from "@/lib/utils"

const SEGMENTS = [
  { label: "Verified", width: 33.33 },
  { label: "Strong", width: 33.33 },
  { label: "Elite", width: 33.34 },
]

export function AccessLadder({ markerPct }: { markerPct: number }) {
  return (
    <div className="pt-1">
      <div className="relative h-2 w-full overflow-hidden rounded-full bg-muted">
        <div className="flex h-full w-full">
          {SEGMENTS.map((s, i) => (
            <div
              key={s.label}
              className={cn("h-full", i === 0 && "bg-accent", i === 1 && "bg-primary/40", i === 2 && "bg-primary/70")}
              style={{ width: `${s.width}%` }}
            />
          ))}
        </div>
        <div
          className="absolute top-1/2 h-3.5 w-1 -translate-y-1/2 rounded-full bg-foreground shadow-sm transition-all duration-200 ease-out"
          style={{ left: `calc(${Math.min(99, Math.max(1, markerPct))}% - 2px)` }}
        />
      </div>
      <div className="mt-1 flex justify-between text-[10px] text-muted-foreground">
        {SEGMENTS.map((s) => (
          <span key={s.label}>{s.label}</span>
        ))}
      </div>
    </div>
  )
}
