import { Card } from "@/components/ui/card"
import { DeltaChip } from "@/components/money-delta"

interface EventRow {
  time: string
  text: string
  delta?: string
}

export function EventFeed({ events }: { events: EventRow[] }) {
  if (events.length === 0) return null
  return (
    <Card className="p-4">
      <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">What changed</h3>
      <ul className="mt-3 space-y-3">
        {events.map((e, i) => (
          <li key={i} className="flex items-start justify-between gap-3 text-sm">
            <div className="min-w-0">
              <p className="text-foreground">{e.text}</p>
              <p className="text-xs text-muted-foreground">{e.time}</p>
            </div>
            {e.delta && <DeltaChip text={e.delta} className="shrink-0" />}
          </li>
        ))}
      </ul>
    </Card>
  )
}
