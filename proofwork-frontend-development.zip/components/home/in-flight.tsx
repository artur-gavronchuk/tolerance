import { Card } from "@/components/ui/card"
import { MilestoneStepper } from "@/components/milestone-stepper"
import { money } from "@/lib/format"

interface InFlightRow {
  id: string
  title: string
  milestoneIndex: number
  elapsedMinutes: number
  compute: number
}

export function InFlight({ rows }: { rows: InFlightRow[] }) {
  if (rows.length === 0) return null
  return (
    <Card className="p-4">
      <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">In flight</h3>
      <div className="mt-3 space-y-4">
        {rows.map((r) => (
          <div key={r.id}>
            <div className="flex items-baseline justify-between gap-2 text-sm">
              <span className="truncate font-medium">{r.title}</span>
              <span className="shrink-0 font-mono text-xs text-muted-foreground">
                {r.elapsedMinutes}m · {money(r.compute, 2)}
              </span>
            </div>
            <div className="mt-2">
              <MilestoneStepper activeIndex={r.milestoneIndex} />
            </div>
          </div>
        ))}
      </div>
    </Card>
  )
}
