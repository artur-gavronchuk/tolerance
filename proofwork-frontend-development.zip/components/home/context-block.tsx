import Link from "next/link"
import { Check, Loader2 } from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { money } from "@/lib/format"
import type { HomeStateContext } from "@/lib/types"

export function ContextBlock({ context }: { context: HomeStateContext }) {
  if (context.checklist) {
    return (
      <Card className="p-4">
        <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Runtime checks</h3>
        <ul className="mt-3 space-y-2.5">
          {context.checklist.map((c) => (
            <li key={c.label} className="flex items-center gap-2.5 text-sm">
              {c.done ? (
                <span className="flex h-4 w-4 items-center justify-center rounded-full bg-success text-success-foreground">
                  <Check className="h-2.5 w-2.5" strokeWidth={3} />
                </span>
              ) : (
                <span className="flex h-4 w-4 items-center justify-center rounded-full border border-border">
                  <Loader2 className="h-2.5 w-2.5 animate-spin text-muted-foreground" />
                </span>
              )}
              <span className={c.done ? "text-foreground" : "text-muted-foreground"}>{c.label}</span>
            </li>
          ))}
        </ul>
      </Card>
    )
  }

  if (context.bestFirstJobs) {
    return (
      <Card className="p-4">
        <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Best first jobs</h3>
        <div className="mt-3 space-y-2">
          {context.bestFirstJobs.map((j) => (
            <div key={j.id} className="flex items-center justify-between gap-3 rounded-md border border-border p-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{j.title}</p>
                <p className="font-mono text-xs text-muted-foreground">Expected net ≈ {money(j.expectedNet, 2)} · {money(j.price, 0)} job</p>
              </div>
              <Button size="sm" variant="outline" render={<Link href="/app/work" />} nativeButton={false}>
                Take
              </Button>
            </div>
          ))}
        </div>
      </Card>
    )
  }

  if (context.backtest) {
    const b = context.backtest
    return (
      <Card className="p-4">
        <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Backtest</h3>
        <p className="mt-2 text-sm text-foreground">
          With these rules FIXER-7 would have taken {b.taken} of {b.total} jobs: {b.accepted} accepted · {b.picked} picked · est. net {money(b.netEst, 0)} · peak daily
          compute {money(b.peakCompute, 0)}
        </p>
      </Card>
    )
  }

  if (context.away) {
    const a = context.away
    return (
      <Card className="p-4">
        <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          While you were away · {a.from} → {a.to}
        </h3>
        <p className="mt-2 text-sm">
          FIXER-7 earned <span className="font-mono font-medium">{money(a.net, 2)}</span> net
        </p>
        <dl className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
          <div>
            <dt className="text-muted-foreground">Earned</dt>
            <dd className="font-mono">{money(a.earned, 2)}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Fees</dt>
            <dd className="font-mono">-{money(a.fees, 2)}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Compute</dt>
            <dd className="font-mono">-{money(a.compute, 2)}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Net</dt>
            <dd className="font-mono">{money(a.net, 2)}</dd>
          </div>
        </dl>
        <p className="mt-3 text-sm text-muted-foreground">
          {a.attempts} attempts · {a.accepted} accepted · {a.picked} picked · {a.incidents} incidents
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Go Backend {a.ratingFrom} → {a.ratingTo}
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Skipped {a.skipped} jobs ({a.skippedBelow} below $80 minimum, {a.skippedExcluded} excluded types)
        </p>
      </Card>
    )
  }

  return null
}
