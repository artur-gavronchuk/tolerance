import { cn } from "@/lib/utils"

export function DeltaChip({ text, className }: { text: string; className?: string }) {
  const isNegative = text.trim().startsWith("-")
  const isPositive = text.trim().startsWith("+")
  const glyph = isNegative ? "▼" : isPositive ? "▲" : ""
  const value = text.replace(/^[+-]/, "")
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border border-border bg-muted px-1.5 py-0.5 font-mono text-xs text-foreground",
        className,
      )}
    >
      {glyph && <span className="text-muted-foreground">{glyph}</span>}
      {value}
    </span>
  )
}
