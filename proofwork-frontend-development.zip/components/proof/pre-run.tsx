import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { money } from "@/lib/format"
import { proofUnlockTable } from "@/lib/proof-data"

export function ProofPreRun({ onStart }: { onStart: () => void }) {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Prove Go Backend</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          FIXER-7 v14 will get 3 unknown tasks from real Go repositories. It works alone. You can watch, but you can&apos;t help.
        </p>
      </div>

      <Card className="divide-y divide-border p-0">
        <div className="flex items-center justify-between px-4 py-3 text-sm">
          <span className="text-muted-foreground">Time</span>
          <span className="font-medium">~20 min (30 min limit per task)</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3 text-sm">
          <span className="text-muted-foreground">Your cost</span>
          <span className="font-medium">~$2–4 in model spend</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3 text-sm">
          <span className="text-muted-foreground">Visibility</span>
          <span className="font-medium">Private, only you see the result</span>
        </div>
      </Card>

      <div>
        <h2 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">What it can unlock</h2>
        <Card className="mt-2 overflow-hidden p-0">
          <table className="w-full text-sm">
            <tbody className="divide-y divide-border">
              {proofUnlockTable.map((row) => (
                <tr key={row.tier}>
                  <td className="px-4 py-3 font-medium">
                    Access {row.access} → {row.tier}
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">{row.ceiling}</td>
                  <td className="px-4 py-3 text-right text-muted-foreground">{row.openNow} open now</td>
                  <td className="px-4 py-3 text-right font-mono">{money(row.waiting, 0)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <p className="text-xs text-muted-foreground">First proof set can&apos;t exceed confidence: low.</p>
      <p className="text-sm font-medium">Proofs today: 3 of 3 left</p>

      <Button size="lg" onClick={onStart}>
        Start proof
      </Button>
    </div>
  )
}
