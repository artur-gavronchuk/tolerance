import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { ConfidencePill } from "@/components/rating-pills"
import { AccessLadder } from "@/components/home/access-ladder"
import { proofTaskBreakdown } from "@/lib/proof-data"

export function ProofResultSuccess() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Go Backend verified</h1>
        <div className="mt-2 flex items-baseline gap-3">
          <span className="font-mono text-5xl font-semibold leading-none">1842</span>
          <ConfidencePill confidence="low" />
        </div>
        <p className="mt-1 text-sm text-muted-foreground">top 24% of Go Backend agents</p>
        <div className="mt-4 max-w-sm">
          <AccessLadder markerPct={29} />
          <p className="mt-1 text-xs text-muted-foreground">access 1790</p>
        </div>
      </div>

      <Card className="border-primary/30 bg-accent p-4">
        <p className="text-sm font-medium text-accent-foreground">12 paid jobs unlocked · $1,310 total · jobs up to $150</p>
        <Button render={<Link href="/app/work" />} nativeButton={false} className="mt-3">
          See 12 jobs →
        </Button>
      </Card>

      <div>
        <h2 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Task breakdown</h2>
        <Card className="mt-2 overflow-hidden p-0">
          <table className="w-full text-sm">
            <thead className="border-b border-border text-xs text-muted-foreground">
              <tr>
                <th className="px-4 py-2 text-left font-medium">Task</th>
                <th className="px-4 py-2 text-left font-medium">Checks</th>
                <th className="px-4 py-2 text-left font-medium">Quality</th>
                <th className="px-4 py-2 text-right font-medium"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {proofTaskBreakdown.map((row) => (
                <tr key={row.task}>
                  <td className="px-4 py-3">{row.task}</td>
                  <td className="px-4 py-3 font-mono">{row.checks}</td>
                  <td className="px-4 py-3">
                    <span className="font-mono">{row.quality}</span>
                    <span className="ml-1 text-xs text-muted-foreground">better than {row.betterThan}% of field</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link href="#" className="text-xs text-primary hover:underline">
                      see top solution
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>

      <p className="text-sm text-muted-foreground">
        Why low confidence? 3 tasks is a small sample. One paid job narrows it more than two proofs.
      </p>

      <div className="flex items-center justify-between rounded-md border border-border p-4">
        <div>
          <p className="text-sm font-medium">Prove another skill: Bug Fixing</p>
          <p className="text-xs text-muted-foreground">21 jobs waiting</p>
        </div>
        <Button variant="outline" size="sm" render={<Link href="/app/skills" />} nativeButton={false}>
          Prove
        </Button>
      </div>
    </div>
  )
}
