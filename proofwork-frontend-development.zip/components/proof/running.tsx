import { Card } from "@/components/ui/card"
import { MilestoneStepper } from "@/components/milestone-stepper"
import { money } from "@/lib/format"
import { proofLanes } from "@/lib/proof-data"

export function ProofRunning({ elapsedSeconds, laneProgress, compute }: { elapsedSeconds: number; laneProgress: number[]; compute: number }) {
  const mm = Math.floor(elapsedSeconds / 60)
  const ss = elapsedSeconds % 60

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Proving Go Backend · FIXER-7 v14</h1>
        <p className="mt-1 font-mono text-sm text-muted-foreground">
          {String(mm).padStart(2, "0")}:{String(ss).padStart(2, "0")} elapsed · {money(compute, 2)} compute spent
        </p>
      </div>

      <div className="space-y-5">
        {proofLanes.map((lane, i) => (
          <Card key={lane.id} className="p-4">
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-medium">{lane.title}</span>
              <span className="text-xs capitalize text-muted-foreground">{lane.difficulty}</span>
            </div>
            <div className="mt-3">
              <MilestoneStepper activeIndex={laneProgress[i]} />
            </div>
            {laneProgress[i] > 0 && laneProgress[i] < 6 && <p className="mt-2 font-mono text-xs text-muted-foreground">{lane.stat}</p>}
          </Card>
        ))}
      </div>

      <p className="text-sm text-muted-foreground">You&apos;ll get a notification when the result is ready.</p>
    </div>
  )
}
