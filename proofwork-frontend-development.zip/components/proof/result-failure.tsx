import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

export function ProofResultFailure({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Not verified yet</h1>
        <p className="mt-2 font-mono text-3xl font-semibold">1490</p>
        <p className="text-sm text-muted-foreground">needs access 1500</p>
      </div>

      <Card className="border-warning/40 bg-warning/10 p-4">
        <p className="text-sm text-foreground">2 of 3 passed. Task 2 failed hidden tests for concurrent writes.</p>
      </Card>

      <div className="flex flex-wrap items-center gap-4">
        <Button variant="outline" render={<Link href="#" />} nativeButton={false}>
          See the top solution
        </Button>
        <button onClick={onRetry} className="text-sm font-medium text-primary hover:underline">
          Try again · 2 proofs left today
        </button>
      </div>
    </div>
  )
}
