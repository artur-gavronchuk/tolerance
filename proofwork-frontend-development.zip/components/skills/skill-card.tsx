import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ConfidencePill } from "@/components/rating-pills"
import { AccessLadder } from "@/components/home/access-ladder"
import { toAccessRating, jobCeiling, nextThreshold } from "@/lib/access"
import { money } from "@/lib/format"
import type { SkillRating } from "@/lib/types"

export function SkillCard({ skill, openJobs, waitingAmount }: { skill: SkillRating; openJobs: number; waitingAmount: number }) {
  if (!skill.verified) {
    return (
      <Card className="p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold">{skill.name}</h3>
            <p className="mt-1 text-xs text-muted-foreground">
              Unverified · {openJobs} open jobs · {money(waitingAmount, 0)} waiting
            </p>
          </div>
          <Button size="sm" render={<Link href={`/app/proof/proof-${skill.id}`} />} nativeButton={false}>
            Prove
          </Button>
        </div>
      </Card>
    )
  }

  const accessRating = toAccessRating(skill.rating, skill.confidence)
  const ceiling = jobCeiling(accessRating)
  const next = nextThreshold(accessRating)
  const markerPct = Math.min(100, Math.max(0, ((accessRating - 1500) / (2400 - 1500)) * 100))

  return (
    <Card className="p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="text-sm font-semibold">{skill.name}</h3>
          <div className="mt-1.5 flex items-baseline gap-2">
            <span className="font-mono text-2xl font-semibold leading-none">{skill.rating}</span>
            <ConfidencePill confidence={skill.confidence} />
          </div>
          <p className="mt-1 text-xs text-muted-foreground">top {skill.percentile}%</p>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" render={<Link href={`/app/proof/proof-${skill.id}`} />} nativeButton={false}>
            Prove
          </Button>
          <Button size="sm" render={<Link href="/app/work" />} nativeButton={false}>
            See jobs
          </Button>
        </div>
      </div>

      <div className="mt-4 max-w-md">
        <AccessLadder markerPct={markerPct} />
      </div>

      <dl className="mt-4 space-y-1.5 text-sm">
        <div className="flex items-baseline justify-between gap-2">
          <dt className="text-muted-foreground">Access {accessRating}</dt>
          <dd className="text-right font-medium">
            jobs up to {money(ceiling, 0)} · {openJobs} open now
          </dd>
        </div>
        {next && (
          <div className="flex items-baseline justify-between gap-2">
            <dt className="text-muted-foreground">Next</dt>
            <dd className="text-right font-medium">
              +{next.distance} access → jobs up to {money(next.nextCeiling, 0)}
            </dd>
          </div>
        )}
      </dl>
      <p className="mt-2 text-xs text-muted-foreground">Fastest way: 2 more proofs or 1 paid job</p>
    </Card>
  )
}
