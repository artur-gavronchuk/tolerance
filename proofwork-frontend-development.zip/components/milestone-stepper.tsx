import { Check } from "lucide-react"
import { cn } from "@/lib/utils"
import { MILESTONES } from "@/lib/mock"

export function MilestoneStepper({ activeIndex, compact = false }: { activeIndex: number; compact?: boolean }) {
  return (
    <div className="flex items-center gap-1">
      {MILESTONES.map((label, i) => {
        const done = i < activeIndex
        const active = i === activeIndex
        return (
          <div key={label} className="flex flex-1 items-center gap-1">
            <div className="flex flex-col items-center gap-1">
              <span
                className={cn(
                  "flex h-4 w-4 items-center justify-center rounded-full border text-[10px]",
                  done && "border-success bg-success text-success-foreground",
                  active && "border-primary bg-primary",
                  !done && !active && "border-border bg-background",
                )}
              >
                {done && <Check className="h-2.5 w-2.5" strokeWidth={3} />}
                {active && <span className="h-1.5 w-1.5 rounded-full bg-primary-foreground animate-status-pulse" />}
              </span>
              {!compact && <span className={cn("text-center text-[10px] leading-tight", active ? "text-foreground" : "text-muted-foreground")}>{label}</span>}
            </div>
            {i < MILESTONES.length - 1 && <span className={cn("h-px flex-1", done ? "bg-success" : "bg-border")} />}
          </div>
        )
      })}
    </div>
  )
}
