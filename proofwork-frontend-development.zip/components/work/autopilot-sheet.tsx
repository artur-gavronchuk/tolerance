"use client"

import { useMemo, useState } from "react"
import { toast } from "sonner"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { money } from "@/lib/format"

const SKILL_OPTIONS = ["Go Backend", "Bug Fixing"]
const EXCLUDE_OPTIONS = ["Migrations", "Auth changes", "Infra"]

export function AutopilotSheet({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [skillsOn, setSkillsOn] = useState<Record<string, boolean>>({ "Go Backend": true, "Bug Fixing": false })
  const [minReward, setMinReward] = useState(80)
  const [minExpectedNet, setMinExpectedNet] = useState(25)
  const [repoScope, setRepoScope] = useState("public")
  const [excluded, setExcluded] = useState<Record<string, boolean>>({ Migrations: true, "Auth changes": true, Infra: false })
  const [maxComputePerAttempt, setMaxComputePerAttempt] = useState(6)
  const [dailyBudget, setDailyBudget] = useState(40)
  const [maxConcurrent, setMaxConcurrent] = useState(2)

  const backtest = useMemo(() => {
    const skillFactor = Object.values(skillsOn).filter(Boolean).length || 1
    const rewardFactor = Math.max(0.4, 1 - minReward / 400)
    const netFactor = Math.max(0.4, 1 - minExpectedNet / 100)
    const concurrentFactor = Math.min(1.4, 0.6 + maxConcurrent * 0.25)
    const taken = Math.round(Math.min(31, 5 + skillFactor * 4 * rewardFactor * netFactor * concurrentFactor))
    const accepted = Math.max(1, Math.round(taken * 0.86))
    const picked = Math.max(0, Math.round(accepted * 0.33))
    const netEst = Math.round(accepted * 52 * netFactor + picked * 28)
    const peakCompute = Math.round(Math.min(dailyBudget, maxComputePerAttempt * maxConcurrent * 1.6))
    return { taken, total: 31, accepted, picked, netEst, peakCompute }
  }, [skillsOn, minReward, minExpectedNet, maxConcurrent, dailyBudget, maxComputePerAttempt])

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-[480px]">
        <SheetHeader>
          <SheetTitle>Set up Autopilot</SheetTitle>
        </SheetHeader>

        <div className="space-y-5 px-4 pb-4">
          <Card className="border-primary/30 bg-accent p-4">
            <p className="text-sm text-accent-foreground">
              With these rules FIXER-7 would have taken <span className="font-mono font-medium">{backtest.taken}</span> of {backtest.total} jobs:{" "}
              {backtest.accepted} accepted · {backtest.picked} picked · est. net {money(backtest.netEst, 0)} · peak daily compute {money(backtest.peakCompute, 0)}
            </p>
          </Card>

          <div>
            <Label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Skills</Label>
            <div className="mt-2 space-y-2">
              {SKILL_OPTIONS.map((s) => (
                <div key={s} className="flex items-center gap-2">
                  <Checkbox id={`skill-${s}`} checked={skillsOn[s] ?? false} onCheckedChange={(v) => setSkillsOn((prev) => ({ ...prev, [s]: !!v }))} />
                  <Label htmlFor={`skill-${s}`} className="text-sm font-normal">
                    {s}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="min-reward" className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Min reward
              </Label>
              <Input id="min-reward" type="number" value={minReward} onChange={(e) => setMinReward(Number(e.target.value))} className="mt-1.5 font-mono" />
            </div>
            <div>
              <Label htmlFor="min-net" className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Min expected net
              </Label>
              <Input id="min-net" type="number" value={minExpectedNet} onChange={(e) => setMinExpectedNet(Number(e.target.value))} className="mt-1.5 font-mono" />
            </div>
          </div>

          <div>
            <Label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Repositories</Label>
            <RadioGroup value={repoScope} onValueChange={setRepoScope} className="mt-2 space-y-2">
              <div className="flex items-center gap-2">
                <RadioGroupItem value="public" id="repo-public" />
                <Label htmlFor="repo-public" className="text-sm font-normal">
                  Public only
                </Label>
              </div>
              <div className="flex items-center gap-2">
                <RadioGroupItem value="private" id="repo-private" disabled />
                <Label htmlFor="repo-private" className="text-sm font-normal text-muted-foreground">
                  Include private (requires Elite)
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div>
            <Label className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Exclude</Label>
            <div className="mt-2 space-y-2">
              {EXCLUDE_OPTIONS.map((e) => (
                <div key={e} className="flex items-center gap-2">
                  <Checkbox id={`ex-${e}`} checked={excluded[e] ?? false} onCheckedChange={(v) => setExcluded((prev) => ({ ...prev, [e]: !!v }))} />
                  <Label htmlFor={`ex-${e}`} className="text-sm font-normal">
                    {e}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <Label htmlFor="max-compute" className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Max compute / attempt
              </Label>
              <Input id="max-compute" type="number" value={maxComputePerAttempt} onChange={(e) => setMaxComputePerAttempt(Number(e.target.value))} className="mt-1.5 font-mono" />
            </div>
            <div>
              <Label htmlFor="daily-budget" className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Daily budget
              </Label>
              <Input id="daily-budget" type="number" value={dailyBudget} onChange={(e) => setDailyBudget(Number(e.target.value))} className="mt-1.5 font-mono" />
            </div>
            <div>
              <Label htmlFor="max-concurrent" className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Max concurrent
              </Label>
              <Input id="max-concurrent" type="number" value={maxConcurrent} onChange={(e) => setMaxConcurrent(Number(e.target.value))} className="mt-1.5 font-mono" />
            </div>
          </div>

          <Separator />

          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Always on (can&apos;t be disabled)</p>
            <ul className="mt-2 space-y-1.5 text-sm text-muted-foreground">
              <li>Pause after 2 failed checks in a row</li>
              <li>Pause if today&apos;s net &lt; −$20</li>
              <li>Pause if runtime offline &gt; 10 min</li>
              <li>One tier lower after a version change until recalibrated</li>
            </ul>
          </div>
        </div>

        <SheetFooter className="flex-row gap-2">
          <Button variant="outline" className="flex-1" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button
            className="flex-1"
            onClick={() => {
              toast("Autopilot turned on")
              onOpenChange(false)
            }}
          >
            Turn on Autopilot
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}
