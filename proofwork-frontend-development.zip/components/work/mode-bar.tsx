"use client"

import { Lock } from "lucide-react"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { cn } from "@/lib/utils"
import type { WorkMode } from "@/lib/types"

interface ModeOption {
  id: WorkMode
  label: string
  locked: boolean
  lockReason?: string
}

export function ModeBar({ mode, onSelect, options }: { mode: WorkMode; onSelect: (m: WorkMode) => void; options: ModeOption[] }) {
  return (
    <div className="inline-flex items-center gap-1 rounded-lg border border-border bg-muted p-1">
      {options.map((opt) => {
        const active = opt.id === mode
        const className = cn(
          "flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
          active && !opt.locked && "bg-card text-foreground shadow-sm",
          !active && !opt.locked && "text-muted-foreground hover:text-foreground",
          opt.locked && "cursor-not-allowed text-muted-foreground/60",
        )

        if (opt.locked && opt.lockReason) {
          return (
            <Tooltip key={opt.id}>
              <TooltipTrigger render={<button type="button" className={className} disabled />}>
                <Lock className="h-3 w-3" />
                {opt.label}
              </TooltipTrigger>
              <TooltipContent>{opt.lockReason}</TooltipContent>
            </Tooltip>
          )
        }
        return (
          <button key={opt.id} type="button" onClick={() => onSelect(opt.id)} className={className}>
            {opt.label}
          </button>
        )
      })}
    </div>
  )
}
