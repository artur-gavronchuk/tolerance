import Link from "next/link"
import { Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { money } from "@/lib/format"
import { pct } from "@/lib/format"
import type { JobMeta } from "@/lib/types"

export function JobRow({ job, onOpen }: { job: JobMeta; onOpen: () => void }) {
  return (
    <div
      role="button"
      tabIndex={0}
      onClick={onOpen}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault()
          onOpen()
        }
      }}
      className="flex w-full cursor-pointer flex-col gap-1 rounded-md border border-border p-3 text-left hover:bg-muted/60 sm:flex-row sm:items-center sm:justify-between sm:gap-4"
    >
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          {job.isChallenge && (
            <Badge variant="outline" className="border-primary/40 text-primary">
              CHALLENGE
            </Badge>
          )}
          <span className="truncate text-sm font-medium">{job.title}</span>
        </div>
        <p className="mt-1 truncate text-xs text-muted-foreground">
          {job.skill} · {job.difficulty} · {job.attempts} attempts · {job.repoVisibility} repo
          {job.isChallenge ? ` · ${money(job.poolSize ?? 0, 0)} pool · ${job.fieldSize} agents · closes in ${job.closeInHours}h` : ` · claim within ${Math.floor(job.claimWithinMinutes / 60) > 0 ? `${Math.floor(job.claimWithinMinutes / 60)}h ${job.claimWithinMinutes % 60}m` : `${job.claimWithinMinutes}m`}`}
        </p>
        {!job.isChallenge && (
          <p className="mt-1 font-mono text-xs text-muted-foreground">
            Expected net ≈ {money(job.expectedNet, 0)} · pass {pct(job.passChance)} · pick {pct(job.pickChance)} · compute ~{money(job.compute, 0)}
          </p>
        )}
        {job.isChallenge && <p className="mt-1 text-xs text-muted-foreground">Top-10 finish would likely move you to Strong</p>}
      </div>
      <div className="flex shrink-0 items-center gap-3">
        <span className="font-mono text-sm font-semibold">{money(job.price, 0)}</span>
        <Button size="sm" variant={job.isChallenge ? "outline" : "default"}>
          {job.isChallenge ? "Enter challenge" : "Take attempt"}
        </Button>
      </div>
    </div>
  )
}

export function LockedJobRow({ job }: { job: JobMeta }) {
  const needsProve = job.lockReason?.includes("unverified")
  return (
    <div className="flex flex-col gap-1 rounded-md border border-border/60 bg-muted/30 p-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <Lock className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
          <span className="truncate text-sm font-medium text-muted-foreground">{job.title}</span>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{job.lockReason}</p>
      </div>
      <div className="flex shrink-0 items-center gap-3">
        <span className="font-mono text-sm text-muted-foreground">{money(job.price, 0)}</span>
        {needsProve ? (
          <Button size="sm" variant="outline" render={<Link href="/app/skills" />} nativeButton={false}>
            Prove {job.skill}
          </Button>
        ) : (
          <Button size="sm" variant="outline" disabled>
            Locked
          </Button>
        )}
      </div>
    </div>
  )
}
