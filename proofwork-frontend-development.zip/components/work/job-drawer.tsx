"use client"

import { toast } from "sonner"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetFooter } from "@/components/ui/sheet"
import { Button } from "@/components/ui/button"
import { money } from "@/lib/format"
import { computePayout } from "@/lib/access"
import type { JobMeta } from "@/lib/types"

export function JobDrawer({ job, open, onOpenChange }: { job: JobMeta | null; open: boolean; onOpenChange: (open: boolean) => void }) {
  if (!job) return null

  const bonusPool = job.price * 0.5
  const basePool = job.price * 0.5
  const baseSplit = basePool / job.attempts
  const { payout: pickedPayout } = computePayout(job.price, job.attempts, true)
  const feeRate = 0.1
  const passedNotPicked = baseSplit * (1 - feeRate)
  const picked = pickedPayout * (1 - feeRate)
  const failed = -(job.compute * 0.35)

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-full overflow-y-auto sm:max-w-[440px]">
        <SheetHeader>
          <SheetTitle className="text-balance">{job.title}</SheetTitle>
          <p className="text-sm text-muted-foreground">
            {money(job.price, 0)} job · {job.attempts} attempts · {job.skill} · {job.difficulty}
          </p>
        </SheetHeader>

        <div className="space-y-5 px-4 pb-4">
          <section>
            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Task</h3>
            <p className="mt-1.5 text-sm text-foreground">
              Add {job.skill === "Go Backend" ? "cursor-based" : ""} pagination support with validated query parameters and a documented response envelope. Existing consumers must keep working unchanged.
            </p>
          </section>

          <section>
            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Repo</h3>
            <p className="mt-1.5 font-mono text-sm text-foreground">{job.repo}</p>
          </section>

          <section>
            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Acceptance</h3>
            <p className="mt-1.5 text-sm text-foreground">186 existing tests + 4 new checks</p>
          </section>

          <section>
            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Competing</h3>
            <p className="mt-1.5 text-sm text-foreground">{job.attempts} attempts · Verified tier · different owners</p>
          </section>

          <section>
            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">How the {money(job.price, 0)} is paid</h3>
            <p className="mt-1.5 text-sm text-foreground">
              {money(basePool, 0)} split among passing attempts · {money(bonusPool, 0)} bonus to the picked attempt · −10% fee on your payout
            </p>
          </section>

          <section>
            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Your expected net</h3>
            <table className="mt-2 w-full text-sm">
              <tbody className="divide-y divide-border">
                <tr>
                  <td className="py-1.5 text-muted-foreground">If it passes, not picked</td>
                  <td className="py-1.5 text-right font-mono">{money(passedNotPicked, 0)}</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-muted-foreground">If picked</td>
                  <td className="py-1.5 text-right font-mono">{money(picked, 0)}</td>
                </tr>
                <tr>
                  <td className="py-1.5 text-muted-foreground">If it fails</td>
                  <td className="py-1.5 text-right font-mono">{money(failed, 0)}</td>
                </tr>
                <tr>
                  <td className="py-1.5 font-medium">Expected</td>
                  <td className="py-1.5 text-right font-mono font-medium">≈ {money(job.expectedNet, 0)}</td>
                </tr>
              </tbody>
            </table>
          </section>

          <section>
            <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Deadline & compute cap</h3>
            <p className="mt-1.5 text-sm text-foreground">
              Claim within {job.claimWithinMinutes >= 60 ? `${Math.floor(job.claimWithinMinutes / 60)}h ${job.claimWithinMinutes % 60}m` : `${job.claimWithinMinutes}m`} · max compute ~{money(job.compute * 1.5, 0)}
            </p>
          </section>
        </div>

        <SheetFooter>
          <Button
            className="w-full"
            onClick={() => {
              toast(`Attempt started · ${job.title}`)
              onOpenChange(false)
            }}
          >
            Take attempt
          </Button>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}
