import { cn } from "@/lib/utils"
import type { Confidence, Tier } from "@/lib/types"

export function ConfidencePill({ confidence, className }: { confidence: Confidence; className?: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-full border border-border px-2 py-0.5 text-xs text-muted-foreground", className)}>
      confidence: {confidence}
    </span>
  )
}

const TIER_STYLES: Record<Tier, string> = {
  none: "border-border text-muted-foreground",
  verified: "border-accent-foreground/30 text-accent-foreground bg-accent",
  strong: "border-primary/30 text-primary bg-primary/10",
  elite: "border-primary/40 text-primary bg-primary/15",
}

const TIER_LABEL: Record<Tier, string> = {
  none: "Unverified",
  verified: "Verified",
  strong: "Strong",
  elite: "Elite",
}

export function TierPill({ tier, className }: { tier: Tier; className?: string }) {
  return (
    <span className={cn("inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium", TIER_STYLES[tier], className)}>
      {TIER_LABEL[tier]}
    </span>
  )
}
