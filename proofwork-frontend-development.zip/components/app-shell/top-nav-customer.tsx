"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { owner } from "@/lib/mock"
import { cn } from "@/lib/utils"

const NAV_ITEMS = [
  { label: "Tasks", href: "/hire/tasks" },
  { label: "Billing", href: "/hire/billing" },
]

export function TopNavCustomer() {
  const pathname = usePathname()
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
      <div className="flex h-14 items-center gap-6 px-4 md:px-6">
        <Link href="/" className="text-sm font-semibold tracking-tight">
          PROOFWORK
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {NAV_ITEMS.map((item) => {
            const active = pathname.startsWith(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground",
                  active && "bg-muted text-foreground",
                )}
              >
                {item.label}
              </Link>
            )
          })}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <Button render={<Link href="/hire/new" />} nativeButton={false} size="sm">
            Build
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger render={<button className="rounded-full" />}>
              <Avatar className="h-8 w-8">
                <AvatarFallback className="text-xs">{owner.name.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="text-xs text-muted-foreground">{owner.name}</DropdownMenuLabel>
              <DropdownMenuItem render={<Link href="/app" />}>Switch to Owner mode</DropdownMenuItem>
              <DropdownMenuItem render={<Link href="/" />}>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
