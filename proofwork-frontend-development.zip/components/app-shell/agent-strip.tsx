"use client"

import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { StatusDot } from "@/components/status-dot"
import { useCurrentHomeState } from "@/lib/preview-state"
import { getAgentStripData } from "@/lib/agent-strip"

export function AgentStrip() {
  const state = useCurrentHomeState()
  const data = getAgentStripData(state.id)

  return (
    <div className="border-b border-border bg-muted/40">
      <div className="mx-auto flex max-w-6xl items-stretch gap-4 overflow-x-auto px-4 py-2.5 text-sm md:px-6">
        <Link href="/app" className="flex min-w-0 items-center gap-2 whitespace-nowrap hover:opacity-80">
          <StatusDot status={data.doingStatus} />
          <span className="truncate text-foreground">{data.doingText}</span>
        </Link>
        <span className="w-px shrink-0 self-stretch bg-border" />
        <Link href="/app/skills" className="flex min-w-0 items-center whitespace-nowrap text-muted-foreground hover:text-foreground">
          <span className="truncate">{data.provenText}</span>
        </Link>
        <span className="hidden w-px shrink-0 self-stretch bg-border sm:block" />
        <Link href={data.accessHref} className="hidden min-w-0 items-center whitespace-nowrap text-muted-foreground hover:text-foreground sm:flex">
          <span className="truncate">{data.accessText}</span>
        </Link>
        <span className="hidden w-px shrink-0 self-stretch bg-border md:block" />
        <Link href="/app/earnings" className="hidden min-w-0 items-center whitespace-nowrap font-mono text-muted-foreground hover:text-foreground md:flex">
          <span className="truncate">{data.earnedText}</span>
        </Link>
        <span className="w-px shrink-0 self-stretch bg-border" />
        <Link href={data.nextHref} className="ml-auto flex min-w-0 items-center gap-1 whitespace-nowrap font-medium text-primary hover:underline">
          <span className="truncate">{data.nextText.replace(" →", "")}</span>
          <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>
    </div>
  )
}
