"use client"

import { ChevronDown, FlaskConical } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { homeStates } from "@/lib/home-states"
import { usePreviewState } from "@/lib/preview-state"
import { cn } from "@/lib/utils"

export function PreviewSwitcher() {
  const { homeStateId, setHomeStateId } = usePreviewState()
  const current = homeStates.find((s) => s.id === homeStateId)

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <DropdownMenu>
        <DropdownMenuTrigger
          render={<button className="flex items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-xs font-medium text-foreground shadow-md hover:bg-muted" />}
        >
          <FlaskConical className="h-3.5 w-3.5 text-primary" />
          Preview state: {current?.id ?? "H0"}
          <ChevronDown className="h-3 w-3 text-muted-foreground" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="max-h-80 w-72 overflow-y-auto">
          <DropdownMenuLabel className="text-xs text-muted-foreground">Home states</DropdownMenuLabel>
          {homeStates.map((s) => (
            <DropdownMenuItem
              key={s.id}
              className={cn("text-xs", s.id === homeStateId && "bg-accent text-accent-foreground")}
              onClick={() => setHomeStateId(s.id)}
            >
              {s.label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
