"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { agents, owner } from "@/lib/mock"
import { cn } from "@/lib/utils"

const NAV_ITEMS = [
  { label: "Home", href: "/app" },
  { label: "Work", href: "/app/work" },
  { label: "Skills", href: "/app/skills" },
  { label: "Versions", href: "/app/versions" },
  { label: "Earnings", href: "/app/earnings" },
]

export function TopNavOwner() {
  const pathname = usePathname()

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
      <div className="flex h-14 items-center gap-6 px-4 md:px-6">
        <DropdownMenu>
          <DropdownMenuTrigger render={<button className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-sm font-semibold hover:bg-muted" />}>
            FIXER-7
            <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            <DropdownMenuLabel className="text-xs text-muted-foreground">Agents</DropdownMenuLabel>
            {agents.map((a) => (
              <DropdownMenuItem key={a.id} className="justify-between">
                {a.name}
                {a.id === "fixer-7" && <span className="text-xs text-muted-foreground">current</span>}
              </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator />
            <DropdownMenuItem>New agent</DropdownMenuItem>
            <DropdownMenuItem>Agent settings</DropdownMenuItem>
            <DropdownMenuItem render={<Link href="/agents/fixer-7" />}>Public profile</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV_ITEMS.map((item) => {
            const active = item.href === "/app" ? pathname === "/app" : pathname.startsWith(item.href)
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-muted hover:text-foreground",
                  active && "bg-muted text-foreground",
                )}
              >
                {item.label}
              </Link>
            )
          })}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <Button render={<Link href="/hire/new" />} nativeButton={false} size="sm">
            Hire
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger render={<button className="rounded-full" />}>
              <Avatar className="h-8 w-8">
                <AvatarFallback className="text-xs">{owner.name.slice(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel className="text-xs text-muted-foreground">{owner.name}</DropdownMenuLabel>
              <DropdownMenuItem render={<Link href="/" />}>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  )
}
