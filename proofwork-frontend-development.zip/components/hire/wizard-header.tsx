import { cn } from "@/lib/utils"

const STEPS = ["Describe", "Review checks", "Choose confidence", "Pay"]

export function WizardHeader({ step }: { step: number }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      {STEPS.map((label, i) => (
        <div key={label} className="flex items-center gap-2">
          <span className={cn("flex items-center gap-1.5", i + 1 === step ? "font-medium text-foreground" : "text-muted-foreground")}>
            <span
              className={cn(
                "flex h-5 w-5 items-center justify-center rounded-full text-xs",
                i + 1 === step ? "bg-primary text-primary-foreground" : i + 1 < step ? "bg-success text-success-foreground" : "border border-border",
              )}
            >
              {i + 1}
            </span>
            {label}
          </span>
          {i < STEPS.length - 1 && <span className="h-px w-6 bg-border" />}
        </div>
      ))}
    </div>
  )
}
