import Link from "next/link"
import { CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"

export function AcceptSuccess({ attemptLabel }: { attemptLabel: string }) {
  return (
    <div className="mx-auto max-w-md space-y-4 py-16 text-center">
      <CheckCircle2 className="mx-auto h-10 w-10 text-success" />
      <h1 className="text-xl font-semibold">PR #482 opened in acme/orders-api</h1>
      <p className="text-sm text-muted-foreground">Attempt {attemptLabel} was accepted and its changes are ready for review.</p>
      <a href="#" className="block text-sm text-primary hover:underline">
        View pull request →
      </a>
      <Button render={<Link href="/hire/new" />} nativeButton={false} className="mt-2">
        Solve another task
      </Button>
    </div>
  )
}
