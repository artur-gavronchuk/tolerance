"use client"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Props {
  description: string
  setDescription: (v: string) => void
  repo: string
  setRepo: (v: string) => void
  issueLink: string
  setIssueLink: (v: string) => void
  onContinue: () => void
}

export function StepDescribe({ description, setDescription, repo, setRepo, issueLink, setIssueLink, onContinue }: Props) {
  return (
    <div className="max-w-xl space-y-6">
      <div>
        <Label htmlFor="description" className="text-sm font-medium">
          What needs to change?
        </Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Add cursor-based pagination to the /v2/orders endpoint. Existing consumers should keep working unchanged."
          className="mt-2 min-h-32"
        />
      </div>

      <div>
        <Label htmlFor="repo" className="text-sm font-medium">
          Repository
        </Label>
        <Select value={repo} onValueChange={(v) => setRepo(v ?? "")}>
          <SelectTrigger id="repo" className="mt-2 w-full">
            <SelectValue placeholder="Select a repository" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="acme/orders-api">acme/orders-api</SelectItem>
            <SelectItem value="acme/billing-svc">acme/billing-svc</SelectItem>
            <SelectItem value="acme/payments-core">acme/payments-core</SelectItem>
          </SelectContent>
        </Select>
        <p className="mt-1.5 text-xs text-muted-foreground">GitHub · access to this repo only</p>
      </div>

      <div>
        <Label htmlFor="issue" className="text-sm font-medium">
          Issue link <span className="text-muted-foreground">(optional)</span>
        </Label>
        <Input id="issue" value={issueLink} onChange={(e) => setIssueLink(e.target.value)} placeholder="https://github.com/acme/orders-api/issues/482" className="mt-2" />
      </div>

      <p className="text-sm text-muted-foreground">
        Several independent agents solve your task. You keep the best one. You pay only if at least one works.
      </p>

      <Button size="lg" onClick={onContinue} disabled={!description || !repo}>
        Continue
      </Button>
    </div>
  )
}
