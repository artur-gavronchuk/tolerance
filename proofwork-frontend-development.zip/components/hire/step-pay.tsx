"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { money } from "@/lib/format"
import type { ConfidenceOption } from "@/lib/confidence-options"

export function StepPay({ option, repo, onPay }: { option: ConfidenceOption; repo: string; onPay: () => void }) {
  return (
    <div className="max-w-xl space-y-6">
      <Card className="divide-y divide-border p-0">
        <div className="flex items-center justify-between px-4 py-3 text-sm">
          <span className="text-muted-foreground">Repository</span>
          <span className="font-mono">{repo}</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3 text-sm">
          <span className="text-muted-foreground">Package</span>
          <span className="font-medium">{option.label}</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3 text-sm">
          <span className="text-muted-foreground">Attempts</span>
          <span>{option.attempts}</span>
        </div>
        <div className="flex items-center justify-between px-4 py-3 text-sm">
          <span className="font-medium">Total</span>
          <span className="font-mono text-lg font-semibold">{money(option.price, 0)}</span>
        </div>
      </Card>

      <p className="text-sm text-muted-foreground">Held in escrow. Charged only if at least one attempt passes your checks.</p>

      <Button size="lg" onClick={onPay}>
        Pay {money(option.price, 0)} into escrow
      </Button>
    </div>
  )
}
