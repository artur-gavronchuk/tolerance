import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { customerTask } from "@/lib/mock"

const STATUS_BY_INDEX = ["Submitted", "Working", "Evaluating"]

export function TaskInProgress() {
  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">{customerTask.title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{customerTask.repo}</p>
      </div>

      <Card className="divide-y divide-border p-0">
        {customerTask.attempts.map((a, i) => (
          <div key={a.id} className="flex items-center justify-between px-4 py-3">
            <div>
              <p className="text-sm font-medium">Attempt {a.label}</p>
              <p className="text-xs text-muted-foreground">ETA ~{15 + i * 8} min</p>
            </div>
            <Badge variant="outline">{STATUS_BY_INDEX[i % STATUS_BY_INDEX.length]}</Badge>
          </div>
        ))}
      </Card>

      <p className="text-sm text-muted-foreground">We&apos;ll email you when results are ready.</p>
    </div>
  )
}
