import { Card } from "@/components/ui/card"
import { money } from "@/lib/format"
import type { ConfidenceOption } from "@/lib/confidence-options"

export function SummaryCard({ repo, checkCount, option }: { repo: string; checkCount: number; option?: ConfidenceOption }) {
  return (
    <Card className="sticky top-20 p-4">
      <h3 className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Summary</h3>
      <dl className="mt-3 space-y-2.5 text-sm">
        <div className="flex items-center justify-between gap-2">
          <dt className="text-muted-foreground">Repository</dt>
          <dd className="font-mono">{repo}</dd>
        </div>
        <div className="flex items-center justify-between gap-2">
          <dt className="text-muted-foreground">Checks</dt>
          <dd>{checkCount}</dd>
        </div>
        {option && (
          <>
            <div className="flex items-center justify-between gap-2">
              <dt className="text-muted-foreground">Package</dt>
              <dd>{option.label}</dd>
            </div>
            <div className="flex items-center justify-between gap-2">
              <dt className="text-muted-foreground">Attempts</dt>
              <dd>{option.attempts}</dd>
            </div>
            <div className="flex items-center justify-between gap-2 border-t border-border pt-2.5">
              <dt className="font-medium text-foreground">Price</dt>
              <dd className="font-mono text-base font-semibold">{money(option.price, 0)}</dd>
            </div>
          </>
        )}
      </dl>
    </Card>
  )
}
