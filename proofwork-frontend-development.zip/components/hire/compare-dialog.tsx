"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import type { customerTask } from "@/lib/mock"

type Attempt = (typeof customerTask)["attempts"][number]

export function CompareDialog({
  open,
  onOpenChange,
  attemptA,
  attemptB,
  onAccept,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  attemptA: Attempt
  attemptB: Attempt
  onAccept: (attempt: Attempt) => void
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] w-full max-w-4xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Compare {attemptA.label} vs {attemptB.label}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 gap-6">
          {[attemptA, attemptB].map((a) => (
            <div key={a.id} className="space-y-4">
              <div>
                <p className="text-sm font-semibold">
                  Attempt {a.label} · {a.agent}
                </p>
                <p className="text-xs text-muted-foreground">{a.tier}</p>
              </div>

              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Approach</p>
                <p className="mt-1 text-sm text-foreground">{a.summary}</p>
              </div>

              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Checks</p>
                <p className="mt-1 font-mono text-sm">
                  {a.checksPassed}/{a.checksTotal}
                </p>
              </div>

              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">New tests</p>
                <p className="mt-1 font-mono text-sm">
                  +{a.linesAdded} −{a.linesRemoved} in {a.filesChanged} files
                </p>
              </div>

              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Risk</p>
                <p className="mt-1 text-sm text-foreground">{a.riskFlags.length > 0 ? a.riskFlags.join(", ") : "No risk flags"}</p>
              </div>

              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Diff</p>
                <pre className="mt-1 max-h-48 overflow-y-auto rounded-md bg-muted p-3 font-mono text-xs leading-relaxed">
                  <span className="block bg-success/10 text-success">{`+ func Paginate(cursor string, limit int) (*Page, error) {`}</span>
                  <span className="block bg-success/10 text-success">{`+   return store.Query(cursor, limit)`}</span>
                  <span className="block bg-success/10 text-success">{`+ }`}</span>
                  <span className="block bg-destructive/10 text-destructive">{`- func List(page int) ([]Order, error) {`}</span>
                  <span className="block text-muted-foreground">{`  func handler(w http.ResponseWriter, r *http.Request) {`}</span>
                </pre>
              </div>

              <Button className="w-full" onClick={() => onAccept(a)}>
                Accept {a.label}
              </Button>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  )
}
