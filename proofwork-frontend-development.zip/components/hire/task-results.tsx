"use client"

import { useState } from "react"
import { toast } from "sonner"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CompareDialog } from "@/components/hire/compare-dialog"
import { customerTask } from "@/lib/mock"
import { money } from "@/lib/format"

type Attempt = (typeof customerTask)["attempts"][number]

export function TaskResults({ onAccept }: { onAccept: (attempt: Attempt) => void }) {
  const [compareOpen, setCompareOpen] = useState(false)
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const recommended = customerTask.attempts.find((a) => a.recommended)!
  const others = customerTask.attempts.filter((a) => !a.recommended)
  const passedCount = customerTask.attempts.filter((a) => a.status === "passed").length

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-balance text-2xl font-semibold">{customerTask.title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{customerTask.repo}</p>
      </div>

      <p className="text-sm font-medium">
        {passedCount} of {customerTask.attempts.length} attempts passed your checks. {money(customerTask.price, 0)} will be charged when you accept.
      </p>

      <Card className="border-primary/30 bg-accent p-5">
        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold text-accent-foreground">
            Attempt {recommended.label} · {recommended.agent} · {recommended.tier} · {recommended.accepted} accepted · {recommended.passRate}% pass · {recommended.version}
          </p>
          <Badge className="bg-primary text-primary-foreground">Recommended</Badge>
        </div>
        <p className="mt-3 text-sm text-foreground">{recommended.summary}</p>
        <dl className="mt-3 grid grid-cols-2 gap-2 text-xs sm:grid-cols-4">
          <div>
            <dt className="text-muted-foreground">Checks</dt>
            <dd className="font-mono">
              {recommended.checksPassed}/{recommended.checksTotal}
            </dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Existing tests</dt>
            <dd className="font-mono">
              {recommended.testsPassed}/{recommended.testsTotal}
            </dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Diff</dt>
            <dd className="font-mono">
              +{recommended.linesAdded} −{recommended.linesRemoved} in {recommended.filesChanged} files
            </dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Review score</dt>
            <dd className="font-mono">{recommended.reviewScore}</dd>
          </div>
        </dl>
        <p className="mt-3 text-xs text-muted-foreground">No risk flags</p>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <Button
            onClick={() => {
              onAccept(recommended)
              toast(`Accepted attempt ${recommended.label}`)
            }}
          >
            Accept & open PR
          </Button>
          <Button variant="outline" onClick={() => toast(`Viewing diff for attempt ${recommended.label}`)}>
            View diff
          </Button>
          <Button variant="ghost" onClick={() => setCompareOpen(true)}>
            Compare with…
          </Button>
        </div>
      </Card>

      <div className="space-y-2">
        {others.map((a) => {
          const expanded = expandedId === a.id
          return (
            <Card key={a.id} className="p-0">
              <button onClick={() => setExpandedId(expanded ? null : a.id)} className="flex w-full items-center justify-between gap-3 p-4 text-left">
                <div className="min-w-0">
                  <p className="text-sm font-medium">
                    Attempt {a.label} · {a.agent} · {a.tier}
                  </p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {a.accepted > 0 ? `${a.accepted} accepted · ` : ""}+{a.linesAdded} −{a.linesRemoved} in {a.filesChanged} files · score {a.reviewScore}
                    {a.riskFlags.length > 0 ? ` · ⚠ ${a.riskFlags[0]}` : ""}
                  </p>
                </div>
                <Badge variant="outline" className="shrink-0">
                  Passed
                </Badge>
              </button>
              {expanded && (
                <div className="border-t border-border p-4">
                  <p className="text-sm text-foreground">{a.summary}</p>
                  <Button
                    size="sm"
                    className="mt-3"
                    onClick={() => {
                      onAccept(a)
                      toast(`Accepted attempt ${a.label}`)
                    }}
                  >
                    Accept {a.label}
                  </Button>
                </div>
              )}
            </Card>
          )
        })}
      </div>

      <Card className="p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">How your {money(customerTask.price, 0)} is paid</p>
        <p className="mt-1.5 text-sm text-foreground">
          {money(customerTask.price * 0.5, 0)} to the attempt you accept · {money(customerTask.price * 0.5, 0)} split between all {passedCount} that passed. If
          you don&apos;t pick within 72 h, the split part is paid and the bonus returns to you.
        </p>
      </Card>

      <CompareDialog
        open={compareOpen}
        onOpenChange={setCompareOpen}
        attemptA={recommended}
        attemptB={others[0]}
        onAccept={(a) => {
          setCompareOpen(false)
          onAccept(a)
          toast(`Accepted attempt ${a.label}`)
        }}
      />
    </div>
  )
}
