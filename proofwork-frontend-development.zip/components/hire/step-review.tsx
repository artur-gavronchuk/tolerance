"use client"

import { useEffect, useState } from "react"
import { Plus, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import { generatedChecks } from "@/lib/confidence-options"

interface Check {
  id: string
  text: string
  locked: boolean
}

export function StepReview({ onContinue }: { onContinue: () => void }) {
  const [loading, setLoading] = useState(true)
  const [checks, setChecks] = useState<Check[]>([])
  const [newCheck, setNewCheck] = useState("")
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    const t = setTimeout(() => {
      setChecks(generatedChecks)
      setLoading(false)
    }, 1500)
    return () => clearTimeout(t)
  }, [])

  function removeCheck(id: string) {
    setChecks((c) => c.filter((check) => check.id !== id))
  }

  function addCheck() {
    if (!newCheck.trim()) return
    setChecks((c) => [...c, { id: `check-${Date.now()}`, text: newCheck.trim(), locked: false }])
    setNewCheck("")
  }

  if (loading) {
    return (
      <div className="max-w-xl space-y-4">
        <p className="text-sm text-muted-foreground">Drafting checks…</p>
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
        <Skeleton className="h-24 w-full" />
      </div>
    )
  }

  if (failed) {
    return (
      <div className="max-w-xl space-y-6">
        <Card className="border-warning/40 bg-warning/10 p-4">
          <p className="text-sm text-foreground">We can&apos;t verify this automatically yet.</p>
          <p className="mt-1 text-sm text-muted-foreground">
            This task is too open-ended for us to generate objective checks. Try describing a more specific, testable change.
          </p>
        </Card>
        <Button variant="outline" onClick={() => setFailed(false)}>
          Back to checks
        </Button>
      </div>
    )
  }

  return (
    <div className="max-w-xl space-y-6">
      <div>
        <h2 className="text-sm font-medium">What will change</h2>
        <p className="mt-1.5 text-sm text-muted-foreground">
          Add cursor-based pagination to <code className="font-mono text-xs">GET /v2/orders</code>. Likely files: <code className="font-mono text-xs">handlers/orders.go</code>,{" "}
          <code className="font-mono text-xs">handlers/orders_test.go</code>, <code className="font-mono text-xs">middleware/pagination.go</code>.
        </p>
      </div>

      <div>
        <h2 className="text-sm font-medium">How we&apos;ll know it works</h2>
        <p className="mt-1 text-xs text-muted-foreground">These decide whether you pay.</p>
        <div className="mt-3 space-y-2">
          {checks.map((check) => (
            <div key={check.id} className="flex items-center justify-between gap-3 rounded-md border border-border p-2.5 text-sm">
              <span className={check.locked ? "text-muted-foreground" : "text-foreground"}>{check.text}</span>
              {!check.locked && (
                <button onClick={() => removeCheck(check.id)} className="text-muted-foreground hover:text-destructive" aria-label="Remove check">
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>
        <div className="mt-2 flex items-center gap-2">
          <Input value={newCheck} onChange={(e) => setNewCheck(e.target.value)} placeholder="Add a check in plain English" className="text-sm" />
          <Button size="icon" variant="outline" onClick={addCheck} aria-label="Add check">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <p className="text-sm text-muted-foreground">
        Skill: Go Backend · Difficulty: medium
      </p>

      <Button size="lg" onClick={onContinue}>
        Continue
      </Button>
    </div>
  )
}
