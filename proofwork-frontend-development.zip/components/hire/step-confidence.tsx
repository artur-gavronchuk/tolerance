"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts"
import { confidenceOptions, chanceCurve } from "@/lib/confidence-options"
import { money } from "@/lib/format"
import { pct } from "@/lib/format"
import { cn } from "@/lib/utils"

export function StepConfidence({
  selected,
  setSelected,
  onContinue,
}: {
  selected: string
  setSelected: (id: string) => void
  onContinue: () => void
}) {
  const [customizeOpen, setCustomizeOpen] = useState(false)

  return (
    <div className="max-w-2xl space-y-6">
      <div className="grid gap-3 sm:grid-cols-2">
        {confidenceOptions.map((opt) => {
          const active = opt.id === selected
          return (
            <button
              key={opt.id}
              disabled={opt.disabled}
              onClick={() => setSelected(opt.id)}
              className={cn(
                "flex flex-col gap-1.5 rounded-lg border p-4 text-left transition-colors",
                active ? "border-primary bg-accent" : "border-border hover:bg-muted/50",
                opt.disabled && "cursor-not-allowed opacity-50",
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium">
                  {opt.label} {opt.recommended && <span className="text-primary">★</span>}
                </span>
                <span className="font-mono text-base font-semibold">{money(opt.price, 0)}</span>
              </div>
              <p className="text-xs text-muted-foreground">
                {opt.attempts} · {opt.tier} · {pct(opt.chance)} chance · {opt.time}
                {opt.note ? ` · ${opt.note}` : ""}
              </p>
            </button>
          )
        })}
      </div>

      <Card className="p-4">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
          Chance of at least one accepted solution
        </p>
        <div className="mt-3 h-40 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chanceCurve} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="attempts" tick={{ fontSize: 11 }} stroke="currentColor" className="text-muted-foreground" />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} stroke="currentColor" className="text-muted-foreground" />
              <Tooltip
                formatter={(value) => [`${value}%`, "Chance"]}
                labelFormatter={(v) => `${v} attempts`}
                contentStyle={{ fontSize: 12, borderRadius: 8 }}
              />
              <Line type="monotone" dataKey="chance" stroke="var(--color-primary)" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <p className="mt-1 text-xs text-muted-foreground">Estimated from 214 similar Go Backend tasks.</p>
      </Card>

      <p className="text-sm text-muted-foreground">
        Strong: agents that have solved hundreds of verified tasks like yours. Attempts come from different builders and, where possible, different AI
        models, so their mistakes don&apos;t repeat each other.
      </p>

      <div>
        <button onClick={() => setCustomizeOpen((v) => !v)} className="flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground">
          <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", customizeOpen && "rotate-180")} />
          Customize (tier, attempts, deadline)
        </button>
        {customizeOpen && (
          <Card className="mt-3 p-4 text-sm text-muted-foreground">
            Custom tier, attempt count, and deadline controls would appear here for advanced customers.
          </Card>
        )}
      </div>

      <Button size="lg" onClick={onContinue}>
        Continue
      </Button>
    </div>
  )
}
